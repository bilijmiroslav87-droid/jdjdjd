package com.glassmenu;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.option.KeybindsScreen;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.function.BooleanSupplier;
import java.util.function.IntConsumer;
import java.util.function.IntSupplier;
import java.util.function.Supplier;

public class GlassScreen extends Screen {
    // Window size in virtual pixels; the whole window is scaled by ui to fit the screen.
    private static final int W = 440, H = 300;
    private static final String[] TABS = {"HUD", "Tools", "Armor", "Fx", "Glass", "Info"};

    // Sidebar on the left, cards on the right
    private static final int SIDE_W = 52;                        // sidebar width
    private static final int ICON_X = 8, ICON_Y = 52, ICON_SIZE = 36, ICON_STEP = 44;
    private static final int GRID_X = 68, GRID_Y = 56, GRID_BOTTOM = H - 14;
    private static final int GRID_W = W - GRID_X - 12;
    private static final int CARD_GAP = 8, CARD_W = (GRID_W - CARD_GAP) / 2, CARD_H = 52;
    private static final int CARD_STEP = CARD_H + CARD_GAP;
    private static final int SCROLL_STEP = 14;
    private static final int POP_W = 200, POP_H = 132;

    // Matte colours. The only accent is UI_ACCENT and it is used for active switches only.
    private static final int BODY = 0x0B0C10;
    private static final int UI_ACCENT = 0xFF8B5CF6;
    private static final int TEXT = 0xF2F2F5, TEXT_DIM = 0x8A8F98;

    private int tab = 0;
    private List<Row> cards = new ArrayList<>();   // clickable and info entries of the current tab
    private int contentHeight;
    private int scroll;
    private int presetIndex;
    private Row popup;                              // module open in the popup window, or null
    private float ui = 1f;
    private final long openedAt = System.nanoTime();

    public GlassScreen() {
        super(net.minecraft.text.Text.literal("Glass Menu"));
    }

    @Override
    protected void init() {
        ui = computeUi();
        rebuild();
    }

    private float computeUi() {
        float s = Math.min(width / (float) (W + 40), height / (float) (H + 40));
        return Math.max(1f, Math.min(1.5f, s));
    }

    private int vWidth() { return Math.round(width / ui); }
    private int vHeight() { return Math.round(height / ui); }
    private int left() { return (vWidth() - W) / 2; }
    private int top() { return (vHeight() - H) / 2; }

    private void rebuild() {
        cards = new ArrayList<>();
        for (Row r : buildRows()) {
            if (!r.header) cards.add(r);
        }
        scroll = 0;
        popup = null;
        int rowCount = (cards.size() + 1) / 2;
        contentHeight = rowCount == 0 ? 0 : (rowCount - 1) * CARD_STEP + CARD_H;
    }

    private int maxScroll() {
        return Math.max(0, contentHeight - (GRID_BOTTOM - GRID_Y));
    }

    private int cardX(int x, int i) { return x + GRID_X + (i % 2) * (CARD_W + CARD_GAP); }
    private int cardY(int y, int i) { return y + GRID_Y + (i / 2) * CARD_STEP - scroll; }
    private boolean cardVisible(int y, int cy) { return cy >= y + GRID_Y && cy + CARD_H <= y + GRID_BOTTOM; }

    private int popupX(int x) { return x + (W - POP_W) / 2; }
    private int popupY(int y) { return y + (H - POP_H) / 2; }

    private static boolean inside(int mx, int my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    private Row cardAt(int mx, int my) {
        int x = left(), y = top();
        for (int i = 0; i < cards.size(); i++) {
            Row row = cards.get(i);
            if (row.click == null) continue;
            int cx = cardX(x, i), cy = cardY(y, i);
            if (cardVisible(y, cy) && inside(mx, my, cx, cy, CARD_W, CARD_H)) return row;
        }
        return null;
    }

    /** Sidebar icon index under a point in virtual coordinates, or -1. */
    private int sidebarAt(int mx, int my) {
        int x = left(), y = top();
        for (int i = 0; i < TABS.length; i++) {
            if (inside(mx, my, x + ICON_X, y + ICON_Y + i * ICON_STEP, ICON_SIZE, ICON_SIZE)) return i;
        }
        return -1;
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        ui = computeUi();

        float p = openProgress();
        int vw = vWidth(), vh = vHeight();
        int x = left();
        int y = top() + Math.round((1f - p) * 12f);
        int ta = Math.round(255 * p);
        int mx = Math.round(mouseX / ui), my = Math.round(mouseY / ui);
        int hotTab = sidebarAt(mx, my);

        ctx.getMatrices().push();
        ctx.getMatrices().scale(ui, ui, 1f);

        // dim backdrop, soft shadow, thin border, matte body
        ctx.fill(0, 0, vw, vh, Theme.alpha(0x000000, Math.round(0x66 * p)));
        Draw.shadow(ctx, x, y, W, H, 14, 0x000000, Math.round(0xB0 * p), 16);
        Draw.roundRect(ctx, x, y, W, H, 14, Theme.alpha(0xFFFFFF, Math.round(0x1A * p)));
        Draw.roundRect(ctx, x + 1, y + 1, W - 2, H - 2, 13, Theme.alpha(BODY, Math.round(0xF4 * p)));

        // sidebar divider
        ctx.fill(x + SIDE_W, y + 16, x + SIDE_W + 1, y + H - 16, Theme.alpha(0xFFFFFF, Math.round(0x14 * p)));

        // sidebar icons: active gets a soft background, hover brightens the icon and shows a label
        for (int i = 0; i < TABS.length; i++) {
            int ix = x + ICON_X, iy = y + ICON_Y + i * ICON_STEP;
            boolean sel = i == tab, hot = i == hotTab;
            if (sel) Draw.roundRect(ctx, ix, iy, ICON_SIZE, ICON_SIZE, 10, Theme.alpha(0xFFFFFF, Math.round(0x1C * p)));
            else if (hot) Draw.roundRect(ctx, ix, iy, ICON_SIZE, ICON_SIZE, 10, Theme.alpha(0xFFFFFF, Math.round(0x0C * p)));
            int iconAlpha = sel ? 0xFF : hot ? 0xC0 : 0x70;
            drawIcon(ctx, i, ix + ICON_SIZE / 2, iy + ICON_SIZE / 2, Theme.alpha(0xFFFFFF, Math.round(iconAlpha * p)));
        }
        if (hotTab >= 0) {
            int ty = y + ICON_Y + hotTab * ICON_STEP + ICON_SIZE / 2 - 9;
            int tw = textRenderer.getWidth(Fonts.text(TABS[hotTab])) + 14;
            Draw.roundRect(ctx, x + SIDE_W + 6, ty, tw, 18, 6, Theme.alpha(0x1B1E26, Math.round(0xF0 * p)));
            ctx.drawTextWithShadow(textRenderer, Fonts.text(TABS[hotTab]), x + SIDE_W + 13, ty + 5,
                    Theme.alpha(TEXT, ta));
        }

        // content header
        ctx.drawTextWithShadow(textRenderer, Fonts.medium(TABS[tab]), x + GRID_X, y + 16, Theme.alpha(TEXT, ta));
        ctx.drawTextWithShadow(textRenderer, Fonts.text(cards.size() + " options"), x + GRID_X, y + 31,
                Theme.alpha(TEXT_DIM, ta));

        // cards
        Row hot = cardAt(mx, my);
        for (int i = 0; i < cards.size(); i++) {
            Row row = cards.get(i);
            int cx = cardX(x, i), cy = y + GRID_Y + (i / 2) * CARD_STEP - scroll;
            if (!cardVisible(y, cy)) continue;
            drawCard(ctx, row, cx, cy, row == hot, p, ta);
        }

        // scroll indicator
        if (maxScroll() > 0) {
            int track = GRID_BOTTOM - GRID_Y;
            int thumb = Math.max(18, track * track / contentHeight);
            int ty = y + GRID_Y + (track - thumb) * scroll / maxScroll();
            Draw.roundRect(ctx, x + W - 7, ty, 3, thumb, 1, Theme.alpha(0xFFFFFF, Math.round(0x30 * p)));
        }

        if (popup != null) drawPopup(ctx, x, y, p, ta);

        ctx.getMatrices().pop();
    }

    /** Minimal icons drawn with plain shapes, so no icon font is needed. */
    private void drawIcon(DrawContext ctx, int tab, int cx, int cy, int c) {
        switch (tab) {
            case 0 -> { // HUD: monitor with bars
                frame(ctx, cx - 9, cy - 7, 18, 13, c);
                ctx.fill(cx - 5, cy - 2, cx - 2, cy + 2, c);
                ctx.fill(cx - 1, cy - 4, cx + 2, cy + 2, c);
                ctx.fill(cx + 3, cy - 1, cx + 6, cy + 2, c);
                ctx.fill(cx - 3, cy + 6, cx + 3, cy + 8, c);
            }
            case 1 -> { // Tools: 2x2 grid
                ctx.fill(cx - 7, cy - 7, cx - 1, cy - 1, c);
                ctx.fill(cx + 1, cy - 7, cx + 7, cy - 1, c);
                ctx.fill(cx - 7, cy + 1, cx - 1, cy + 7, c);
                ctx.fill(cx + 1, cy + 1, cx + 7, cy + 7, c);
            }
            case 2 -> { // Armor: shield
                ctx.fill(cx - 7, cy - 8, cx + 7, cy + 1, c);
                ctx.fill(cx - 5, cy + 1, cx + 5, cy + 4, c);
                ctx.fill(cx - 3, cy + 4, cx + 3, cy + 7, c);
                ctx.fill(cx - 1, cy + 7, cx + 1, cy + 8, c);
            }
            case 3 -> { // Fx: sparkle
                ctx.fill(cx - 1, cy - 8, cx + 1, cy + 8, c);
                ctx.fill(cx - 8, cy - 1, cx + 8, cy + 1, c);
                ctx.fill(cx - 5, cy - 5, cx - 4, cy - 4, c);
                ctx.fill(cx + 4, cy + 4, cx + 5, cy + 5, c);
            }
            case 4 -> { // Glass: ring with a dot
                ring(ctx, cx, cy, 8, c);
                Draw.roundRect(ctx, cx - 2, cy - 2, 4, 4, 2, c);
            }
            default -> { // Info: ring with an "i"
                ring(ctx, cx, cy, 8, c);
                ctx.fill(cx - 1, cy - 4, cx + 1, cy - 2, c);
                ctx.fill(cx - 1, cy - 1, cx + 1, cy + 4, c);
            }
        }
    }

    private static void frame(DrawContext ctx, int x, int y, int w, int h, int c) {
        ctx.fill(x, y, x + w, y + 1, c);
        ctx.fill(x, y + h - 1, x + w, y + h, c);
        ctx.fill(x, y, x + 1, y + h, c);
        ctx.fill(x + w - 1, y, x + w, y + h, c);
    }

    private static void ring(DrawContext ctx, int cx, int cy, int r, int c) {
        Draw.roundRect(ctx, cx - r, cy - r, 2 * r, 2 * r, r, c);
        Draw.roundRect(ctx, cx - r + 1, cy - r + 1, 2 * r - 2, 2 * r - 2, r - 1, Theme.alpha(BODY, 0xFF));
    }

    /** Card with a thin border, label, state text, switch or value bar. */
    private void drawCard(DrawContext ctx, Row row, int cx, int cy, boolean hot, float p, int ta) {
        boolean on = row.on != null && row.on.getAsBoolean();
        if (hot) Draw.shadow(ctx, cx, cy, CARD_W, CARD_H, 10, 0xFFFFFF, Math.round(0x14 * p), 4);
        Draw.roundRect(ctx, cx, cy, CARD_W, CARD_H, 10, Theme.alpha(0xFFFFFF, Math.round(0x18 * p)));
        Draw.roundRect(ctx, cx + 1, cy + 1, CARD_W - 2, CARD_H - 2, 9,
                Theme.alpha(0xFFFFFF, Math.round((hot ? 0x14 : 0x0A) * p)));

        ctx.drawTextWithShadow(textRenderer, Fonts.text(row.label), cx + 12, cy + 10, Theme.alpha(TEXT, ta));

        String sub;
        if (row.on != null) {
            sub = on ? "On" : "Off";
        } else {
            sub = row.value.get();
        }
        ctx.drawTextWithShadow(textRenderer, Fonts.text(sub), cx + 12, cy + 25, Theme.alpha(TEXT_DIM, ta));

        if (row.on != null) {
            drawSwitch(ctx, cx + CARD_W - 40, cy + 18, on, p);
        }
        if (row.sliderGet != null) {
            int bx = cx + 12, by = cy + CARD_H - 9, bw = CARD_W - 24;
            Draw.roundRect(ctx, bx, by, bw, 3, 1, Theme.alpha(0xFFFFFF, Math.round(0x22 * p)));
            float t = (row.sliderGet.getAsInt() - row.sliderMin) / (float) Math.max(1, row.sliderMax - row.sliderMin);
            int fw = Math.max(3, Math.round(bw * Math.max(0f, Math.min(1f, t))));
            Draw.roundRect(ctx, bx, by, fw, 3, 1, Theme.alpha(0xFFFFFF, Math.round(0xD0 * p)));
        }
    }

    /** Switch: UI_ACCENT when on, neutral grey when off, white knob. */
    private static void drawSwitch(DrawContext ctx, int x, int y, boolean on, float p) {
        int w = 28, h = 16;
        Draw.roundRect(ctx, x, y, w, h, 8, on ? Theme.alpha(UI_ACCENT, Math.round(255 * p))
                : Theme.alpha(0xFFFFFF, Math.round(0x30 * p)));
        int kx = on ? x + w - h + 2 : x + 2;
        Draw.roundRect(ctx, kx, y + 2, h - 4, h - 4, 6, Theme.alpha(0xFFFFFF, Math.round(255 * p)));
    }

    private void drawPopup(DrawContext ctx, int x, int y, float p, int ta) {
        int px = popupX(x), py = popupY(y);
        Draw.shadow(ctx, px, py, POP_W, POP_H, 12, 0x000000, Math.round(0xC0 * p), 16);
        Draw.roundRect(ctx, px, py, POP_W, POP_H, 12, Theme.alpha(0xFFFFFF, Math.round(0x1A * p)));
        Draw.roundRect(ctx, px + 1, py + 1, POP_W - 2, POP_H - 2, 11, Theme.alpha(0x14161C, Math.round(0xF8 * p)));

        ctx.drawTextWithShadow(textRenderer, Fonts.medium(popup.label), px + 14, py + 13, Theme.alpha(TEXT, ta));
        ctx.drawTextWithShadow(textRenderer, Fonts.text("x"), px + POP_W - 18, py + 13, Theme.alpha(TEXT_DIM, ta));
        ctx.fill(px + 14, py + 30, px + POP_W - 14, py + 31, Theme.alpha(0xFFFFFF, Math.round(0x18 * p)));

        ctx.drawTextWithShadow(textRenderer, Fonts.text(popup.value.get()), px + 14, py + 40,
                Theme.alpha(TEXT_DIM, ta));

        if (popup.on != null) {
            drawSwitch(ctx, px + POP_W / 2 - 14, py + 58, popup.on.getAsBoolean(), p);
        }
        if (popup.primary != null) popupButton(ctx, px + 14, py + POP_H - 36, popup.primary, p, ta);
        if (popup.secondary != null) popupButton(ctx, px + POP_W - 98, py + POP_H - 36, popup.secondary, p, ta);
    }

    private void popupButton(DrawContext ctx, int bx, int by, String text, float p, int ta) {
        Draw.roundRect(ctx, bx, by, 84, 24, 8, Theme.alpha(0xFFFFFF, Math.round(0x1C * p)));
        ctx.drawCenteredTextWithShadow(textRenderer, Fonts.text(text), bx + 42, by + 8, Theme.alpha(TEXT, ta));
    }

    private float openProgress() {
        if (!Settings.openAnim) return 1f;
        float t = (System.nanoTime() - openedAt) / 180_000_000f;
        t = Math.max(0f, Math.min(1f, t));
        float inv = 1f - t;
        return 1f - inv * inv * inv;
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button != 0 && button != 1) return super.mouseClicked(mouseX, mouseY, button);
        int mx = (int) Math.round(mouseX / ui), my = (int) Math.round(mouseY / ui);
        int x = left(), y = top();

        // popup window takes all clicks while it is open
        if (popup != null) {
            int px = popupX(x), py = popupY(y);
            if (inside(mx, my, px + POP_W - 24, py + 8, 16, 16)) {
                popup = null;
                return true;
            }
            if (popup.primary != null && inside(mx, my, px + 14, py + POP_H - 36, 84, 24)) {
                popup.click.accept(0);
                return true;
            }
            if (popup.secondary != null && inside(mx, my, px + POP_W - 98, py + POP_H - 36, 84, 24)) {
                popup.click.accept(1);
                return true;
            }
            if (popup.on != null && inside(mx, my, px + POP_W / 2 - 14, py + 58, 28, 16)) {
                popup.click.accept(0);
                return true;
            }
            if (!inside(mx, my, px, py, POP_W, POP_H)) popup = null;
            return true;
        }

        // sidebar icons
        int t = sidebarAt(mx, my);
        if (t >= 0) {
            tab = t;
            rebuild();
            return true;
        }

        // cards: the switch toggles directly, anywhere else opens the popup
        Row row = cardAt(mx, my);
        if (row != null) {
            int i = cards.indexOf(row);
            if (row.on != null && inside(mx, my, cardX(x, i) + CARD_W - 40, cardY(y, i) + 18, 28, 16)) {
                row.click.accept(0);
            } else {
                popup = row;
            }
            return true;
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        int mx = (int) Math.round(mouseX / ui), my = (int) Math.round(mouseY / ui);
        int x = left(), y = top();
        if (inside(mx, my, x + GRID_X, y + GRID_Y, GRID_W, GRID_BOTTOM - GRID_Y) && verticalAmount != 0) {
            scroll = Math.max(0, Math.min(maxScroll(), scroll - (int) Math.signum(verticalAmount) * SCROLL_STEP));
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    @Override
    public void removed() {
        Config.save();
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    // ---------- tab contents ----------

    private List<Row> buildRows() {
        List<Row> r = new ArrayList<>();
        MinecraftClient mc = MinecraftClient.getInstance();

        switch (tab) {
            case 0 -> { // HUD
                r.add(header("INFO PANEL"));
                r.add(toggle("Info panel", () -> Settings.infoPanel, () -> Settings.infoPanel = !Settings.infoPanel));
                r.add(cycle("Info corner", () -> Hud.CORNER_NAMES[Settings.infoCorner],
                        d -> Settings.infoCorner = Math.floorMod(Settings.infoCorner + d, 4)));
                r.add(toggle("Game time", () -> Settings.showTime, () -> Settings.showTime = !Settings.showTime));
                r.add(toggle("Coordinates", () -> Settings.showCoords, () -> Settings.showCoords = !Settings.showCoords));
                r.add(toggle("Speed", () -> Settings.showSpeed, () -> Settings.showSpeed = !Settings.showSpeed));
                r.add(toggle("Ping", () -> Settings.showPing, () -> Settings.showPing = !Settings.showPing));
                r.add(toggle("CPS counter", () -> Settings.cps, () -> Settings.cps = !Settings.cps));
                r.add(header("OVERLAYS"));
                r.add(toggle("Compass", () -> Settings.compass, () -> Settings.compass = !Settings.compass));
                r.add(toggle("FPS graph", () -> Settings.showGraph, () -> Settings.showGraph = !Settings.showGraph));
                r.add(cycle("Graph corner", () -> Hud.CORNER_NAMES[Settings.graphCorner],
                        d -> Settings.graphCorner = Math.floorMod(Settings.graphCorner + d, 4)));
                r.add(new Row("Preset", null, () -> "< " + Settings.PRESET_NAMES[presetIndex] + " >",
                        b -> {
                            if (b == 1) {
                                presetIndex = (presetIndex + 1) % Settings.PRESET_NAMES.length;
                            } else {
                                Settings.applyPreset(presetIndex);
                                Config.save();
                            }
                        }, false));
            }
            case 1 -> { // Tools
                r.add(header("KEYSTROKES"));
                r.add(toggle("Keystrokes", () -> Settings.keystrokes, () -> Settings.keystrokes = !Settings.keystrokes));
                r.add(cycle("Keys corner", () -> Hud.CORNER_NAMES[Settings.keystrokesCorner],
                        d -> Settings.keystrokesCorner = Math.floorMod(Settings.keystrokesCorner + d, 4)));
                r.add(header("CROSSHAIR & OVERLAYS"));
                r.add(cycle("Crosshair", () -> Settings.CROSSHAIR_NAMES[Settings.crosshairStyle],
                        d -> Settings.crosshairStyle = Math.floorMod(Settings.crosshairStyle + d, Settings.CROSSHAIR_NAMES.length)));
                r.add(toggle("Hide fire overlay", () -> Settings.hideFire, () -> Settings.hideFire = !Settings.hideFire));
                r.add(toggle("Hide vignette", () -> Settings.hideVignette, () -> Settings.hideVignette = !Settings.hideVignette));
                r.add(header("ZOOM"));
                r.add(toggle("Zoom (hold C)", () -> Settings.zoomEnabled, () -> Settings.zoomEnabled = !Settings.zoomEnabled));
                r.add(slider("Zoom FOV", () -> Settings.zoomFov, v -> Settings.zoomFov = v, 30, 70, 5, ""));
                r.add(header("SESSION"));
                r.add(toggle("Session timer", () -> Settings.showSession, () -> Settings.showSession = !Settings.showSession));
                r.add(toggle("Waypoints (M)", () -> Settings.showWaypoint, () -> Settings.showWaypoint = !Settings.showWaypoint));
                r.add(new Row("Clear waypoints", null, () -> GlassMenu.waypoints().size() + " set", b -> {
                    GlassMenu.clearWaypoints();
                }, false));
                r.add(toggle("Session stats", () -> Settings.showStats, () -> Settings.showStats = !Settings.showStats));
                r.add(new Row("Reset stats", null, () -> "click", b -> {
                    GlassMenu.resetStats();
                }, false));
                r.add(toggle("FPS / ping colors", () -> Settings.fpsColors, () -> Settings.fpsColors = !Settings.fpsColors));
            }
            case 2 -> { // Armor & potions
                r.add(header("ARMOUR"));
                r.add(toggle("Armor HUD", () -> Settings.armorHud, () -> Settings.armorHud = !Settings.armorHud));
                r.add(cycle("Armor corner", () -> Hud.CORNER_NAMES[Settings.armorCorner],
                        d -> Settings.armorCorner = Math.floorMod(Settings.armorCorner + d, 4)));
                r.add(header("POTIONS"));
                r.add(toggle("Potion HUD", () -> Settings.potionHud, () -> Settings.potionHud = !Settings.potionHud));
                r.add(cycle("Potion corner", () -> Hud.CORNER_NAMES[Settings.potionCorner],
                        d -> Settings.potionCorner = Math.floorMod(Settings.potionCorner + d, 4)));
            }
            case 3 -> { // Fx
                r.add(header("TRAIL & HITS"));
                r.add(cycle("Trail", () -> Settings.TRAIL_NAMES[Settings.trailMode],
                        d -> Settings.trailMode = Math.floorMod(Settings.trailMode + d, Settings.TRAIL_NAMES.length)));
                r.add(cycle("Hit effect", () -> Settings.HIT_NAMES[Settings.hitMode],
                        d -> Settings.hitMode = Math.floorMod(Settings.hitMode + d, Settings.HIT_NAMES.length)));
                r.add(header("NEON HAT"));
                r.add(cycle("Hat style", () -> Settings.HAT_NAMES[Settings.hatMode],
                        d -> Settings.hatMode = Math.floorMod(Settings.hatMode + d, Settings.HAT_NAMES.length)));
                r.add(slider("Hat size", () -> Settings.hatSize, v -> Settings.hatSize = v, 1, 3, 1, ""));
                r.add(toggle("Hat gradient", () -> Settings.hatGradient, () -> Settings.hatGradient = !Settings.hatGradient));
                r.add(header("WINGS & JUMP"));
                r.add(toggle("Particle wings", () -> Settings.wings, () -> Settings.wings = !Settings.wings));
                r.add(toggle("Jump burst", () -> Settings.jumpFx, () -> Settings.jumpFx = !Settings.jumpFx));
                r.add(header("WEATHER"));
                r.add(cycle("Weather", () -> Settings.WEATHER_NAMES[Settings.weatherMode],
                        d -> Settings.weatherMode = Math.floorMod(Settings.weatherMode + d, Settings.WEATHER_NAMES.length)));
                r.add(slider("Weather density", () -> Settings.weatherDensity, v -> Settings.weatherDensity = v, 1, 10, 1, ""));
                r.add(header("ACCENT"));
                r.add(toggle("Rainbow accent", () -> Settings.rainbow, () -> Settings.rainbow = !Settings.rainbow));
                r.add(cycle("Accent", () -> Settings.ACCENT_NAMES[Settings.accentIndex],
                        d -> Settings.accentIndex = Math.floorMod(Settings.accentIndex + d, Settings.ACCENTS.length)));
            }
            case 4 -> { // Glass
                r.add(header("PULSE"));
                r.add(new Row("Apply Pulse dark theme", null, () -> "click", b -> {
                    Settings.applyPulseTheme();
                    Config.save();
                }, false));
                r.add(header("HUD LOOK"));
                r.add(slider("HUD opacity", () -> Settings.hudAlpha, v -> Settings.hudAlpha = v, 0, 100, 10, "%"));
                r.add(cycle("HUD scale", () -> Settings.hudScale + "%",
                        d -> {
                            int i = 0;
                            for (int k = 0; k < Settings.HUD_SCALES.length; k++) {
                                if (Settings.HUD_SCALES[k] == Settings.hudScale) i = k;
                            }
                            i = Math.floorMod(i + d, Settings.HUD_SCALES.length);
                            Settings.hudScale = Settings.HUD_SCALES[i];
                        }));
                r.add(toggle("HUD accent bar", () -> Settings.hudAccentBar, () -> Settings.hudAccentBar = !Settings.hudAccentBar));
                r.add(header("NIGHT"));
                r.add(toggle("Brightness boost", () -> Settings.brightBoost, () -> Settings.brightBoost = !Settings.brightBoost));
                r.add(header("PANEL"));
                r.add(slider("Opacity", () -> Settings.glassAlpha, v -> Settings.glassAlpha = v, 20, 100, 5, "%"));
                r.add(slider("Corner radius", () -> Settings.cornerRadius, v -> Settings.cornerRadius = v, 0, 12, 1, "px"));
                r.add(toggle("Open animation", () -> Settings.openAnim, () -> Settings.openAnim = !Settings.openAnim));
            }
            default -> { // Info
                r.add(header("KEYS"));
                r.add(info("Menu key", () -> GlassMenu.openKey().getBoundKeyLocalizedText().getString()));
                r.add(info("Zoom key", () -> GlassMenu.zoomKey().getBoundKeyLocalizedText().getString() + " (hold)"));
                r.add(info("Hide HUD", () -> GlassMenu.hudKey().getBoundKeyLocalizedText().getString()));
                r.add(info("Waypoint / copy", () -> "M / N"));
                r.add(header("ACTIONS"));
                r.add(new Row("Controls", null, () -> "open",
                        b -> mc.setScreen(new KeybindsScreen(this, mc.options)), false));
                r.add(new Row("Reset settings", null, () -> "click", b -> {
                    Settings.resetDefaults();
                    Config.save();
                }, false));
                r.add(info("Config file", () -> "glassmenu.json"));
            }
        }
        return r;
    }

    private static Row header(String title) {
        Row r = new Row(title, null, null, null, true);
        return r;
    }

    private static Row toggle(String label, BooleanSupplier get, Runnable flip) {
        return new Row(label, get, null, b -> {
            flip.run();
            Config.save();
        }, false);
    }

    /** Left click / right click step through values. step receives +1 or -1. */
    private static Row cycle(String label, Supplier<String> value, IntConsumer step) {
        return new Row(label, null, value, b -> {
            step.accept(b == 1 ? -1 : 1);
            Config.save();
        }, false);
    }

    /** Left click increases, right click decreases. */
    private static Row slider(String label, IntSupplier get, IntConsumer set, int min, int max, int step, String suffix) {
        IntConsumer adjust = d -> {
            set.accept(Math.max(min, Math.min(max, get.getAsInt() + d * step)));
            Config.save();
        };
        return new Row(label, null, () -> "< " + get.getAsInt() + suffix + " >",
                b -> adjust.accept(b == 1 ? -1 : 1), false).labels("+", "-").range(min, max, get);
    }

    private static Row info(String label, Supplier<String> value) {
        return new Row(label, null, value, null, false);
    }

    /** Labels of the actions that run once; the popup shows a single "Run" button for them. */
    private static final Set<String> ACTIONS = Set.of(
            "Apply Pulse dark theme", "Clear waypoints", "Reset stats", "Controls", "Reset settings");

    private static final class Row {
        final String label;
        final BooleanSupplier on;   // if not null the row is a switch
        final Supplier<String> value;
        final IntConsumer click;    // receives the mouse button (0 left, 1 right); null = info only
        final boolean header;
        String primary;             // popup button for mouse button 0
        String secondary;           // popup button for mouse button 1, may be null
        IntSupplier sliderGet;      // set for sliders, shows a value bar on the card
        int sliderMin, sliderMax;

        Row(String label, BooleanSupplier on, Supplier<String> value, IntConsumer click, boolean header) {
            this.label = label;
            this.on = on;
            this.value = value;
            this.click = click;
            this.header = header;
            if (on != null) {
                primary = "Toggle";
                secondary = null;
            } else if (label.equals("Preset")) {
                primary = "Apply";
                secondary = "Next";
            } else if (ACTIONS.contains(label)) {
                primary = "Run";
                secondary = null;
            } else {
                primary = "Next";
                secondary = "Prev";
            }
        }

        Row labels(String p, String s) {
            primary = p;
            secondary = s;
            return this;
        }

        Row range(int min, int max, IntSupplier get) {
            sliderMin = min;
            sliderMax = max;
            sliderGet = get;
            return this;
        }
    }
}
