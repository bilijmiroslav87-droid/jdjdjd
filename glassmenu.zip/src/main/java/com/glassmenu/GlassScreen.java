package com.glassmenu;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.option.KeybindsScreen;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.function.BooleanSupplier;
import java.util.function.IntConsumer;
import java.util.function.IntSupplier;
import java.util.function.Supplier;

public class GlassScreen extends Screen {
    // Window size in virtual pixels; the whole window is scaled by ui to fit the screen.
    private static final int W = 440, H = 290;
    private static final String[] TABS = {"HUD", "Tools", "Armor", "Fx", "Glass", "Info"};
    private static final int SIDE_X = 12, SIDE_Y = 48, SIDE_W = 100, SIDE_H = 24, SIDE_STEP = 28;
    private static final int GRID_X = 124, GRID_Y = 48, GRID_BOTTOM = H - 26;
    private static final int CARD_W = 149, CARD_H = 40, CARD_GAP = 6, CARD_STEP = 46;
    private static final int SCROLL_STEP = 14;
    private static final int POP_W = 200, POP_H = 132;

    private int tab = 0;
    private List<Row> cards = new ArrayList<>();   // clickable entries of the current tab, shown as cards
    private int contentHeight;
    private int scroll;
    private int presetIndex;
    private Row popup;                              // module open in the popup window, or null
    private float ui = 1f;
    private final long openedAt = System.nanoTime();

    public GlassScreen() {
        super(net.minecraft.text.Text.literal("Glass Menu"));
    }

    @Override
    protected void init() {
        ui = computeUi();
        rebuild();
    }

    private float computeUi() {
        float s = Math.min(width / (float) (W + 40), height / (float) (H + 40));
        return Math.max(1f, Math.min(1.5f, s));
    }

    private int vWidth() { return Math.round(width / ui); }
    private int vHeight() { return Math.round(height / ui); }
    private int left() { return (vWidth() - W) / 2; }
    private int top() { return (vHeight() - H) / 2; }

    private void rebuild() {
        cards = new ArrayList<>();
        for (Row r : buildRows()) {
            if (!r.header) cards.add(r);
        }
        scroll = 0;
        popup = null;
        int rowCount = (cards.size() + 1) / 2;
        contentHeight = rowCount == 0 ? 0 : (rowCount - 1) * CARD_STEP + CARD_H;
    }

    private int maxScroll() {
        return Math.max(0, contentHeight - (GRID_BOTTOM - GRID_Y));
    }

    /** Card position relative to a window origin (x, y); the window origin is the top-left of the window. */
    private int cardX(int x, int i) { return x + GRID_X + (i % 2) * (CARD_W + CARD_GAP); }
    private int cardY(int y, int i) { return y + GRID_Y + (i / 2) * CARD_STEP - scroll; }
    private boolean cardVisible(int y, int cy) { return cy >= y + GRID_Y && cy + CARD_H <= y + GRID_BOTTOM; }

    private int popupX(int x) { return x + (W - POP_W) / 2; }
    private int popupY(int y) { return y + (H - POP_H) / 2; }

    private static boolean inside(int mx, int my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    /** Clickable card under a point in virtual coordinates, or null. */
    private Row cardAt(int mx, int my) {
        int x = left(), y = top();
        for (int i = 0; i < cards.size(); i++) {
            Row row = cards.get(i);
            if (row.click == null) continue;
            int cx = cardX(x, i), cy = cardY(y, i);
            if (cardVisible(y, cy) && inside(mx, my, cx, cy, CARD_W, CARD_H)) return row;
        }
        return null;
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        ui = computeUi();

        float p = openProgress();
        int vw = vWidth(), vh = vHeight();
        int x = left();
        int y = top() + Math.round((1f - p) * 14f);
        int accent = Theme.accent();
        int r = Settings.cornerRadius;
        int ir = Math.max(0, r - 1);
        int ta = Math.round(255 * p);
        int mx = Math.round(mouseX / ui), my = Math.round(mouseY / ui);

        ctx.getMatrices().push();
        ctx.getMatrices().scale(ui, ui, 1f);

        // dim + parallax background
        ctx.fill(0, 0, vw, vh, Theme.alpha(0x000000, Math.round(0x50 * p)));
        if (Settings.parallax) drawParallax(ctx, vw, vh, mx, my, accent, p);

        // window: shadow, border, body, top sheen
        Draw.roundRect(ctx, x + 2, y + 5, W, H, r, Theme.alpha(0x000000, Math.round(0x80 * p)));
        Draw.roundRect(ctx, x, y, W, H, r, Theme.alpha(0xFFFFFF, Math.round(0x26 * p)));
        Draw.roundRect(ctx, x + 1, y + 1, W - 2, H - 2, ir,
                Theme.alpha(0x0A0E13, Math.round(Settings.glassAlpha * 2.55f * p)));
        Draw.roundRect(ctx, x + 1, y + 1, W - 2, 40, ir, Theme.alpha(0xFFFFFF, Math.round(0x0C * p)));
        if (Settings.sheen) drawSheen(ctx, x, y, p);

        // title
        ctx.drawCenteredTextWithShadow(textRenderer, Fonts.medium("Glass Menu"), x + W / 2, y + 12,
                Theme.alpha(0xFFFFFF, ta));
        ctx.drawCenteredTextWithShadow(textRenderer, Fonts.text("settings"), x + W / 2, y + 24,
                Theme.alpha(0x8A9099, ta));

        // divider between sidebar and grid
        ctx.fill(x + SIDE_X + SIDE_W + 8, y + 44, x + SIDE_X + SIDE_W + 9, y + H - 26,
                Theme.alpha(0xFFFFFF, Math.round(0x18 * p)));

        // categories (sidebar)
        for (int i = 0; i < TABS.length; i++) {
            int sy = y + SIDE_Y + i * SIDE_STEP;
            boolean sel = i == tab;
            Draw.roundRect(ctx, x + SIDE_X, sy, SIDE_W, SIDE_H, 6,
                    sel ? Theme.alpha(accent, Math.round(0x66 * p)) : Theme.alpha(0xFFFFFF, Math.round(0x0C * p)));
            ctx.drawTextWithShadow(textRenderer, Fonts.text(TABS[i]), x + SIDE_X + 10, sy + 8,
                    Theme.alpha(0xFFFFFF, sel ? ta : Math.round(0x90 * p)));
        }

        // module cards
        Row hot = cardAt(mx, my);
        for (int i = 0; i < cards.size(); i++) {
            Row row = cards.get(i);
            int cx = cardX(x, i);
            int cy = cardY(y, i);
            if (!cardVisible(y, cy)) continue;

            boolean isHot = row == hot;
            boolean on = row.on != null && row.on.getAsBoolean();
            Draw.roundRect(ctx, cx, cy, CARD_W, CARD_H, 7,
                    Theme.alpha(0xFFFFFF, Math.round((isHot ? 0x22 : 0x0E) * p)));
            Draw.roundRect(ctx, cx, cy + 6, 2, CARD_H - 12, 1,
                    Theme.alpha(on ? accent : 0xFFFFFF, Math.round((on ? 255 : 0x30) * p)));

            ctx.drawTextWithShadow(textRenderer, Fonts.text(row.label), cx + 10, cy + 8,
                    Theme.alpha(0xFFFFFF, ta));
            String sub = row.on != null ? (on ? "On" : "Off") : row.value.get();
            int subColor = row.click == null ? 0x7A8089
                    : row.on != null ? (on ? accent : 0x7A8089)
                    : accent;
            ctx.drawTextWithShadow(textRenderer, Fonts.text(sub), cx + 10, cy + 22, Theme.alpha(subColor, ta));

            if (row.on != null) {
                pill(ctx, cx + CARD_W - 36, cy + 14, on, accent, p);
            }
        }

        // scroll indicator
        if (maxScroll() > 0) {
            int track = GRID_BOTTOM - GRID_Y;
            int thumb = Math.max(18, track * track / contentHeight);
            int ty = y + GRID_Y + (track - thumb) * scroll / maxScroll();
            Draw.roundRect(ctx, x + W - 8, ty, 3, thumb, 1, Theme.alpha(0xFFFFFF, Math.round(0x40 * p)));
        }

        ctx.drawCenteredTextWithShadow(textRenderer,
                Fonts.text("Click a card to open it  |  Wheel scrolls  |  Esc closes"),
                x + W / 2, y + H - 16, Theme.alpha(0x7A8089, ta));

        if (popup != null) drawPopup(ctx, x, y, accent, p, ta);

        ctx.getMatrices().pop();
    }

    /** Popup window for one module: value, switch or buttons for the actions. */
    private void drawPopup(DrawContext ctx, int x, int y, int accent, float p, int ta) {
        int px = popupX(x), py = popupY(y);
        Draw.roundRect(ctx, px + 2, py + 4, POP_W, POP_H, 8, Theme.alpha(0x000000, Math.round(0x90 * p)));
        Draw.roundRect(ctx, px, py, POP_W, POP_H, 8, Theme.alpha(0xFFFFFF, Math.round(0x30 * p)));
        Draw.roundRect(ctx, px + 1, py + 1, POP_W - 2, POP_H - 2, 7, Theme.alpha(0x0E141B, Math.round(245 * p)));

        ctx.drawTextWithShadow(textRenderer, Fonts.medium(popup.label), px + 12, py + 11, Theme.alpha(0xFFFFFF, ta));
        ctx.drawTextWithShadow(textRenderer, Fonts.text("x"), px + POP_W - 16, py + 11, Theme.alpha(0x8A9099, ta));
        ctx.fill(px + 12, py + 28, px + POP_W - 12, py + 29, Theme.alpha(0xFFFFFF, Math.round(0x22 * p)));

        ctx.drawTextWithShadow(textRenderer, Fonts.text(popup.value.get()), px + 12, py + 38,
                Theme.alpha(popup.click == null ? 0xC8CCD2 : accent, ta));

        if (popup.on != null) {
            pill(ctx, px + POP_W / 2 - 13, py + 60, popup.on.getAsBoolean(), accent, p);
        }

        if (popup.primary != null) popupButton(ctx, px + 12, py + POP_H - 32, popup.primary, accent, p, ta);
        if (popup.secondary != null) popupButton(ctx, px + POP_W - 96, py + POP_H - 32, popup.secondary, accent, p, ta);
    }

    private void popupButton(DrawContext ctx, int bx, int by, String text, int accent, float p, int ta) {
        Draw.roundRect(ctx, bx, by, 84, 22, 6, Theme.alpha(accent, Math.round(0x55 * p)));
        ctx.drawCenteredTextWithShadow(textRenderer, Fonts.text(text), bx + 42, by + 7, Theme.alpha(0xFFFFFF, ta));
    }

    /** Soft orbs on three depth layers that drift away from the cursor. */
    private void drawParallax(DrawContext ctx, int vw, int vh, int mx, int my, int accent, float p) {
        float nx = Math.max(-1f, Math.min(1f, (mx - vw / 2f) / (vw / 2f)));
        float ny = Math.max(-1f, Math.min(1f, (my - vh / 2f) / (vh / 2f)));
        // fractionX, fractionY, radius, depth
        float[][] layout = {
                {0.18f, 0.22f, 70, 14},
                {0.84f, 0.74f, 90, 24},
                {0.66f, 0.12f, 46, 9}
        };
        int[] colours = {accent, 0xFF6FF3FF, 0xFFFFFFFF};
        int[] alphas = {0x30, 0x22, 0x18};
        for (int i = 0; i < layout.length; i++) {
            float[] o = layout[i];
            int r = (int) o[2];
            int cx = Math.round(o[0] * vw - nx * o[3]);
            int cy = Math.round(o[1] * vh - ny * o[3]);
            Draw.roundRect(ctx, cx - r, cy - r, 2 * r, 2 * r, r,
                    Theme.alpha(colours[i], Math.round(alphas[i] * p)));
        }
    }

    /** Switch: accent track with a soft glow when on, grey when off, white knob. */
    private static void pill(DrawContext ctx, int x, int y, boolean on, int accent, float p) {
        int w = 26, h = 12;
        if (on) {
            Draw.roundRect(ctx, x - 3, y - 3, w + 6, h + 6, 9, Theme.alpha(accent, Math.round(0x22 * p)));
        }
        Draw.roundRect(ctx, x, y, w, h, 6,
                on ? Theme.alpha(accent, Math.round(0xDD * p)) : Theme.alpha(0xFFFFFF, Math.round(0x26 * p)));
        int kx = on ? x + w - h + 2 : x + 2;
        Draw.roundRect(ctx, kx, y + 2, h - 4, h - 4, 4, Theme.alpha(0xFFFFFF, Math.round(255 * p)));
    }

    private void drawSheen(DrawContext ctx, int x, int y, float p) {
        long t = System.currentTimeMillis() % 3600L;
        int bx = x - 60 + (int) (t * (W + 120) / 3600L);
        for (int i = 0; i < 3; i++) {
            int sx = bx + i * 10;
            int x1 = Math.max(sx, x + 1), x2 = Math.min(sx + 4, x + W - 1);
            if (x2 > x1) {
                ctx.fill(x1, y + 1, x2, y + H - 1, Theme.alpha(0xFFFFFF, Math.round((10 - i * 3) * p)));
            }
        }
    }

    private float openProgress() {
        if (!Settings.openAnim) return 1f;
        float t = (System.nanoTime() - openedAt) / 180_000_000f;
        t = Math.max(0f, Math.min(1f, t));
        float inv = 1f - t;
        return 1f - inv * inv * inv;
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button != 0 && button != 1) return super.mouseClicked(mouseX, mouseY, button);
        int mx = (int) Math.round(mouseX / ui), my = (int) Math.round(mouseY / ui);
        int x = left(), y = top();

        // popup window takes all clicks while it is open
        if (popup != null) {
            int px = popupX(x), py = popupY(y);
            if (inside(mx, my, px + POP_W - 22, py + 6, 16, 16)) {
                popup = null;
                return true;
            }
            if (popup.primary != null && inside(mx, my, px + 12, py + POP_H - 32, 84, 22)) {
                popup.click.accept(0);
                return true;
            }
            if (popup.secondary != null && inside(mx, my, px + POP_W - 96, py + POP_H - 32, 84, 22)) {
                popup.click.accept(1);
                return true;
            }
            if (popup.on != null && inside(mx, my, px + POP_W / 2 - 13, py + 60, 26, 12)) {
                popup.click.accept(0);
                return true;
            }
            if (!inside(mx, my, px, py, POP_W, POP_H)) popup = null;
            return true;
        }

        // categories
        for (int i = 0; i < TABS.length; i++) {
            if (inside(mx, my, x + SIDE_X, y + SIDE_Y + i * SIDE_STEP, SIDE_W, SIDE_H)) {
                tab = i;
                rebuild();
                return true;
            }
        }

        // cards: the switch toggles directly, anywhere else opens the popup
        Row row = cardAt(mx, my);
        if (row != null) {
            int i = cards.indexOf(row);
            if (row.on != null && inside(mx, my, cardX(x, i) + CARD_W - 36, cardY(y, i) + 14, 26, 12)) {
                row.click.accept(0);
            } else {
                popup = row;
            }
            return true;
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        int mx = (int) Math.round(mouseX / ui), my = (int) Math.round(mouseY / ui);
        int x = left(), y = top();
        if (inside(mx, my, x + GRID_X, y + GRID_Y, W - GRID_X, GRID_BOTTOM - GRID_Y) && verticalAmount != 0) {
            scroll = Math.max(0, Math.min(maxScroll(), scroll - (int) Math.signum(verticalAmount) * SCROLL_STEP));
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    @Override
    public void removed() {
        Config.save();
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    // ---------- tab contents ----------

    private List<Row> buildRows() {
        List<Row> r = new ArrayList<>();
        MinecraftClient mc = MinecraftClient.getInstance();

        switch (tab) {
            case 0 -> { // HUD
                r.add(header("INFO PANEL"));
                r.add(toggle("Info panel", () -> Settings.infoPanel, () -> Settings.infoPanel = !Settings.infoPanel));
                r.add(cycle("Info corner", () -> Hud.CORNER_NAMES[Settings.infoCorner],
                        d -> Settings.infoCorner = Math.floorMod(Settings.infoCorner + d, 4)));
                r.add(toggle("Game time", () -> Settings.showTime, () -> Settings.showTime = !Settings.showTime));
                r.add(toggle("Coordinates", () -> Settings.showCoords, () -> Settings.showCoords = !Settings.showCoords));
                r.add(toggle("Speed", () -> Settings.showSpeed, () -> Settings.showSpeed = !Settings.showSpeed));
                r.add(toggle("Ping", () -> Settings.showPing, () -> Settings.showPing = !Settings.showPing));
                r.add(toggle("CPS counter", () -> Settings.cps, () -> Settings.cps = !Settings.cps));
                r.add(header("OVERLAYS"));
                r.add(toggle("Compass", () -> Settings.compass, () -> Settings.compass = !Settings.compass));
                r.add(toggle("FPS graph", () -> Settings.showGraph, () -> Settings.showGraph = !Settings.showGraph));
                r.add(cycle("Graph corner", () -> Hud.CORNER_NAMES[Settings.graphCorner],
                        d -> Settings.graphCorner = Math.floorMod(Settings.graphCorner + d, 4)));
                r.add(new Row("Preset", null, () -> "< " + Settings.PRESET_NAMES[presetIndex] + " >",
                        b -> {
                            if (b == 1) {
                                presetIndex = (presetIndex + 1) % Settings.PRESET_NAMES.length;
                            } else {
                                Settings.applyPreset(presetIndex);
                                Config.save();
                            }
                        }, false));
            }
            case 1 -> { // Tools
                r.add(header("KEYSTROKES"));
                r.add(toggle("Keystrokes", () -> Settings.keystrokes, () -> Settings.keystrokes = !Settings.keystrokes));
                r.add(cycle("Keys corner", () -> Hud.CORNER_NAMES[Settings.keystrokesCorner],
                        d -> Settings.keystrokesCorner = Math.floorMod(Settings.keystrokesCorner + d, 4)));
                r.add(header("CROSSHAIR & OVERLAYS"));
                r.add(cycle("Crosshair", () -> Settings.CROSSHAIR_NAMES[Settings.crosshairStyle],
                        d -> Settings.crosshairStyle = Math.floorMod(Settings.crosshairStyle + d, Settings.CROSSHAIR_NAMES.length)));
                r.add(toggle("Hide fire overlay", () -> Settings.hideFire, () -> Settings.hideFire = !Settings.hideFire));
                r.add(toggle("Hide vignette", () -> Settings.hideVignette, () -> Settings.hideVignette = !Settings.hideVignette));
                r.add(header("ZOOM"));
                r.add(toggle("Zoom (hold C)", () -> Settings.zoomEnabled, () -> Settings.zoomEnabled = !Settings.zoomEnabled));
                r.add(slider("Zoom FOV", () -> Settings.zoomFov, v -> Settings.zoomFov = v, 30, 70, 5, ""));
                r.add(header("SESSION"));
                r.add(toggle("Session timer", () -> Settings.showSession, () -> Settings.showSession = !Settings.showSession));
                r.add(toggle("Waypoints (M)", () -> Settings.showWaypoint, () -> Settings.showWaypoint = !Settings.showWaypoint));
                r.add(new Row("Clear waypoints", null, () -> GlassMenu.waypoints().size() + " set", b -> {
                    GlassMenu.clearWaypoints();
                }, false));
                r.add(toggle("Session stats", () -> Settings.showStats, () -> Settings.showStats = !Settings.showStats));
                r.add(new Row("Reset stats", null, () -> "click", b -> {
                    GlassMenu.resetStats();
                }, false));
                r.add(toggle("FPS / ping colors", () -> Settings.fpsColors, () -> Settings.fpsColors = !Settings.fpsColors));
            }
            case 2 -> { // Armor & potions
                r.add(header("ARMOUR"));
                r.add(toggle("Armor HUD", () -> Settings.armorHud, () -> Settings.armorHud = !Settings.armorHud));
                r.add(cycle("Armor corner", () -> Hud.CORNER_NAMES[Settings.armorCorner],
                        d -> Settings.armorCorner = Math.floorMod(Settings.armorCorner + d, 4)));
                r.add(header("POTIONS"));
                r.add(toggle("Potion HUD", () -> Settings.potionHud, () -> Settings.potionHud = !Settings.potionHud));
                r.add(cycle("Potion corner", () -> Hud.CORNER_NAMES[Settings.potionCorner],
                        d -> Settings.potionCorner = Math.floorMod(Settings.potionCorner + d, 4)));
            }
            case 3 -> { // Fx
                r.add(header("TRAIL & HITS"));
                r.add(cycle("Trail", () -> Settings.TRAIL_NAMES[Settings.trailMode],
                        d -> Settings.trailMode = Math.floorMod(Settings.trailMode + d, Settings.TRAIL_NAMES.length)));
                r.add(cycle("Hit effect", () -> Settings.HIT_NAMES[Settings.hitMode],
                        d -> Settings.hitMode = Math.floorMod(Settings.hitMode + d, Settings.HIT_NAMES.length)));
                r.add(header("NEON HAT"));
                r.add(cycle("Hat style", () -> Settings.HAT_NAMES[Settings.hatMode],
                        d -> Settings.hatMode = Math.floorMod(Settings.hatMode + d, Settings.HAT_NAMES.length)));
                r.add(slider("Hat size", () -> Settings.hatSize, v -> Settings.hatSize = v, 1, 3, 1, ""));
                r.add(toggle("Hat gradient", () -> Settings.hatGradient, () -> Settings.hatGradient = !Settings.hatGradient));
                r.add(header("WINGS & JUMP"));
                r.add(toggle("Particle wings", () -> Settings.wings, () -> Settings.wings = !Settings.wings));
                r.add(toggle("Jump burst", () -> Settings.jumpFx, () -> Settings.jumpFx = !Settings.jumpFx));
                r.add(header("WEATHER"));
                r.add(cycle("Weather", () -> Settings.WEATHER_NAMES[Settings.weatherMode],
                        d -> Settings.weatherMode = Math.floorMod(Settings.weatherMode + d, Settings.WEATHER_NAMES.length)));
                r.add(slider("Weather density", () -> Settings.weatherDensity, v -> Settings.weatherDensity = v, 1, 10, 1, ""));
                r.add(header("ACCENT"));
                r.add(toggle("Rainbow accent", () -> Settings.rainbow, () -> Settings.rainbow = !Settings.rainbow));
                r.add(cycle("Accent", () -> Settings.ACCENT_NAMES[Settings.accentIndex],
                        d -> Settings.accentIndex = Math.floorMod(Settings.accentIndex + d, Settings.ACCENTS.length)));
            }
            case 4 -> { // Glass
                r.add(header("PULSE"));
                r.add(new Row("Apply Pulse dark theme", null, () -> "click", b -> {
                    Settings.applyPulseTheme();
                    Config.save();
                }, false));
                r.add(header("HUD LOOK"));
                r.add(slider("HUD opacity", () -> Settings.hudAlpha, v -> Settings.hudAlpha = v, 0, 100, 10, "%"));
                r.add(cycle("HUD scale", () -> Settings.hudScale + "%",
                        d -> {
                            int i = 0;
                            for (int k = 0; k < Settings.HUD_SCALES.length; k++) {
                                if (Settings.HUD_SCALES[k] == Settings.hudScale) i = k;
                            }
                            i = Math.floorMod(i + d, Settings.HUD_SCALES.length);
                            Settings.hudScale = Settings.HUD_SCALES[i];
                        }));
                r.add(toggle("HUD accent bar", () -> Settings.hudAccentBar, () -> Settings.hudAccentBar = !Settings.hudAccentBar));
                r.add(header("NIGHT"));
                r.add(toggle("Brightness boost", () -> Settings.brightBoost, () -> Settings.brightBoost = !Settings.brightBoost));
                r.add(header("PANEL"));
                r.add(slider("Opacity", () -> Settings.glassAlpha, v -> Settings.glassAlpha = v, 20, 100, 5, "%"));
                r.add(slider("Corner radius", () -> Settings.cornerRadius, v -> Settings.cornerRadius = v, 0, 12, 1, "px"));
                r.add(toggle("Sheen", () -> Settings.sheen, () -> Settings.sheen = !Settings.sheen));
                r.add(toggle("Parallax", () -> Settings.parallax, () -> Settings.parallax = !Settings.parallax));
                r.add(toggle("Open animation", () -> Settings.openAnim, () -> Settings.openAnim = !Settings.openAnim));
            }
            default -> { // Info
                r.add(header("KEYS"));
                r.add(info("Menu key", () -> GlassMenu.openKey().getBoundKeyLocalizedText().getString()));
                r.add(info("Zoom key", () -> GlassMenu.zoomKey().getBoundKeyLocalizedText().getString() + " (hold)"));
                r.add(info("Hide HUD", () -> GlassMenu.hudKey().getBoundKeyLocalizedText().getString()));
                r.add(info("Waypoint / copy", () -> "M / N"));
                r.add(header("ACTIONS"));
                r.add(new Row("Controls", null, () -> "open",
                        b -> mc.setScreen(new KeybindsScreen(this, mc.options)), false));
                r.add(new Row("Reset settings", null, () -> "click", b -> {
                    Settings.resetDefaults();
                    Config.save();
                }, false));
                r.add(info("Config file", () -> "glassmenu.json"));
            }
        }
        return r;
    }

    private static Row header(String title) {
        Row r = new Row(title, null, null, null, true);
        return r;
    }

    private static Row toggle(String label, BooleanSupplier get, Runnable flip) {
        return new Row(label, get, null, b -> {
            flip.run();
            Config.save();
        }, false);
    }

    /** Left click / right click step through values. step receives +1 or -1. */
    private static Row cycle(String label, Supplier<String> value, IntConsumer step) {
        return new Row(label, null, value, b -> {
            step.accept(b == 1 ? -1 : 1);
            Config.save();
        }, false);
    }

    /** Left click increases, right click decreases. */
    private static Row slider(String label, IntSupplier get, IntConsumer set, int min, int max, int step, String suffix) {
        IntConsumer adjust = d -> {
            set.accept(Math.max(min, Math.min(max, get.getAsInt() + d * step)));
            Config.save();
        };
        return new Row(label, null, () -> "< " + get.getAsInt() + suffix + " >",
                b -> adjust.accept(b == 1 ? -1 : 1), false).labels("+", "-");
    }

    private static Row info(String label, Supplier<String> value) {
        return new Row(label, null, value, null, false);
    }

    /** Labels of the actions that run once; the popup shows a single "Run" button for them. */
    private static final Set<String> ACTIONS = Set.of(
            "Apply Pulse dark theme", "Clear waypoints", "Reset stats", "Controls", "Reset settings");

    private static final class Row {
        final String label;
        final BooleanSupplier on;   // if not null the row is a switch
        final Supplier<String> value;
        final IntConsumer click;    // receives the mouse button (0 left, 1 right); null = info only
        final boolean header;
        String primary;             // popup button for mouse button 0
        String secondary;           // popup button for mouse button 1, may be null

        Row(String label, BooleanSupplier on, Supplier<String> value, IntConsumer click, boolean header) {
            this.label = label;
            this.on = on;
            this.value = value;
            this.click = click;
            this.header = header;
            if (on != null) {
                primary = "Toggle";
                secondary = null;
            } else if (label.equals("Preset")) {
                primary = "Apply";
                secondary = "Next";
            } else if (ACTIONS.contains(label)) {
                primary = "Run";
                secondary = null;
            } else {
                primary = "Next";
                secondary = "Prev";
            }
        }

        Row labels(String p, String s) {
            primary = p;
            secondary = s;
            return this;
        }
    }
}
