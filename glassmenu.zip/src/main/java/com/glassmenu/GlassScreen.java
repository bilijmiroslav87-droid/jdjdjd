package com.glassmenu;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.option.KeybindsScreen;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.function.BooleanSupplier;
import java.util.function.IntConsumer;
import java.util.function.IntFunction;
import java.util.function.IntSupplier;
import java.util.function.Supplier;

public class GlassScreen extends Screen {
    // Window size in virtual pixels; the whole window is scaled by ui to fit the screen.
    private static final int W = 640, H = 420;
    private static final String[] TABS = {"HUD", "World", "Hands", "Fx", "Tools", "Settings"};

    // Left sidebar (150 px) with a vertical list of categories
    private static final int SIDE_W = 150;
    private static final int NAV_X = 10, NAV_Y = 58, NAV_H = 28, NAV_STEP = 32;

    // Content: 2 x N grid of cards on the right
    private static final int GRID_X = SIDE_W + 20, GRID_Y = 58, GRID_BOTTOM = H - 14;
    private static final int GRID_W = W - GRID_X - 16;
    private static final int CARD_GAP = 10, CARD_W = (GRID_W - CARD_GAP) / 2, CARD_H = 54;
    private static final int CARD_STEP = CARD_H + CARD_GAP;
    private static final int SCROLL_STEP = 14;
    private static final int POP_W = 210, POP_H = 136;

    // Colours. The only accent is UI_ACCENT and it is used for active switches only.
    private static final int CARD_BG = 0xFFFFFF;          // card fill: RGBA(255, 255, 255, 6)
    private static final int CARD_BG_ALPHA = 6;
    private static final int BODY = 0x0C0C10;             // window fill: RGBA(12, 12, 16, 220)
    private static final int BODY_ALPHA = 220;
    private static final int UI_ACCENT = 0xFF8B5CF6;
    private static final int TEXT = 0xF2F2F5, TEXT_DIM = 0x8A8F98;

    private int tab = 0;
    private List<Row> cards = new ArrayList<>();
    private int contentHeight;
    private int scroll;
    private int presetIndex;
    private Row popup;
    private float ui = 1f;
    private final long openedAt = System.nanoTime();
    private long lastFrame = System.nanoTime();
    private float frameDt = 0f;
    private final float[] navAlpha = new float[TABS.length];

    public GlassScreen() {
        super(net.minecraft.text.Text.literal("Glass Menu"));
        for (int i = 0; i < navAlpha.length; i++) navAlpha[i] = 0.45f;
    }

    @Override
    protected void init() {
        ui = computeUi();
        rebuild();
    }

    private float computeUi() {
        float s = Math.min(width / (float) (W + 40), height / (float) (H + 40));
        return Math.max(1f, Math.min(1.5f, s));
    }

    private int vWidth() { return Math.round(width / ui); }
    private int vHeight() { return Math.round(height / ui); }
    private int left() { return (vWidth() - W) / 2; }
    private int top() { return (vHeight() - H) / 2; }

    private void rebuild() {
        cards = new ArrayList<>();
        for (Row r : buildRows()) {
            if (!r.header) cards.add(r);
        }
        scroll = 0;
        popup = null;
        int rowCount = (cards.size() + 1) / 2;
        contentHeight = rowCount == 0 ? 0 : (rowCount - 1) * CARD_STEP + CARD_H;
    }

    private int maxScroll() {
        return Math.max(0, contentHeight - (GRID_BOTTOM - GRID_Y));
    }

    private int cardX(int x, int i) { return x + GRID_X + (i % 2) * (CARD_W + CARD_GAP); }
    private int cardY(int y, int i) { return y + GRID_Y + (i / 2) * CARD_STEP - scroll; }
    private boolean cardVisible(int y, int cy) { return cy >= y + GRID_Y && cy + CARD_H <= y + GRID_BOTTOM; }

    private int popupX(int x) { return x + (W - POP_W) / 2; }
    private int popupY(int y) { return y + (H - POP_H) / 2; }

    private static boolean inside(int mx, int my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    private Row cardAt(int mx, int my) {
        int x = left(), y = top();
        for (int i = 0; i < cards.size(); i++) {
            Row row = cards.get(i);
            if (row.click == null) continue;
            int cx = cardX(x, i), cy = cardY(y, i);
            if (cardVisible(y, cy) && inside(mx, my, cx, cy, CARD_W, CARD_H)) return row;
        }
        return null;
    }

    /** Category index under a point in virtual coordinates, or -1. */
    private int navAt(int mx, int my) {
        int x = left(), y = top();
        for (int i = 0; i < TABS.length; i++) {
            if (inside(mx, my, x + NAV_X, y + NAV_Y + i * NAV_STEP, SIDE_W - NAV_X * 2, NAV_H)) return i;
        }
        return -1;
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        ui = computeUi();
        long now = System.nanoTime();
        frameDt = Math.min(0.05f, (now - lastFrame) / 1_000_000_000f);
        lastFrame = now;

        float p = openProgress();
        int vw = vWidth(), vh = vHeight();
        int x = left();
        int y = top() + Math.round((1f - p) * 12f);
        int ta = Math.round(255 * p);
        int mx = Math.round(mouseX / ui), my = Math.round(mouseY / ui);
        int hotNav = navAt(mx, my);

        ctx.getMatrices().push();
        ctx.getMatrices().scale(ui, ui, 1f);

        // dim backdrop, shadow, thin border, matte body
        if (Settings.menuBlur) {
            renderBackground(ctx, mouseX, mouseY, delta);   // the game's own menu background blur
        }
        ctx.fill(0, 0, vw, vh, Theme.alpha(0x000000, Math.round((Settings.menuBlur ? 0x18 : 0x66) * p)));
        Draw.shadow(ctx, x, y, W, H, 12, 0x000000, Math.round(0xB0 * p), 16);
        Draw.roundRect(ctx, x, y, W, H, 12, Theme.alpha(0xFFFFFF, Math.round(0x1A * p)));
        Draw.roundRect(ctx, x + 1, y + 1, W - 2, H - 2, 11, Theme.alpha(BODY, Math.round(BODY_ALPHA * p)));

        // sidebar: title and a vertical list of categories
        ctx.drawTextWithShadow(textRenderer, Fonts.display("GLASS MENU"), x + NAV_X + 2, y + 20,
                Theme.alpha(TEXT, ta));
        ctx.fill(x + SIDE_W, y + 16, x + SIDE_W + 1, y + H - 16, Theme.alpha(0xFFFFFF, Math.round(0x14 * p)));

        for (int i = 0; i < TABS.length; i++) {
            float target = i == tab ? 1f : (i == hotNav ? 0.9f : 0.45f);
            navAlpha[i] += (target - navAlpha[i]) * Math.min(1f, frameDt * 10f);
            int ny = y + NAV_Y + i * NAV_STEP;
            if (i == tab) {
                Draw.roundRect(ctx, x + NAV_X, ny, SIDE_W - NAV_X * 2, NAV_H, 8,
                        Theme.alpha(0xFFFFFF, Math.round(12 * p)));
                Draw.roundRect(ctx, x + NAV_X, ny + 7, 2, NAV_H - 14, 1,
                        Theme.alpha(0xFFFFFF, Math.round(0xE0 * p)));
            }
            int alpha = Math.round(255 * navAlpha[i] * p);
            ctx.drawTextWithShadow(textRenderer, Fonts.text(TABS[i]), x + NAV_X + 12, ny + 9,
                    Theme.alpha(TEXT, alpha));
        }

        // content header
        ctx.drawTextWithShadow(textRenderer, Fonts.display(TABS[tab]), x + GRID_X, y + 20, Theme.alpha(TEXT, ta));
        ctx.drawTextWithShadow(textRenderer, Fonts.text(cards.size() + " options"), x + GRID_X, y + 36,
                Theme.alpha(TEXT_DIM, ta));

        // cards
        Row hot = cardAt(mx, my);
        for (int i = 0; i < cards.size(); i++) {
            Row row = cards.get(i);
            int cx = cardX(x, i), cy = y + GRID_Y + (i / 2) * CARD_STEP - scroll;
            if (!cardVisible(y, cy)) continue;
            drawCard(ctx, row, cx, cy, row == hot, p, ta);
        }

        if (maxScroll() > 0) {
            int track = GRID_BOTTOM - GRID_Y;
            int thumb = Math.max(18, track * track / contentHeight);
            int ty = y + GRID_Y + (track - thumb) * scroll / maxScroll();
            Draw.roundRect(ctx, x + W - 7, ty, 3, thumb, 1, Theme.alpha(0xFFFFFF, Math.round(0x30 * p)));
        }

        if (popup != null) drawPopup(ctx, x, y, p, ta);

        ctx.getMatrices().pop();
    }

    /** Card: rounded quad with RGBA(20, 20, 25, 180), thin border, label, state and a smooth switch. */
    private void drawCard(DrawContext ctx, Row row, int cx, int cy, boolean hot, float p, int ta) {
        boolean on = row.on != null && row.on.getAsBoolean();
        if (hot) Draw.shadow(ctx, cx, cy, CARD_W, CARD_H, 10, 0xFFFFFF, Math.round(0x12 * p), 4);
        Draw.roundRect(ctx, cx, cy, CARD_W, CARD_H, 8, Theme.alpha(0xFFFFFF, Math.round((hot ? 0x26 : 0x18) * p)));
        Draw.roundRect(ctx, cx + 1, cy + 1, CARD_W - 2, CARD_H - 2, 7,
                Theme.alpha(CARD_BG, Math.round(CARD_BG_ALPHA * p)));

        ctx.drawTextWithShadow(textRenderer, Fonts.text(row.label), cx + 12, cy + 12, Theme.alpha(TEXT, ta));

        String sub = row.on != null ? (on ? "On" : "Off") : row.value.get();
        ctx.drawTextWithShadow(textRenderer, Fonts.text(sub), cx + 12, cy + 28, Theme.alpha(TEXT_DIM, ta));

        if (row.on != null) {
            float target = on ? 1f : 0f;
            row.anim += (target - row.anim) * Math.min(1f, frameDt * 14f);
            drawSwitch(ctx, cx + CARD_W - 42, cy + 19, row.anim, p);
        }
        if (row.sliderGet != null) {
            int bx = cx + 12, by = cy + CARD_H - 9, bw = CARD_W - 24;
            Draw.roundRect(ctx, bx, by, bw, 3, 1, Theme.alpha(0xFFFFFF, Math.round(0x22 * p)));
            float t = (row.sliderGet.getAsInt() - row.sliderMin) / (float) Math.max(1, row.sliderMax - row.sliderMin);
            int fw = Math.max(3, Math.round(bw * Math.max(0f, Math.min(1f, t))));
            Draw.roundRect(ctx, bx, by, fw, 3, 1, Theme.alpha(0xFFFFFF, Math.round(0xD0 * p)));
        }
    }

    /** Smooth switch: track colour and knob position follow an animation value in [0, 1]. */
    private static void drawSwitch(DrawContext ctx, int x, int y, float anim, float p) {
        int w = 30, h = 16;
        int track = Draw.lerpArgb(Theme.alpha(0xFFFFFF, 0x30), Theme.alpha(UI_ACCENT, 0xFF), Math.max(0f, Math.min(1f, anim)));
        Draw.roundRect(ctx, x, y, w, h, 8, Theme.alpha(track, Math.round(255 * p)));
        float travel = w - h + 2 - 2;
        int kx = Math.round(x + 2 + travel * anim);
        Draw.roundRect(ctx, kx, y + 2, h - 4, h - 4, 6, Theme.alpha(0xFFFFFF, Math.round(255 * p)));
    }

    private void drawPopup(DrawContext ctx, int x, int y, float p, int ta) {
        int px = popupX(x), py = popupY(y);
        Draw.shadow(ctx, px, py, POP_W, POP_H, 12, 0x000000, Math.round(0xC0 * p), 16);
        Draw.roundRect(ctx, px, py, POP_W, POP_H, 12, Theme.alpha(0xFFFFFF, Math.round(0x1A * p)));
        Draw.roundRect(ctx, px + 1, py + 1, POP_W - 2, POP_H - 2, 11, Theme.alpha(0x14161C, Math.round(0xF8 * p)));

        ctx.drawTextWithShadow(textRenderer, Fonts.medium(popup.label), px + 14, py + 13, Theme.alpha(TEXT, ta));
        ctx.drawTextWithShadow(textRenderer, Fonts.text("x"), px + POP_W - 18, py + 13, Theme.alpha(TEXT_DIM, ta));
        ctx.fill(px + 14, py + 30, px + POP_W - 14, py + 31, Theme.alpha(0xFFFFFF, Math.round(0x18 * p)));

        ctx.drawTextWithShadow(textRenderer, Fonts.text(popup.value.get()), px + 14, py + 40,
                Theme.alpha(TEXT_DIM, ta));

        if (popup.on != null) {
            drawSwitch(ctx, px + POP_W / 2 - 15, py + 60, popup.anim, p);
        }
        if (popup.primary != null) popupButton(ctx, px + 14, py + POP_H - 36, popup.primary, p, ta);
        if (popup.secondary != null) popupButton(ctx, px + POP_W - 98, py + POP_H - 36, popup.secondary, p, ta);
    }

    private void popupButton(DrawContext ctx, int bx, int by, String text, float p, int ta) {
        Draw.roundRect(ctx, bx, by, 84, 24, 8, Theme.alpha(0xFFFFFF, Math.round(0x1C * p)));
        ctx.drawCenteredTextWithShadow(textRenderer, Fonts.text(text), bx + 42, by + 8, Theme.alpha(TEXT, ta));
    }

    private float openProgress() {
        if (!Settings.openAnim) return 1f;
        float t = (System.nanoTime() - openedAt) / 180_000_000f;
        t = Math.max(0f, Math.min(1f, t));
        float inv = 1f - t;
        return 1f - inv * inv * inv;
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button != 0 && button != 1) return super.mouseClicked(mouseX, mouseY, button);
        int mx = (int) Math.round(mouseX / ui), my = (int) Math.round(mouseY / ui);
        int x = left(), y = top();

        if (popup != null) {
            int px = popupX(x), py = popupY(y);
            if (inside(mx, my, px + POP_W - 24, py + 8, 16, 16)) {
                popup = null;
                return true;
            }
            if (popup.primary != null && inside(mx, my, px + 14, py + POP_H - 36, 84, 24)) {
                popup.click.accept(0);
                return true;
            }
            if (popup.secondary != null && inside(mx, my, px + POP_W - 98, py + POP_H - 36, 84, 24)) {
                popup.click.accept(1);
                return true;
            }
            if (popup.on != null && inside(mx, my, px + POP_W / 2 - 15, py + 60, 30, 16)) {
                popup.click.accept(0);
                return true;
            }
            if (!inside(mx, my, px, py, POP_W, POP_H)) popup = null;
            return true;
        }

        int t = navAt(mx, my);
        if (t >= 0) {
            tab = t;
            rebuild();
            return true;
        }

        Row row = cardAt(mx, my);
        if (row != null) {
            int i = cards.indexOf(row);
            if (row.on != null && inside(mx, my, cardX(x, i) + CARD_W - 42, cardY(y, i) + 19, 30, 16)) {
                row.click.accept(0);
            } else {
                popup = row;
            }
            return true;
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        int mx = (int) Math.round(mouseX / ui), my = (int) Math.round(mouseY / ui);
        int x = left(), y = top();
        if (inside(mx, my, x + GRID_X, y + GRID_Y, GRID_W, GRID_BOTTOM - GRID_Y) && verticalAmount != 0) {
            scroll = Math.max(0, Math.min(maxScroll(), scroll - (int) Math.signum(verticalAmount) * SCROLL_STEP));
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    @Override
    public void removed() {
        Config.save();
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    // ---------- tab contents ----------

    private static String clock(int hour) {
        return String.format("%02d:00", (hour + 6) % 24);
    }

    private List<Row> buildRows() {
        List<Row> r = new ArrayList<>();
        MinecraftClient mc = MinecraftClient.getInstance();

        switch (tab) {
            case 0 -> { // HUD
                r.add(toggle("FPS / Ping pill", () -> Settings.pillEnabled, () -> Settings.pillEnabled = !Settings.pillEnabled));
                r.add(cycle("Pill corner", () -> Hud.CORNER_NAMES[Settings.pillCorner],
                        d -> Settings.pillCorner = Math.floorMod(Settings.pillCorner + d, 4)));
                r.add(toggle("Show ping", () -> Settings.showPing, () -> Settings.showPing = !Settings.showPing));
                r.add(toggle("Status colors", () -> Settings.fpsColors, () -> Settings.fpsColors = !Settings.fpsColors));
                r.add(toggle("Keybinds list", () -> Settings.keybindsHud, () -> Settings.keybindsHud = !Settings.keybindsHud));
                r.add(cycle("Keybinds corner", () -> Hud.CORNER_NAMES[Settings.keybindsCorner],
                        d -> Settings.keybindsCorner = Math.floorMod(Settings.keybindsCorner + d, 4)));
            }
            case 1 -> { // World
                r.add(toggle("Custom time", () -> Settings.customTime, () -> Settings.customTime = !Settings.customTime));
                r.add(slider("Time of day", () -> Settings.timeHour, v -> Settings.timeHour = v, 0, 23, 1, GlassScreen::clock));
                r.add(cycle("Weather", () -> Settings.WEATHER_NAMES[Settings.weatherOverride],
                        d -> Settings.weatherOverride = Math.floorMod(Settings.weatherOverride + d, Settings.WEATHER_NAMES.length)));
                r.add(toggle("Sky color", () -> Settings.tintSky, () -> Settings.tintSky = !Settings.tintSky));
                r.add(toggle("Fog color", () -> Settings.tintFog, () -> Settings.tintFog = !Settings.tintFog));
                r.add(cycle("Tint", () -> Settings.TINT_NAMES[Settings.tintIndex],
                        d -> Settings.tintIndex = Math.floorMod(Settings.tintIndex + d, Settings.TINT_COLORS.length)));
                r.add(slider("Tint strength", () -> Settings.tintStrength, v -> Settings.tintStrength = v, 0, 100, 10, "%"));
                r.add(toggle("Brightness boost", () -> Settings.brightBoost, () -> Settings.brightBoost = !Settings.brightBoost));
            }
            case 2 -> { // Hands and items
                r.add(toggle("Custom hands", () -> Settings.customHands, () -> Settings.customHands = !Settings.customHands));
                r.add(slider("Hand X", () -> Settings.handX, v -> Settings.handX = v, -50, 50, 5, " cm"));
                r.add(slider("Hand Y", () -> Settings.handY, v -> Settings.handY = v, -50, 50, 5, " cm"));
                r.add(slider("Hand depth", () -> Settings.handZ, v -> Settings.handZ = v, -50, 50, 5, " cm"));
                r.add(slider("Hand scale", () -> Settings.handScale, v -> Settings.handScale = v, 50, 150, 10, "%"));
                r.add(toggle("Item physics (still)", () -> Settings.itemPhysics, () -> Settings.itemPhysics = !Settings.itemPhysics));
            }
            case 3 -> { // Fx
                r.add(cycle("Trail", () -> Settings.TRAIL_NAMES[Settings.trailMode],
                        d -> Settings.trailMode = Math.floorMod(Settings.trailMode + d, Settings.TRAIL_NAMES.length)));
                r.add(cycle("Hit effect", () -> Settings.HIT_NAMES[Settings.hitMode],
                        d -> Settings.hitMode = Math.floorMod(Settings.hitMode + d, Settings.HIT_NAMES.length)));
                r.add(cycle("Particles", () -> Settings.PARTICLE_WEATHER_NAMES[Settings.weatherMode],
                        d -> Settings.weatherMode = Math.floorMod(Settings.weatherMode + d, Settings.PARTICLE_WEATHER_NAMES.length)));
                r.add(slider("Particle density", () -> Settings.weatherDensity, v -> Settings.weatherDensity = v, 1, 10, 1, ""));
                r.add(cycle("Hat style", () -> Settings.HAT_NAMES[Settings.hatMode],
                        d -> Settings.hatMode = Math.floorMod(Settings.hatMode + d, Settings.HAT_NAMES.length)));
                r.add(slider("Hat size", () -> Settings.hatSize, v -> Settings.hatSize = v, 1, 3, 1, ""));
                r.add(toggle("Hat gradient", () -> Settings.hatGradient, () -> Settings.hatGradient = !Settings.hatGradient));
                r.add(toggle("Particle wings", () -> Settings.wings, () -> Settings.wings = !Settings.wings));
                r.add(toggle("Jump burst", () -> Settings.jumpFx, () -> Settings.jumpFx = !Settings.jumpFx));
            }
            case 4 -> { // Tools
                r.add(toggle("Zoom", () -> Settings.zoomEnabled, () -> Settings.zoomEnabled = !Settings.zoomEnabled));
                r.add(slider("Zoom FOV", () -> Settings.zoomFov, v -> Settings.zoomFov = v, 30, 70, 5, ""));
                r.add(cycle("Crosshair", () -> Settings.CROSSHAIR_NAMES[Settings.crosshairStyle],
                        d -> Settings.crosshairStyle = Math.floorMod(Settings.crosshairStyle + d, Settings.CROSSHAIR_NAMES.length)));
                r.add(toggle("Hide fire overlay", () -> Settings.hideFire, () -> Settings.hideFire = !Settings.hideFire));
                r.add(toggle("Hide vignette", () -> Settings.hideVignette, () -> Settings.hideVignette = !Settings.hideVignette));
            }
            default -> { // Settings
                r.add(cycle("Accent", () -> Settings.ACCENT_NAMES[Settings.accentIndex],
                        d -> Settings.accentIndex = Math.floorMod(Settings.accentIndex + d, Settings.ACCENTS.length)));
                r.add(toggle("Rainbow accent", () -> Settings.rainbow, () -> Settings.rainbow = !Settings.rainbow));
                r.add(toggle("Menu blur", () -> Settings.menuBlur, () -> Settings.menuBlur = !Settings.menuBlur));
                r.add(toggle("Open animation", () -> Settings.openAnim, () -> Settings.openAnim = !Settings.openAnim));
                r.add(info("Menu key", () -> GlassMenu.openKey().getBoundKeyLocalizedText().getString()));
                r.add(info("Zoom key", () -> GlassMenu.zoomKey().getBoundKeyLocalizedText().getString()));
                r.add(info("Hide HUD key", () -> GlassMenu.hudKey().getBoundKeyLocalizedText().getString()));
                r.add(new Row("Controls", null, () -> "open",
                        b -> mc.setScreen(new KeybindsScreen(this, mc.options)), false));
                r.add(new Row("Reset settings", null, () -> "click", b -> {
                    Settings.resetDefaults();
                    Config.save();
                    rebuild();
                }, false));
            }
        }
        return r;
    }

    private static Row toggle(String label, BooleanSupplier get, Runnable flip) {
        return new Row(label, get, null, b -> {
            flip.run();
            Config.save();
        }, false);
    }

    /** Left click steps forward, right click steps back. */
    private static Row cycle(String label, Supplier<String> value, IntConsumer step) {
        return new Row(label, null, value, b -> {
            step.accept(b == 1 ? -1 : 1);
            Config.save();
        }, false);
    }

    private static Row slider(String label, IntSupplier get, IntConsumer set, int min, int max, int step,
                              IntFunction<String> fmt) {
        IntConsumer adjust = d -> {
            set.accept(Math.max(min, Math.min(max, get.getAsInt() + d * step)));
            Config.save();
        };
        return new Row(label, null, () -> "< " + fmt.apply(get.getAsInt()) + " >",
                b -> adjust.accept(b == 1 ? -1 : 1), false).labels("+", "-").range(min, max, get);
    }

    private static Row slider(String label, IntSupplier get, IntConsumer set, int min, int max, int step,
                              String suffix) {
        return slider(label, get, set, min, max, step, v -> v + suffix);
    }

    private static Row info(String label, Supplier<String> value) {
        return new Row(label, null, value, null, false);
    }

    /** Labels of the actions that run once; the popup shows a single "Run" button for them. */
    private static final Set<String> ACTIONS = Set.of("Controls", "Reset settings");

    private static final class Row {
        final String label;
        final BooleanSupplier on;
        final Supplier<String> value;
        final IntConsumer click;
        final boolean header;
        String primary;
        String secondary;
        IntSupplier sliderGet;
        int sliderMin, sliderMax;
        float anim;                 // switch animation, 0 = off, 1 = on

        Row(String label, BooleanSupplier on, Supplier<String> value, IntConsumer click, boolean header) {
            this.label = label;
            this.on = on;
            this.value = value;
            this.click = click;
            this.header = header;
            if (on != null) {
                primary = "Toggle";
                secondary = null;
                anim = on.getAsBoolean() ? 1f : 0f;
            } else if (label.equals("Preset")) {
                primary = "Apply";
                secondary = "Next";
            } else if (ACTIONS.contains(label)) {
                primary = "Run";
                secondary = null;
            } else {
                primary = "Next";
                secondary = "Prev";
            }
        }

        Row labels(String p, String s) {
            primary = p;
            secondary = s;
            return this;
        }

        Row range(int min, int max, IntSupplier get) {
            sliderMin = min;
            sliderMax = max;
            sliderGet = get;
            return this;
        }
    }
}
