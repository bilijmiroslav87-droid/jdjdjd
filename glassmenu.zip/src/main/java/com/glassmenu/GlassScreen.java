package com.glassmenu;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.option.KeybindsScreen;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BooleanSupplier;
import java.util.function.IntConsumer;
import java.util.function.IntSupplier;
import java.util.function.Supplier;

public class GlassScreen extends Screen {
    private static final int W = 300, H = 252;
    private static final String[] TABS = {"HUD", "Tools", "Fx", "Glass", "Info"};
    private static final int TAB_W = 52, TAB_GAP = 3, TAB_Y = 32, TAB_H = 16;
    private static final int ROW_Y = 62, ROW_H = 22, ROW_STEP = 26;

    private int tab = 0;
    private List<Row> rows;
    private final long openedAt = System.nanoTime();

    public GlassScreen() {
        super(Text.literal("Glass Menu"));
    }

    @Override
    protected void init() {
        rows = buildRows();
    }

    private int left() { return (width - W) / 2; }
    private int top() { return (height - H) / 2; }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        if (rows == null) rows = buildRows();

        float p = openProgress();
        int x = left();
        int y = top() + Math.round((1f - p) * 12f);
        int accent = Theme.accent();
        int r = Settings.cornerRadius;
        int ir = Math.max(0, r - 1);
        int ta = Math.round(255 * p);

        // dim background
        ctx.fill(0, 0, width, height, Theme.alpha(0x000000, Math.round(0x66 * p)));

        // glass body: border, tinted body, top gloss
        Draw.roundRect(ctx, x, y, W, H, r, Theme.alpha(0xFFFFFF, Math.round(0x66 * p)));
        Draw.roundRect(ctx, x + 1, y + 1, W - 2, H - 2, ir,
                Theme.alpha(0x101820, Math.round(Settings.glassAlpha * 2.55f * p)));
        Draw.roundRect(ctx, x + 1, y + 1, W - 2, H / 2 - 1, ir, Theme.alpha(0xFFFFFF, Math.round(0x22 * p)));

        if (Settings.sheen) drawSheen(ctx, x, y, p);

        // title + accent line
        ctx.drawCenteredTextWithShadow(textRenderer, Text.literal("Glass Menu"), width / 2, y + 10,
                Theme.alpha(0xFFFFFF, ta));
        ctx.fill(x + 16, y + 26, x + W - 16, y + 27, Theme.alpha(accent, ta));

        // tabs
        for (int i = 0; i < TABS.length; i++) {
            int tx = tabX(i);
            boolean sel = i == tab;
            Draw.roundRect(ctx, tx, y + TAB_Y, TAB_W, TAB_H, 4,
                    sel ? Theme.alpha(accent, Math.round(0x66 * p)) : Theme.alpha(0xFFFFFF, Math.round(0x1A * p)));
            ctx.drawCenteredTextWithShadow(textRenderer, Text.literal(TABS[i]), tx + TAB_W / 2, y + TAB_Y + 4,
                    Theme.alpha(0xFFFFFF, sel ? ta : Math.round(0xAA * p)));
        }

        // rows
        int hover = rowAt(mouseX, mouseY);
        for (int i = 0; i < rows.size(); i++) {
            Row row = rows.get(i);
            int ry = y + ROW_Y + i * ROW_STEP;
            boolean hot = i == hover && row.click != null;
            Draw.roundRect(ctx, x + 12, ry, W - 24, ROW_H, 4,
                    Theme.alpha(0xFFFFFF, Math.round((hot ? 0x44 : 0x18) * p)));
            Draw.roundRect(ctx, x + 12, ry + 4, 2, ROW_H - 8, 1, Theme.alpha(accent, ta));
            ctx.drawTextWithShadow(textRenderer, Text.literal(row.label), x + 22, ry + 7, Theme.alpha(0xFFFFFF, ta));

            String v = row.value.get();
            int vw = textRenderer.getWidth(v);
            int vc = row.click == null ? 0xDDDDDD : accent;
            ctx.drawTextWithShadow(textRenderer, Text.literal(v), x + W - 22 - vw, ry + 7, Theme.alpha(vc, ta));
        }

        ctx.drawCenteredTextWithShadow(textRenderer,
                Text.literal("Click or scroll to change | Esc to close"),
                width / 2, y + H - 14, Theme.alpha(0xAAAAAA, ta));

        super.render(ctx, mouseX, mouseY, delta);
    }

    /** Soft light band that slides across the panel. */
    private void drawSheen(DrawContext ctx, int x, int y, float p) {
        long t = System.currentTimeMillis() % 3600L;
        int bx = x - 60 + (int) (t * (W + 120) / 3600L);
        ctx.enableScissor(x + 1, y + 1, x + W - 1, y + H - 1);
        for (int i = 0; i < 3; i++) {
            int sx = bx + i * 10;
            ctx.fill(sx, y, sx + 4, y + H, Theme.alpha(0xFFFFFF, Math.round((18 - i * 4) * p)));
        }
        ctx.disableScissor();
    }

    private float openProgress() {
        if (!Settings.openAnim) return 1f;
        float t = (System.nanoTime() - openedAt) / 180_000_000f;
        t = Math.max(0f, Math.min(1f, t));
        float inv = 1f - t;
        return 1f - inv * inv * inv;
    }

    private int tabX(int i) {
        int total = TABS.length * TAB_W + (TABS.length - 1) * TAB_GAP;
        return left() + (W - total) / 2 + i * (TAB_W + TAB_GAP);
    }

    private int rowAt(double mx, double my) {
        if (rows == null) return -1;
        int x = left(), y = top();
        if (mx < x + 12 || mx > x + W - 12) return -1;
        for (int i = 0; i < rows.size(); i++) {
            int ry = y + ROW_Y + i * ROW_STEP;
            if (my >= ry && my <= ry + ROW_H) return i;
        }
        return -1;
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (rows == null) rows = buildRows();
        if (button == 0 || button == 1) {
            int y = top();
            for (int i = 0; i < TABS.length; i++) {
                int tx = tabX(i);
                if (mouseX >= tx && mouseX <= tx + TAB_W && mouseY >= y + TAB_Y && mouseY <= y + TAB_Y + TAB_H) {
                    tab = i;
                    rows = buildRows();
                    return true;
                }
            }
            int idx = rowAt(mouseX, mouseY);
            if (idx >= 0 && rows.get(idx).click != null) {
                rows.get(idx).click.accept(button);
                return true;
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        int idx = rowAt(mouseX, mouseY);
        if (idx >= 0 && verticalAmount != 0 && rows.get(idx).scroll != null) {
            rows.get(idx).scroll.accept(verticalAmount > 0 ? 1 : -1);
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    @Override
    public void removed() {
        Config.save();
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    // ---------- tab contents ----------

    private List<Row> buildRows() {
        List<Row> r = new ArrayList<>();
        MinecraftClient mc = MinecraftClient.getInstance();

        switch (tab) {
            case 0 -> { // HUD
                r.add(toggle("Info panel", () -> Settings.infoPanel, () -> Settings.infoPanel = !Settings.infoPanel));
                r.add(cycle("Info corner", () -> Hud.CORNER_NAMES[Settings.infoCorner],
                        d -> Settings.infoCorner = Math.floorMod(Settings.infoCorner + d, 4)));
                r.add(toggle("Coordinates", () -> Settings.showCoords, () -> Settings.showCoords = !Settings.showCoords));
                r.add(toggle("Ping", () -> Settings.showPing, () -> Settings.showPing = !Settings.showPing));
                r.add(toggle("CPS counter", () -> Settings.cps, () -> Settings.cps = !Settings.cps));
                r.add(toggle("Compass", () -> Settings.compass, () -> Settings.compass = !Settings.compass));
            }
            case 1 -> { // Tools
                r.add(toggle("Keystrokes", () -> Settings.keystrokes, () -> Settings.keystrokes = !Settings.keystrokes));
                r.add(cycle("Keys corner", () -> Hud.CORNER_NAMES[Settings.keystrokesCorner],
                        d -> Settings.keystrokesCorner = Math.floorMod(Settings.keystrokesCorner + d, 4)));
                r.add(toggle("Zoom (hold C)", () -> Settings.zoomEnabled, () -> Settings.zoomEnabled = !Settings.zoomEnabled));
                r.add(slider("Zoom FOV", () -> Settings.zoomFov, v -> Settings.zoomFov = v, 30, 70, 5, ""));
                r.add(toggle("FPS / ping colors", () -> Settings.fpsColors, () -> Settings.fpsColors = !Settings.fpsColors));
            }
            case 2 -> { // Fx
                r.add(cycle("Trail", () -> Settings.TRAIL_NAMES[Settings.trailMode],
                        d -> Settings.trailMode = Math.floorMod(Settings.trailMode + d, Settings.TRAIL_NAMES.length)));
                r.add(cycle("Hit effect", () -> Settings.HIT_NAMES[Settings.hitMode],
                        d -> Settings.hitMode = Math.floorMod(Settings.hitMode + d, Settings.HIT_NAMES.length)));
                r.add(toggle("Rainbow accent", () -> Settings.rainbow, () -> Settings.rainbow = !Settings.rainbow));
                r.add(cycle("Accent", () -> Settings.ACCENT_NAMES[Settings.accentIndex],
                        d -> Settings.accentIndex = Math.floorMod(Settings.accentIndex + d, Settings.ACCENTS.length)));
            }
            case 3 -> { // Glass
                r.add(slider("Opacity", () -> Settings.glassAlpha, v -> Settings.glassAlpha = v, 20, 100, 5, "%"));
                r.add(slider("Corner radius", () -> Settings.cornerRadius, v -> Settings.cornerRadius = v, 0, 12, 1, "px"));
                r.add(toggle("Sheen", () -> Settings.sheen, () -> Settings.sheen = !Settings.sheen));
                r.add(toggle("Open animation", () -> Settings.openAnim, () -> Settings.openAnim = !Settings.openAnim));
            }
            default -> { // Info
                r.add(info("Menu key", () -> GlassMenu.openKey().getBoundKeyLocalizedText().getString()));
                r.add(info("Zoom key", () -> GlassMenu.zoomKey().getBoundKeyLocalizedText().getString() + " (hold)"));
                r.add(new Row("Controls", () -> "open", b -> mc.setScreen(new KeybindsScreen(this, mc.options)), null));
                r.add(new Row("Reset settings", () -> "click", b -> {
                    Settings.resetDefaults();
                    Config.save();
                }, null));
                r.add(info("Config", () -> "config/glassmenu.json"));
            }
        }
        return r;
    }

    private static Row toggle(String label, BooleanSupplier get, Runnable flip) {
        return new Row(label, () -> get.getAsBoolean() ? "ON" : "OFF", b -> {
            flip.run();
            Config.save();
        }, null);
    }

    /** Left click / right click / scroll step through values. step receives +1 or -1. */
    private static Row cycle(String label, Supplier<String> value, IntConsumer step) {
        return new Row(label, value,
                b -> {
                    step.accept(b == 1 ? -1 : 1);
                    Config.save();
                },
                d -> {
                    step.accept(d);
                    Config.save();
                });
    }

    private static Row slider(String label, IntSupplier get, IntConsumer set, int min, int max, int step, String suffix) {
        IntConsumer adjust = d -> {
            set.accept(Math.max(min, Math.min(max, get.getAsInt() + d * step)));
            Config.save();
        };
        return new Row(label, () -> get.getAsInt() + suffix,
                b -> adjust.accept(b == 1 ? -1 : 1),
                adjust);
    }

    private static Row info(String label, Supplier<String> value) {
        return new Row(label, value, null, null);
    }

    private static final class Row {
        final String label;
        final Supplier<String> value;
        final IntConsumer click;   // receives the mouse button (0 left, 1 right); null = info only
        final IntConsumer scroll;  // receives +1 / -1; may be null

        Row(String label, Supplier<String> value, IntConsumer click, IntConsumer scroll) {
            this.label = label;
            this.value = value;
            this.click = click;
            this.scroll = scroll;
        }
    }
}
