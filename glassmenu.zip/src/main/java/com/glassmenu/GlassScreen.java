package com.glassmenu;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.option.KeybindsScreen;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BooleanSupplier;
import java.util.function.IntConsumer;
import java.util.function.IntSupplier;
import java.util.function.Supplier;

public class GlassScreen extends Screen {
    // Panel size in "virtual" pixels; the whole panel is scaled by ui to fit the screen.
    private static final int W = 300, H = 300;
    private static final String[] TABS = {"HUD", "Tools", "Armor", "Fx", "Glass", "Info"};
    private static final int TAB_W = 44, TAB_GAP = 3, TAB_Y = 36, TAB_H = 18;
    private static final int LIST_Y = 64, LIST_BOTTOM = H - 26;
    private static final int LIST_H = LIST_BOTTOM - LIST_Y;
    private static final int HEADER_H = 18, ROW_H = 24, GAP = 3, SCROLL_STEP = 14;

    private int tab = 0;
    private List<Row> rows;
    private int contentHeight;
    private int scroll;
    private int presetIndex;
    private float ui = 1f;
    private final long openedAt = System.nanoTime();

    public GlassScreen() {
        super(net.minecraft.text.Text.literal("Glass Menu"));
    }

    @Override
    protected void init() {
        ui = computeUi();
        rebuild();
    }

    private float computeUi() {
        float s = Math.min(width / (float) (W + 40), height / (float) (H + 40));
        return Math.max(1f, Math.min(1.5f, s));
    }

    private int vWidth() { return Math.round(width / ui); }
    private int vHeight() { return Math.round(height / ui); }
    private int left() { return (vWidth() - W) / 2; }
    private int top() { return (vHeight() - H) / 2; }

    private void rebuild() {
        rows = buildRows();
        scroll = 0;
        int y = 0;
        for (Row r : rows) {
            r.top = y;
            y += r.height + GAP;
        }
        contentHeight = Math.max(0, y - GAP);
    }

    private int maxScroll() {
        return Math.max(0, contentHeight - LIST_H);
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        ui = computeUi();
        if (rows == null) rebuild();

        float p = openProgress();
        int vw = vWidth(), vh = vHeight();
        int x = left();
        int y = top() + Math.round((1f - p) * 14f);
        int accent = Theme.accent();
        int r = Settings.cornerRadius;
        int ir = Math.max(0, r - 1);
        int ta = Math.round(255 * p);
        int mx = Math.round(mouseX / ui), my = Math.round(mouseY / ui);

        ctx.getMatrices().push();
        ctx.getMatrices().scale(ui, ui, 1f);

        // dim + parallax background
        ctx.fill(0, 0, vw, vh, Theme.alpha(0x000000, Math.round(0x50 * p)));
        if (Settings.parallax) drawParallax(ctx, vw, vh, mx, my, accent, p);

        // matte dark panel: shadow, soft border, body, faint top sheen
        Draw.roundRect(ctx, x + 2, y + 5, W, H, r, Theme.alpha(0x000000, Math.round(0x80 * p)));
        Draw.roundRect(ctx, x, y, W, H, r, Theme.alpha(0xFFFFFF, Math.round(0x26 * p)));
        Draw.roundRect(ctx, x + 1, y + 1, W - 2, H - 2, ir,
                Theme.alpha(0x0A0E13, Math.round(Settings.glassAlpha * 2.55f * p)));
        Draw.roundRect(ctx, x + 1, y + 1, W - 2, 40, ir, Theme.alpha(0xFFFFFF, Math.round(0x0C * p)));
        if (Settings.sheen) drawSheen(ctx, x, y, p);

        // title
        ctx.drawCenteredTextWithShadow(textRenderer, Fonts.medium("Glass Menu"), x + W / 2, y + 12,
                Theme.alpha(0xFFFFFF, ta));
        ctx.drawCenteredTextWithShadow(textRenderer, Fonts.text("settings"), x + W / 2, y + 24,
                Theme.alpha(0x8A9099, ta));

        // tabs
        for (int i = 0; i < TABS.length; i++) {
            int tx = tabX(i);
            boolean sel = i == tab;
            Draw.roundRect(ctx, tx, y + TAB_Y, TAB_W, TAB_H, 5,
                    sel ? Theme.alpha(accent, Math.round(0x70 * p)) : Theme.alpha(0xFFFFFF, Math.round(0x0E * p)));
            ctx.drawCenteredTextWithShadow(textRenderer, Fonts.text(TABS[i]), tx + TAB_W / 2, y + TAB_Y + 5,
                    Theme.alpha(0xFFFFFF, sel ? ta : Math.round(0x90 * p)));
        }

        // rows (only fully visible ones are drawn)
        Row hot = rowAt(mx, my);
        for (Row row : rows) {
            int ry = y + LIST_Y + row.top - scroll;
            if (ry < y + LIST_Y || ry + row.height > y + LIST_BOTTOM) continue;

            if (row.header) {
                int tw = textRenderer.getWidth(Fonts.text(row.label));
                int cx = x + W / 2;
                ctx.drawCenteredTextWithShadow(textRenderer, Fonts.text(row.label), cx, ry + 5,
                        Theme.alpha(0x8A9099, ta));
                ctx.fill(x + 16, ry + 9, cx - tw / 2 - 8, ry + 10, Theme.alpha(0xFFFFFF, Math.round(0x22 * p)));
                ctx.fill(cx + tw / 2 + 8, ry + 9, x + W - 16, ry + 10, Theme.alpha(0xFFFFFF, Math.round(0x22 * p)));
                continue;
            }

            boolean isHot = row == hot && row.click != null;
            Draw.roundRect(ctx, x + 12, ry, W - 24, ROW_H, 6,
                    Theme.alpha(0xFFFFFF, Math.round((isHot ? 0x1C : 0x0C) * p)));
            ctx.drawTextWithShadow(textRenderer, Fonts.text(row.label), x + 22, ry + 8,
                    Theme.alpha(0xFFFFFF, ta));

            if (row.on != null) {
                pill(ctx, x + W - 22 - 26, ry + 6, row.on.getAsBoolean(), accent, p);
            } else {
                String v = row.value.get();
                int tw = textRenderer.getWidth(Fonts.text(v));
                int vc = row.click == null ? 0xC8CCD2 : accent;
                ctx.drawTextWithShadow(textRenderer, Fonts.text(v), x + W - 22 - tw, ry + 8, Theme.alpha(vc, ta));
            }
        }

        // scroll indicator
        if (maxScroll() > 0) {
            int track = LIST_H;
            int thumb = Math.max(18, track * LIST_H / contentHeight);
            int ty = y + LIST_Y + (track - thumb) * scroll / maxScroll();
            Draw.roundRect(ctx, x + W - 8, ty, 3, thumb, 1, Theme.alpha(0xFFFFFF, Math.round(0x40 * p)));
        }

        ctx.drawCenteredTextWithShadow(textRenderer, Fonts.text("Click to change  |  Wheel scrolls  |  Esc closes"),
                x + W / 2, y + H - 16, Theme.alpha(0x7A8089, ta));

        ctx.getMatrices().pop();
    }

    /** Soft orbs on three depth layers that drift away from the cursor. */
    private void drawParallax(DrawContext ctx, int vw, int vh, int mx, int my, int accent, float p) {
        float nx = Math.max(-1f, Math.min(1f, (mx - vw / 2f) / (vw / 2f)));
        float ny = Math.max(-1f, Math.min(1f, (my - vh / 2f) / (vh / 2f)));
        // fractionX, fractionY, radius, depth
        float[][] layout = {
                {0.18f, 0.22f, 70, 14},
                {0.84f, 0.74f, 90, 24},
                {0.66f, 0.12f, 46, 9}
        };
        int[] colours = {accent, 0xFF6FF3FF, 0xFFFFFFFF};
        int[] alphas = {0x30, 0x22, 0x18};
        for (int i = 0; i < layout.length; i++) {
            float[] o = layout[i];
            int r = (int) o[2];
            int cx = Math.round(o[0] * vw - nx * o[3]);
            int cy = Math.round(o[1] * vh - ny * o[3]);
            Draw.roundRect(ctx, cx - r, cy - r, 2 * r, 2 * r, r,
                    Theme.alpha(colours[i], Math.round(alphas[i] * p)));
        }
    }

    /** Switch: accent track with a soft glow when on, grey when off, white knob. */
    private static void pill(DrawContext ctx, int x, int y, boolean on, int accent, float p) {
        int w = 26, h = 12;
        if (on) {
            Draw.roundRect(ctx, x - 3, y - 3, w + 6, h + 6, 9, Theme.alpha(accent, Math.round(0x22 * p)));
        }
        Draw.roundRect(ctx, x, y, w, h, 6,
                on ? Theme.alpha(accent, Math.round(0xDD * p)) : Theme.alpha(0xFFFFFF, Math.round(0x26 * p)));
        int kx = on ? x + w - h + 2 : x + 2;
        Draw.roundRect(ctx, kx, y + 2, h - 4, h - 4, 4, Theme.alpha(0xFFFFFF, Math.round(255 * p)));
    }

    private void drawSheen(DrawContext ctx, int x, int y, float p) {
        long t = System.currentTimeMillis() % 3600L;
        int bx = x - 60 + (int) (t * (W + 120) / 3600L);
        for (int i = 0; i < 3; i++) {
            int sx = bx + i * 10;
            int x1 = Math.max(sx, x + 1), x2 = Math.min(sx + 4, x + W - 1);
            if (x2 > x1) {
                ctx.fill(x1, y + 1, x2, y + H - 1, Theme.alpha(0xFFFFFF, Math.round((10 - i * 3) * p)));
            }
        }
    }

    private float openProgress() {
        if (!Settings.openAnim) return 1f;
        float t = (System.nanoTime() - openedAt) / 180_000_000f;
        t = Math.max(0f, Math.min(1f, t));
        float inv = 1f - t;
        return 1f - inv * inv * inv;
    }

    private int tabX(int i) {
        int total = TABS.length * TAB_W + (TABS.length - 1) * TAB_GAP;
        return left() + (W - total) / 2 + i * (TAB_W + TAB_GAP);
    }

    /** Row fully under a point in virtual coordinates, or null. */
    private Row rowAt(int mx, int my) {
        if (rows == null) return null;
        int x = left(), y = top();
        if (mx < x + 12 || mx > x + W - 12) return null;
        for (Row row : rows) {
            if (row.header) continue;
            int ry = y + LIST_Y + row.top - scroll;
            if (ry < y + LIST_Y || ry + row.height > y + LIST_BOTTOM) continue;
            if (my >= ry && my <= ry + row.height) return row;
        }
        return null;
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (rows == null) rebuild();
        if (button == 0 || button == 1) {
            int mx = (int) Math.round(mouseX / ui), my = (int) Math.round(mouseY / ui);
            int y = top();
            for (int i = 0; i < TABS.length; i++) {
                int tx = tabX(i);
                if (mx >= tx && mx <= tx + TAB_W && my >= y + TAB_Y && my <= y + TAB_Y + TAB_H) {
                    tab = i;
                    rebuild();
                    return true;
                }
            }
            Row row = rowAt(mx, my);
            if (row != null && row.click != null) {
                row.click.accept(button);
                return true;
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        int mx = (int) Math.round(mouseX / ui), my = (int) Math.round(mouseY / ui);
        int x = left(), y = top();
        if (mx >= x && mx <= x + W && my >= y + LIST_Y && my <= y + LIST_BOTTOM && verticalAmount != 0) {
            scroll = Math.max(0, Math.min(maxScroll(), scroll - (int) Math.signum(verticalAmount) * SCROLL_STEP));
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    @Override
    public void removed() {
        Config.save();
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    // ---------- tab contents ----------

    private List<Row> buildRows() {
        List<Row> r = new ArrayList<>();
        MinecraftClient mc = MinecraftClient.getInstance();

        switch (tab) {
            case 0 -> { // HUD
                r.add(header("INFO PANEL"));
                r.add(toggle("Info panel", () -> Settings.infoPanel, () -> Settings.infoPanel = !Settings.infoPanel));
                r.add(cycle("Info corner", () -> Hud.CORNER_NAMES[Settings.infoCorner],
                        d -> Settings.infoCorner = Math.floorMod(Settings.infoCorner + d, 4)));
                r.add(toggle("Game time", () -> Settings.showTime, () -> Settings.showTime = !Settings.showTime));
                r.add(toggle("Coordinates", () -> Settings.showCoords, () -> Settings.showCoords = !Settings.showCoords));
                r.add(toggle("Speed", () -> Settings.showSpeed, () -> Settings.showSpeed = !Settings.showSpeed));
                r.add(toggle("Ping", () -> Settings.showPing, () -> Settings.showPing = !Settings.showPing));
                r.add(toggle("CPS counter", () -> Settings.cps, () -> Settings.cps = !Settings.cps));
                r.add(header("OVERLAYS"));
                r.add(toggle("Compass", () -> Settings.compass, () -> Settings.compass = !Settings.compass));
                r.add(toggle("FPS graph", () -> Settings.showGraph, () -> Settings.showGraph = !Settings.showGraph));
                r.add(cycle("Graph corner", () -> Hud.CORNER_NAMES[Settings.graphCorner],
                        d -> Settings.graphCorner = Math.floorMod(Settings.graphCorner + d, 4)));
                r.add(new Row("Preset", null, () -> "< " + Settings.PRESET_NAMES[presetIndex] + " >",
                        b -> {
                            if (b == 1) {
                                presetIndex = (presetIndex + 1) % Settings.PRESET_NAMES.length;
                            } else {
                                Settings.applyPreset(presetIndex);
                                Config.save();
                            }
                        }, null));
            }
            case 1 -> { // Tools
                r.add(header("KEYSTROKES"));
                r.add(toggle("Keystrokes", () -> Settings.keystrokes, () -> Settings.keystrokes = !Settings.keystrokes));
                r.add(cycle("Keys corner", () -> Hud.CORNER_NAMES[Settings.keystrokesCorner],
                        d -> Settings.keystrokesCorner = Math.floorMod(Settings.keystrokesCorner + d, 4)));
                r.add(header("CROSSHAIR & OVERLAYS"));
                r.add(cycle("Crosshair", () -> Settings.CROSSHAIR_NAMES[Settings.crosshairStyle],
                        d -> Settings.crosshairStyle = Math.floorMod(Settings.crosshairStyle + d, Settings.CROSSHAIR_NAMES.length)));
                r.add(toggle("Hide fire overlay", () -> Settings.hideFire, () -> Settings.hideFire = !Settings.hideFire));
                r.add(toggle("Hide vignette", () -> Settings.hideVignette, () -> Settings.hideVignette = !Settings.hideVignette));
                r.add(header("ZOOM"));
                r.add(toggle("Zoom (hold C)", () -> Settings.zoomEnabled, () -> Settings.zoomEnabled = !Settings.zoomEnabled));
                r.add(slider("Zoom FOV", () -> Settings.zoomFov, v -> Settings.zoomFov = v, 30, 70, 5, ""));
                r.add(header("SESSION"));
                r.add(toggle("Session timer", () -> Settings.showSession, () -> Settings.showSession = !Settings.showSession));
                r.add(toggle("Waypoints (M)", () -> Settings.showWaypoint, () -> Settings.showWaypoint = !Settings.showWaypoint));
                r.add(new Row("Clear waypoints", null, () -> GlassMenu.waypoints().size() + " set", b -> {
                    GlassMenu.clearWaypoints();
                }, false));
                r.add(toggle("Session stats", () -> Settings.showStats, () -> Settings.showStats = !Settings.showStats));
                r.add(new Row("Reset stats", null, () -> "click", b -> {
                    GlassMenu.resetStats();
                }, false));
                r.add(toggle("FPS / ping colors", () -> Settings.fpsColors, () -> Settings.fpsColors = !Settings.fpsColors));
            }
            case 2 -> { // Armor & potions
                r.add(header("ARMOUR"));
                r.add(toggle("Armor HUD", () -> Settings.armorHud, () -> Settings.armorHud = !Settings.armorHud));
                r.add(cycle("Armor corner", () -> Hud.CORNER_NAMES[Settings.armorCorner],
                        d -> Settings.armorCorner = Math.floorMod(Settings.armorCorner + d, 4)));
                r.add(header("POTIONS"));
                r.add(toggle("Potion HUD", () -> Settings.potionHud, () -> Settings.potionHud = !Settings.potionHud));
                r.add(cycle("Potion corner", () -> Hud.CORNER_NAMES[Settings.potionCorner],
                        d -> Settings.potionCorner = Math.floorMod(Settings.potionCorner + d, 4)));
            }
            case 3 -> { // Fx
                r.add(header("TRAIL & HITS"));
                r.add(cycle("Trail", () -> Settings.TRAIL_NAMES[Settings.trailMode],
                        d -> Settings.trailMode = Math.floorMod(Settings.trailMode + d, Settings.TRAIL_NAMES.length)));
                r.add(cycle("Hit effect", () -> Settings.HIT_NAMES[Settings.hitMode],
                        d -> Settings.hitMode = Math.floorMod(Settings.hitMode + d, Settings.HIT_NAMES.length)));
                r.add(header("NEON HAT"));
                r.add(cycle("Hat style", () -> Settings.HAT_NAMES[Settings.hatMode],
                        d -> Settings.hatMode = Math.floorMod(Settings.hatMode + d, Settings.HAT_NAMES.length)));
                r.add(slider("Hat size", () -> Settings.hatSize, v -> Settings.hatSize = v, 1, 3, 1, ""));
                r.add(header("WEATHER"));
                r.add(cycle("Weather", () -> Settings.WEATHER_NAMES[Settings.weatherMode],
                        d -> Settings.weatherMode = Math.floorMod(Settings.weatherMode + d, Settings.WEATHER_NAMES.length)));
                r.add(slider("Weather density", () -> Settings.weatherDensity, v -> Settings.weatherDensity = v, 1, 10, 1, ""));
                r.add(header("ACCENT"));
                r.add(toggle("Rainbow accent", () -> Settings.rainbow, () -> Settings.rainbow = !Settings.rainbow));
                r.add(cycle("Accent", () -> Settings.ACCENT_NAMES[Settings.accentIndex],
                        d -> Settings.accentIndex = Math.floorMod(Settings.accentIndex + d, Settings.ACCENTS.length)));
            }
            case 4 -> { // Glass
                r.add(header("PULSE"));
                r.add(new Row("Apply Pulse dark theme", null, () -> "click", b -> {
                    Settings.applyPulseTheme();
                    Config.save();
                }, false));
                r.add(header("HUD LOOK"));
                r.add(slider("HUD opacity", () -> Settings.hudAlpha, v -> Settings.hudAlpha = v, 0, 100, 10, "%"));
                r.add(cycle("HUD scale", () -> Settings.hudScale + "%",
                        d -> {
                            int i = 0;
                            for (int k = 0; k < Settings.HUD_SCALES.length; k++) {
                                if (Settings.HUD_SCALES[k] == Settings.hudScale) i = k;
                            }
                            i = Math.floorMod(i + d, Settings.HUD_SCALES.length);
                            Settings.hudScale = Settings.HUD_SCALES[i];
                        }));
                r.add(toggle("HUD accent bar", () -> Settings.hudAccentBar, () -> Settings.hudAccentBar = !Settings.hudAccentBar));
                r.add(header("FOG & SKY"));
                r.add(toggle("Custom fog", () -> Settings.customFog, () -> Settings.customFog = !Settings.customFog));
                r.add(cycle("Fog color", () -> Settings.FOG_NAMES[Settings.fogColorIndex],
                        d -> Settings.fogColorIndex = Math.floorMod(Settings.fogColorIndex + d, Settings.FOG_COLORS.length)));
                r.add(slider("Fog distance", () -> Settings.fogDistance, v -> Settings.fogDistance = v, 20, 100, 10, "%"));
                r.add(header("NIGHT"));
                r.add(toggle("Brightness boost", () -> Settings.brightBoost, () -> Settings.brightBoost = !Settings.brightBoost));
                r.add(header("PANEL"));
                r.add(slider("Opacity", () -> Settings.glassAlpha, v -> Settings.glassAlpha = v, 20, 100, 5, "%"));
                r.add(slider("Corner radius", () -> Settings.cornerRadius, v -> Settings.cornerRadius = v, 0, 12, 1, "px"));
                r.add(toggle("Sheen", () -> Settings.sheen, () -> Settings.sheen = !Settings.sheen));
                r.add(toggle("Parallax", () -> Settings.parallax, () -> Settings.parallax = !Settings.parallax));
                r.add(toggle("Open animation", () -> Settings.openAnim, () -> Settings.openAnim = !Settings.openAnim));
            }
            default -> { // Info
                r.add(header("KEYS"));
                r.add(info("Menu key", () -> GlassMenu.openKey().getBoundKeyLocalizedText().getString()));
                r.add(info("Zoom key", () -> GlassMenu.zoomKey().getBoundKeyLocalizedText().getString() + " (hold)"));
                r.add(info("Hide HUD", () -> GlassMenu.hudKey().getBoundKeyLocalizedText().getString()));
                r.add(info("Waypoint / copy", () -> "M / N"));
                r.add(header("ACTIONS"));
                r.add(new Row("Controls", null, () -> "open",
                        b -> mc.setScreen(new KeybindsScreen(this, mc.options)), null));
                r.add(new Row("Reset settings", null, () -> "click", b -> {
                    Settings.resetDefaults();
                    Config.save();
                }, null));
                r.add(info("Config file", () -> "glassmenu.json"));
            }
        }
        return r;
    }

    private static Row header(String title) {
        Row r = new Row(title, null, null, null, true);
        return r;
    }

    private static Row toggle(String label, BooleanSupplier get, Runnable flip) {
        return new Row(label, get, null, b -> {
            flip.run();
            Config.save();
        }, false);
    }

    /** Left click / right click step through values. step receives +1 or -1. */
    private static Row cycle(String label, Supplier<String> value, IntConsumer step) {
        return new Row(label, null, value, b -> {
            step.accept(b == 1 ? -1 : 1);
            Config.save();
        }, false);
    }

    /** Left click increases, right click decreases. */
    private static Row slider(String label, IntSupplier get, IntConsumer set, int min, int max, int step, String suffix) {
        IntConsumer adjust = d -> {
            set.accept(Math.max(min, Math.min(max, get.getAsInt() + d * step)));
            Config.save();
        };
        return new Row(label, null, () -> "< " + get.getAsInt() + suffix + " >",
                b -> adjust.accept(b == 1 ? -1 : 1), false);
    }

    private static Row info(String label, Supplier<String> value) {
        return new Row(label, null, value, null, false);
    }

    private static final class Row {
        final String label;
        final BooleanSupplier on;   // if not null the row shows a switch
        final Supplier<String> value;
        final IntConsumer click;    // receives the mouse button; null = info only
        final boolean header;
        final int height;
        int top;                    // offset inside the scrollable list

        Row(String label, BooleanSupplier on, Supplier<String> value, IntConsumer click, boolean header) {
            this.label = label;
            this.on = on;
            this.value = value;
            this.click = click;
            this.header = header;
            this.height = header ? HEADER_H : ROW_H;
        }
    }
}
