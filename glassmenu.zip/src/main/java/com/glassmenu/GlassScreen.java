package com.glassmenu;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.option.KeybindsScreen;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BooleanSupplier;
import java.util.function.IntConsumer;
import java.util.function.IntSupplier;
import java.util.function.Supplier;

public class GlassScreen extends Screen {
    // Panel size in "virtual" pixels; the whole panel is scaled by ui to fit the screen.
    private static final int W = 300, H = 270;
    private static final String[] TABS = {"HUD", "Tools", "Armor", "Fx", "Glass", "Info"};
    private static final int TAB_W = 44, TAB_GAP = 3, TAB_Y = 34, TAB_H = 18;
    private static final int ROW_Y = 64, ROW_H = 24, ROW_STEP = 27;

    private int tab = 0;
    private List<Row> rows;
    private float ui = 1f;
    private final long openedAt = System.nanoTime();

    public GlassScreen() {
        super(Text.literal("Glass Menu"));
    }

    @Override
    protected void init() {
        ui = computeUi();
        rows = buildRows();
    }

    private float computeUi() {
        float s = Math.min(width / (float) (W + 40), height / (float) (H + 40));
        return Math.max(1f, Math.min(1.5f, s));
    }

    private int vWidth() { return Math.round(width / ui); }
    private int vHeight() { return Math.round(height / ui); }
    private int left() { return (vWidth() - W) / 2; }
    private int top() { return (vHeight() - H) / 2; }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        ui = computeUi();
        if (rows == null) rows = buildRows();

        float p = openProgress();
        int vw = vWidth(), vh = vHeight();
        int x = left();
        int y = top() + Math.round((1f - p) * 14f);
        int accent = Theme.accent();
        int r = Settings.cornerRadius;
        int ir = Math.max(0, r - 1);
        int ta = Math.round(255 * p);
        int mx = Math.round(mouseX / ui), my = Math.round(mouseY / ui);

        ctx.getMatrices().push();
        ctx.getMatrices().scale(ui, ui, 1f);

        // soft dim behind the panel
        ctx.fill(0, 0, vw, vh, Theme.alpha(0x000000, Math.round(0x40 * p)));

        // drop shadow, bright border, dark tinted body, top gloss
        Draw.roundRect(ctx, x + 2, y + 4, W, H, r, Theme.alpha(0x000000, Math.round(0x66 * p)));
        Draw.roundRect(ctx, x, y, W, H, r, Theme.alpha(0xFFFFFF, Math.round(0x70 * p)));
        Draw.roundRect(ctx, x + 1, y + 1, W - 2, H - 2, ir,
                Theme.alpha(0x0B1118, Math.round(Settings.glassAlpha * 2.55f * p)));
        Draw.roundRect(ctx, x + 1, y + 1, W - 2, 44, ir, Theme.alpha(0xFFFFFF, Math.round(0x14 * p)));

        if (Settings.sheen) drawSheen(ctx, x, y, p);

        // header
        ctx.drawCenteredTextWithShadow(textRenderer, Text.literal("GLASS MENU"), x + W / 2, y + 11,
                Theme.alpha(0xFFFFFF, ta));
        Draw.roundRect(ctx, x + 16, y + 25, W - 32, 2, 1, Theme.alpha(accent, ta));

        // tabs
        for (int i = 0; i < TABS.length; i++) {
            int tx = tabX(i);
            boolean sel = i == tab;
            Draw.roundRect(ctx, tx, y + TAB_Y, TAB_W, TAB_H, 5,
                    sel ? Theme.alpha(accent, Math.round(0x80 * p)) : Theme.alpha(0xFFFFFF, Math.round(0x14 * p)));
            ctx.drawCenteredTextWithShadow(textRenderer, Text.literal(TABS[i]), tx + TAB_W / 2, y + TAB_Y + 5,
                    Theme.alpha(0xFFFFFF, sel ? ta : Math.round(0xAA * p)));
        }

        // rows
        int hover = rowAt(mx, my);
        for (int i = 0; i < rows.size(); i++) {
            Row row = rows.get(i);
            int ry = y + ROW_Y + i * ROW_STEP;
            boolean hot = i == hover && row.click != null;
            Draw.roundRect(ctx, x + 12, ry, W - 24, ROW_H, 5,
                    Theme.alpha(0xFFFFFF, Math.round((hot ? 0x40 : 0x14) * p)));
            Draw.roundRect(ctx, x + 12, ry + 5, 3, ROW_H - 10, 1, Theme.alpha(accent, ta));
            ctx.drawTextWithShadow(textRenderer, Text.literal(row.label), x + 22, ry + 8, Theme.alpha(0xFFFFFF, ta));

            if (row.on != null) {
                pill(ctx, x + W - 22 - 26, ry + 6, row.on.getAsBoolean(), accent, p);
            } else {
                String v = row.value.get();
                int tw = textRenderer.getWidth(v);
                int vc = row.click == null ? 0xDDDDDD : accent;
                ctx.drawTextWithShadow(textRenderer, Text.literal(v), x + W - 22 - tw, ry + 8, Theme.alpha(vc, ta));
            }
        }

        ctx.drawCenteredTextWithShadow(textRenderer,
                Text.literal("Click or scroll to change | Esc closes"),
                x + W / 2, y + H - 16, Theme.alpha(0xB0B0B0, ta));

        ctx.getMatrices().pop();
    }

    /** iOS-style switch: track in accent colour when on, grey when off, white knob. */
    private static void pill(DrawContext ctx, int x, int y, boolean on, int accent, float p) {
        int w = 26, h = 12;
        Draw.roundRect(ctx, x, y, w, h, 6,
                on ? Theme.alpha(accent, Math.round(0xDD * p)) : Theme.alpha(0xFFFFFF, Math.round(0x30 * p)));
        int kx = on ? x + w - h + 2 : x + 2;
        Draw.roundRect(ctx, kx, y + 2, h - 4, h - 4, 4, Theme.alpha(0xFFFFFF, Math.round(255 * p)));
    }

    /** Soft light band that slides across the panel. */
    private void drawSheen(DrawContext ctx, int x, int y, float p) {
        long t = System.currentTimeMillis() % 3600L;
        int bx = x - 60 + (int) (t * (W + 120) / 3600L);
        for (int i = 0; i < 3; i++) {
            int sx = bx + i * 10;
            int x1 = Math.max(sx, x + 1), x2 = Math.min(sx + 4, x + W - 1);
            if (x2 > x1) {
                ctx.fill(x1, y + 1, x2, y + H - 1, Theme.alpha(0xFFFFFF, Math.round((18 - i * 4) * p)));
            }
        }
    }

    private float openProgress() {
        if (!Settings.openAnim) return 1f;
        float t = (System.nanoTime() - openedAt) / 180_000_000f;
        t = Math.max(0f, Math.min(1f, t));
        float inv = 1f - t;
        return 1f - inv * inv * inv;
    }

    private int tabX(int i) {
        int total = TABS.length * TAB_W + (TABS.length - 1) * TAB_GAP;
        return left() + (W - total) / 2 + i * (TAB_W + TAB_GAP);
    }

    /** Row index under a point given in virtual (unscaled) coordinates, or -1. */
    private int rowAt(int mx, int my) {
        if (rows == null) return -1;
        int x = left(), y = top();
        if (mx < x + 12 || mx > x + W - 12) return -1;
        for (int i = 0; i < rows.size(); i++) {
            int ry = y + ROW_Y + i * ROW_STEP;
            if (my >= ry && my <= ry + ROW_H) return i;
        }
        return -1;
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (rows == null) rows = buildRows();
        if (button == 0 || button == 1) {
            int mx = (int) Math.round(mouseX / ui), my = (int) Math.round(mouseY / ui);
            int y = top();
            for (int i = 0; i < TABS.length; i++) {
                int tx = tabX(i);
                if (mx >= tx && mx <= tx + TAB_W && my >= y + TAB_Y && my <= y + TAB_Y + TAB_H) {
                    tab = i;
                    rows = buildRows();
                    return true;
                }
            }
            int idx = rowAt(mx, my);
            if (idx >= 0 && rows.get(idx).click != null) {
                rows.get(idx).click.accept(button);
                return true;
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        int idx = rowAt((int) Math.round(mouseX / ui), (int) Math.round(mouseY / ui));
        if (idx >= 0 && verticalAmount != 0 && rows.get(idx).scroll != null) {
            rows.get(idx).scroll.accept(verticalAmount > 0 ? 1 : -1);
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    @Override
    public void removed() {
        Config.save();
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    // ---------- tab contents ----------

    private List<Row> buildRows() {
        List<Row> r = new ArrayList<>();
        MinecraftClient mc = MinecraftClient.getInstance();

        switch (tab) {
            case 0 -> { // HUD
                r.add(toggle("Info panel", () -> Settings.infoPanel, () -> Settings.infoPanel = !Settings.infoPanel));
                r.add(cycle("Info corner", () -> Hud.CORNER_NAMES[Settings.infoCorner],
                        d -> Settings.infoCorner = Math.floorMod(Settings.infoCorner + d, 4)));
                r.add(toggle("Coordinates", () -> Settings.showCoords, () -> Settings.showCoords = !Settings.showCoords));
                r.add(toggle("Speed", () -> Settings.showSpeed, () -> Settings.showSpeed = !Settings.showSpeed));
                r.add(toggle("Ping", () -> Settings.showPing, () -> Settings.showPing = !Settings.showPing));
                r.add(toggle("CPS counter", () -> Settings.cps, () -> Settings.cps = !Settings.cps));
                r.add(toggle("Compass", () -> Settings.compass, () -> Settings.compass = !Settings.compass));
            }
            case 1 -> { // Tools
                r.add(toggle("Keystrokes", () -> Settings.keystrokes, () -> Settings.keystrokes = !Settings.keystrokes));
                r.add(cycle("Keys corner", () -> Hud.CORNER_NAMES[Settings.keystrokesCorner],
                        d -> Settings.keystrokesCorner = Math.floorMod(Settings.keystrokesCorner + d, 4)));
                r.add(toggle("Zoom (hold C)", () -> Settings.zoomEnabled, () -> Settings.zoomEnabled = !Settings.zoomEnabled));
                r.add(slider("Zoom FOV", () -> Settings.zoomFov, v -> Settings.zoomFov = v, 30, 70, 5, ""));
                r.add(toggle("FPS / ping colors", () -> Settings.fpsColors, () -> Settings.fpsColors = !Settings.fpsColors));
            }
            case 2 -> { // Armor & potions
                r.add(toggle("Armor HUD", () -> Settings.armorHud, () -> Settings.armorHud = !Settings.armorHud));
                r.add(cycle("Armor corner", () -> Hud.CORNER_NAMES[Settings.armorCorner],
                        d -> Settings.armorCorner = Math.floorMod(Settings.armorCorner + d, 4)));
                r.add(toggle("Potion HUD", () -> Settings.potionHud, () -> Settings.potionHud = !Settings.potionHud));
                r.add(cycle("Potion corner", () -> Hud.CORNER_NAMES[Settings.potionCorner],
                        d -> Settings.potionCorner = Math.floorMod(Settings.potionCorner + d, 4)));
            }
            case 3 -> { // Fx
                r.add(cycle("Trail", () -> Settings.TRAIL_NAMES[Settings.trailMode],
                        d -> Settings.trailMode = Math.floorMod(Settings.trailMode + d, Settings.TRAIL_NAMES.length)));
                r.add(cycle("Hit effect", () -> Settings.HIT_NAMES[Settings.hitMode],
                        d -> Settings.hitMode = Math.floorMod(Settings.hitMode + d, Settings.HIT_NAMES.length)));
                r.add(toggle("Rainbow accent", () -> Settings.rainbow, () -> Settings.rainbow = !Settings.rainbow));
                r.add(cycle("Accent", () -> Settings.ACCENT_NAMES[Settings.accentIndex],
                        d -> Settings.accentIndex = Math.floorMod(Settings.accentIndex + d, Settings.ACCENTS.length)));
            }
            case 4 -> { // Glass
                r.add(slider("Opacity", () -> Settings.glassAlpha, v -> Settings.glassAlpha = v, 20, 100, 5, "%"));
                r.add(slider("Corner radius", () -> Settings.cornerRadius, v -> Settings.cornerRadius = v, 0, 12, 1, "px"));
                r.add(toggle("Sheen", () -> Settings.sheen, () -> Settings.sheen = !Settings.sheen));
                r.add(toggle("Open animation", () -> Settings.openAnim, () -> Settings.openAnim = !Settings.openAnim));
            }
            default -> { // Info
                r.add(info("Menu key", () -> GlassMenu.openKey().getBoundKeyLocalizedText().getString()));
                r.add(info("Zoom key", () -> GlassMenu.zoomKey().getBoundKeyLocalizedText().getString() + " (hold)"));
                r.add(new Row("Controls", null, () -> "open",
                        b -> mc.setScreen(new KeybindsScreen(this, mc.options)), null));
                r.add(new Row("Reset settings", null, () -> "click", b -> {
                    Settings.resetDefaults();
                    Config.save();
                }, null));
                r.add(info("Config", () -> "config/glassmenu.json"));
            }
        }
        return r;
    }

    private static Row toggle(String label, BooleanSupplier get, Runnable flip) {
        return new Row(label, get, null, b -> {
            flip.run();
            Config.save();
        }, null);
    }

    /** Left click / right click / scroll step through values. step receives +1 or -1. */
    private static Row cycle(String label, Supplier<String> value, IntConsumer step) {
        return new Row(label, null, value,
                b -> {
                    step.accept(b == 1 ? -1 : 1);
                    Config.save();
                },
                d -> {
                    step.accept(d);
                    Config.save();
                });
    }

    private static Row slider(String label, IntSupplier get, IntConsumer set, int min, int max, int step, String suffix) {
        IntConsumer adjust = d -> {
            set.accept(Math.max(min, Math.min(max, get.getAsInt() + d * step)));
            Config.save();
        };
        return new Row(label, null, () -> "< " + get.getAsInt() + suffix + " >",
                b -> adjust.accept(b == 1 ? -1 : 1),
                adjust);
    }

    private static Row info(String label, Supplier<String> value) {
        return new Row(label, null, value, null, null);
    }

    private static final class Row {
        final String label;
        final BooleanSupplier on;   // if not null the row shows a switch
        final Supplier<String> value;
        final IntConsumer click;    // receives the mouse button (0 left, 1 right); null = info only
        final IntConsumer scroll;   // receives +1 / -1; may be null

        Row(String label, BooleanSupplier on, Supplier<String> value, IntConsumer click, IntConsumer scroll) {
            this.label = label;
            this.on = on;
            this.value = value;
            this.click = click;
            this.scroll = scroll;
        }
    }
}
