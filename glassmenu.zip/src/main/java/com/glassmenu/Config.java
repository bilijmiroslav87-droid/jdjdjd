package com.glassmenu;

import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

/** Saves and loads Settings as config/glassmenu.json. */
public final class Config {
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("glassmenu.json");

    private Config() {}

    public static void load() {
        if (!Files.exists(FILE)) return;
        try {
            JsonObject o = JsonParser.parseString(Files.readString(FILE)).getAsJsonObject();

            Settings.infoPanel = bool(o, "infoPanel", Settings.infoPanel);
            Settings.infoCorner = num(o, "infoCorner", Settings.infoCorner);
            Settings.showCoords = bool(o, "showCoords", Settings.showCoords);
            Settings.showSpeed = bool(o, "showSpeed", Settings.showSpeed);
            Settings.showPing = bool(o, "showPing", Settings.showPing);
            Settings.cps = bool(o, "cps", Settings.cps);
            Settings.compass = bool(o, "compass", Settings.compass);
            Settings.keystrokes = bool(o, "keystrokes", Settings.keystrokes);
            Settings.keystrokesCorner = num(o, "keystrokesCorner", Settings.keystrokesCorner);

            Settings.zoomEnabled = bool(o, "zoomEnabled", Settings.zoomEnabled);
            Settings.zoomFov = num(o, "zoomFov", Settings.zoomFov);
            Settings.fpsColors = bool(o, "fpsColors", Settings.fpsColors);

            Settings.armorHud = bool(o, "armorHud", Settings.armorHud);
            Settings.armorCorner = num(o, "armorCorner", Settings.armorCorner);
            Settings.potionHud = bool(o, "potionHud", Settings.potionHud);
            Settings.potionCorner = num(o, "potionCorner", Settings.potionCorner);

            Settings.trailMode = num(o, "trailMode", Settings.trailMode);
            Settings.hitMode = num(o, "hitMode", Settings.hitMode);
            Settings.weatherMode = num(o, "weatherMode", Settings.weatherMode);
            Settings.weatherDensity = num(o, "weatherDensity", Settings.weatherDensity);
            Settings.rainbow = bool(o, "rainbow", Settings.rainbow);
            Settings.accentIndex = num(o, "accentIndex", Settings.accentIndex);

            Settings.glassAlpha = num(o, "glassAlpha", Settings.glassAlpha);
            Settings.cornerRadius = num(o, "cornerRadius", Settings.cornerRadius);
            Settings.sheen = bool(o, "sheen", Settings.sheen);
            Settings.openAnim = bool(o, "openAnim", Settings.openAnim);
            Settings.parallax = bool(o, "parallax", Settings.parallax);
            Settings.showTime = bool(o, "showTime", Settings.showTime);
            Settings.showGraph = bool(o, "showGraph", Settings.showGraph);
            Settings.graphCorner = num(o, "graphCorner", Settings.graphCorner);
            Settings.hudAlpha = num(o, "hudAlpha", Settings.hudAlpha);
            Settings.hudScale = num(o, "hudScale", Settings.hudScale);
            Settings.hudAccentBar = bool(o, "hudAccentBar", Settings.hudAccentBar);
            Settings.crosshairStyle = num(o, "crosshairStyle", Settings.crosshairStyle);
            Settings.hideFire = bool(o, "hideFire", Settings.hideFire);
            Settings.hideVignette = bool(o, "hideVignette", Settings.hideVignette);
            Settings.hatMode = num(o, "hatMode", Settings.hatMode);
            Settings.brightBoost = bool(o, "brightBoost", Settings.brightBoost);
            Settings.showStats = bool(o, "showStats", Settings.showStats);
            Settings.customFog = bool(o, "customFog", Settings.customFog);
            Settings.fogColorIndex = num(o, "fogColorIndex", Settings.fogColorIndex);
            Settings.fogDistance = num(o, "fogDistance", Settings.fogDistance);
            Settings.hatSize = num(o, "hatSize", Settings.hatSize);
            Settings.hatGradient = bool(o, "hatGradient", Settings.hatGradient);
            Settings.wings = bool(o, "wings", Settings.wings);
            Settings.jumpFx = bool(o, "jumpFx", Settings.jumpFx);
            Settings.showSession = bool(o, "showSession", Settings.showSession);
            Settings.showWaypoint = bool(o, "showWaypoint", Settings.showWaypoint);

            Settings.sanitize();
        } catch (Exception e) {
            GlassMenu.LOGGER.warn("Could not read {}, using defaults", FILE, e);
        }
    }

    public static void save() {
        JsonObject o = new JsonObject();
        o.addProperty("infoPanel", Settings.infoPanel);
        o.addProperty("infoCorner", Settings.infoCorner);
        o.addProperty("showCoords", Settings.showCoords);
        o.addProperty("showSpeed", Settings.showSpeed);
        o.addProperty("showPing", Settings.showPing);
        o.addProperty("cps", Settings.cps);
        o.addProperty("compass", Settings.compass);
        o.addProperty("keystrokes", Settings.keystrokes);
        o.addProperty("keystrokesCorner", Settings.keystrokesCorner);

        o.addProperty("zoomEnabled", Settings.zoomEnabled);
        o.addProperty("zoomFov", Settings.zoomFov);
        o.addProperty("fpsColors", Settings.fpsColors);

        o.addProperty("armorHud", Settings.armorHud);
        o.addProperty("armorCorner", Settings.armorCorner);
        o.addProperty("potionHud", Settings.potionHud);
        o.addProperty("potionCorner", Settings.potionCorner);

        o.addProperty("trailMode", Settings.trailMode);
        o.addProperty("hitMode", Settings.hitMode);
        o.addProperty("weatherMode", Settings.weatherMode);
        o.addProperty("weatherDensity", Settings.weatherDensity);
        o.addProperty("rainbow", Settings.rainbow);
        o.addProperty("accentIndex", Settings.accentIndex);

        o.addProperty("glassAlpha", Settings.glassAlpha);
        o.addProperty("cornerRadius", Settings.cornerRadius);
        o.addProperty("sheen", Settings.sheen);
        o.addProperty("openAnim", Settings.openAnim);
        o.addProperty("parallax", Settings.parallax);
        o.addProperty("showTime", Settings.showTime);
        o.addProperty("showGraph", Settings.showGraph);
        o.addProperty("graphCorner", Settings.graphCorner);
        o.addProperty("hudAlpha", Settings.hudAlpha);
        o.addProperty("hudScale", Settings.hudScale);
        o.addProperty("hudAccentBar", Settings.hudAccentBar);
        o.addProperty("crosshairStyle", Settings.crosshairStyle);
        o.addProperty("hideFire", Settings.hideFire);
        o.addProperty("hideVignette", Settings.hideVignette);
        o.addProperty("hatMode", Settings.hatMode);
        o.addProperty("brightBoost", Settings.brightBoost);
        o.addProperty("showStats", Settings.showStats);
        o.addProperty("customFog", Settings.customFog);
        o.addProperty("fogColorIndex", Settings.fogColorIndex);
        o.addProperty("fogDistance", Settings.fogDistance);
        o.addProperty("hatSize", Settings.hatSize);
        o.addProperty("hatGradient", Settings.hatGradient);
        o.addProperty("wings", Settings.wings);
        o.addProperty("jumpFx", Settings.jumpFx);
        o.addProperty("showSession", Settings.showSession);
        o.addProperty("showWaypoint", Settings.showWaypoint);

        try {
            Files.createDirectories(FILE.getParent());
            Files.writeString(FILE, new GsonBuilder().setPrettyPrinting().create().toJson(o));
        } catch (IOException e) {
            GlassMenu.LOGGER.warn("Could not save {}", FILE, e);
        }
    }

    private static boolean bool(JsonObject o, String key, boolean def) {
        return o.has(key) ? o.get(key).getAsBoolean() : def;
    }

    private static int num(JsonObject o, String key, int def) {
        return o.has(key) ? o.get(key).getAsInt() : def;
    }
}
