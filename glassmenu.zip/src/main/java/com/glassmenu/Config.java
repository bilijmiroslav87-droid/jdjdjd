package com.glassmenu;

import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.lang.reflect.Field;
import java.nio.file.Files;
import java.nio.file.Path;

/** Saves and loads every boolean/int field of Settings as config/glassmenu.json. */
public final class Config {
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("glassmenu.json");

    private Config() {}

    public static void load() {
        if (!Files.exists(FILE)) return;
        try {
            JsonObject o = JsonParser.parseString(Files.readString(FILE)).getAsJsonObject();
            for (Field f : Settings.class.getFields()) {
                if (!Settings.isSetting(f) || !o.has(f.getName())) continue;
                try {
                    if (f.getType() == boolean.class) f.setBoolean(null, o.get(f.getName()).getAsBoolean());
                    else f.setInt(null, o.get(f.getName()).getAsInt());
                } catch (Exception ignored) {
                }
            }
            Settings.sanitize();
        } catch (Exception e) {
            GlassMenu.LOGGER.warn("Could not read {}, using defaults", FILE, e);
        }
    }

    public static void save() {
        JsonObject o = new JsonObject();
        for (Field f : Settings.class.getFields()) {
            if (!Settings.isSetting(f)) continue;
            try {
                if (f.getType() == boolean.class) o.addProperty(f.getName(), f.getBoolean(null));
                else o.addProperty(f.getName(), f.getInt(null));
            } catch (IllegalAccessException ignored) {
            }
        }
        try {
            Files.createDirectories(FILE.getParent());
            Files.writeString(FILE, new GsonBuilder().setPrettyPrinting().create().toJson(o));
        } catch (IOException e) {
            GlassMenu.LOGGER.warn("Could not save {}", FILE, e);
        }
    }
}
