package com.glassmenu;

import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

/** Saves and loads Settings as config/glassmenu.json. */
public final class Config {
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("glassmenu.json");

    private Config() {}

    public static void load() {
        if (!Files.exists(FILE)) return;
        try {
            JsonObject o = JsonParser.parseString(Files.readString(FILE)).getAsJsonObject();

            Settings.infoPanel = bool(o, "infoPanel", Settings.infoPanel);
            Settings.infoCorner = num(o, "infoCorner", Settings.infoCorner);
            Settings.showCoords = bool(o, "showCoords", Settings.showCoords);
            Settings.showPing = bool(o, "showPing", Settings.showPing);
            Settings.cps = bool(o, "cps", Settings.cps);
            Settings.compass = bool(o, "compass", Settings.compass);
            Settings.keystrokes = bool(o, "keystrokes", Settings.keystrokes);
            Settings.keystrokesCorner = num(o, "keystrokesCorner", Settings.keystrokesCorner);

            Settings.zoomEnabled = bool(o, "zoomEnabled", Settings.zoomEnabled);
            Settings.zoomFov = num(o, "zoomFov", Settings.zoomFov);
            Settings.fpsColors = bool(o, "fpsColors", Settings.fpsColors);

            Settings.trailMode = num(o, "trailMode", Settings.trailMode);
            Settings.hitMode = num(o, "hitMode", Settings.hitMode);
            Settings.rainbow = bool(o, "rainbow", Settings.rainbow);
            Settings.accentIndex = num(o, "accentIndex", Settings.accentIndex);

            Settings.glassAlpha = num(o, "glassAlpha", Settings.glassAlpha);
            Settings.cornerRadius = num(o, "cornerRadius", Settings.cornerRadius);
            Settings.sheen = bool(o, "sheen", Settings.sheen);
            Settings.openAnim = bool(o, "openAnim", Settings.openAnim);

            Settings.sanitize();
        } catch (Exception e) {
            GlassMenu.LOGGER.warn("Could not read {}, using defaults", FILE, e);
        }
    }

    public static void save() {
        JsonObject o = new JsonObject();
        o.addProperty("infoPanel", Settings.infoPanel);
        o.addProperty("infoCorner", Settings.infoCorner);
        o.addProperty("showCoords", Settings.showCoords);
        o.addProperty("showPing", Settings.showPing);
        o.addProperty("cps", Settings.cps);
        o.addProperty("compass", Settings.compass);
        o.addProperty("keystrokes", Settings.keystrokes);
        o.addProperty("keystrokesCorner", Settings.keystrokesCorner);

        o.addProperty("zoomEnabled", Settings.zoomEnabled);
        o.addProperty("zoomFov", Settings.zoomFov);
        o.addProperty("fpsColors", Settings.fpsColors);

        o.addProperty("trailMode", Settings.trailMode);
        o.addProperty("hitMode", Settings.hitMode);
        o.addProperty("rainbow", Settings.rainbow);
        o.addProperty("accentIndex", Settings.accentIndex);

        o.addProperty("glassAlpha", Settings.glassAlpha);
        o.addProperty("cornerRadius", Settings.cornerRadius);
        o.addProperty("sheen", Settings.sheen);
        o.addProperty("openAnim", Settings.openAnim);

        try {
            Files.createDirectories(FILE.getParent());
            Files.writeString(FILE, new GsonBuilder().setPrettyPrinting().create().toJson(o));
        } catch (IOException e) {
            GlassMenu.LOGGER.warn("Could not save {}", FILE, e);
        }
    }

    private static boolean bool(JsonObject o, String key, boolean def) {
        return o.has(key) ? o.get(key).getAsBoolean() : def;
    }

    private static int num(JsonObject o, String key, int def) {
        return o.has(key) ? o.get(key).getAsInt() : def;
    }
}
