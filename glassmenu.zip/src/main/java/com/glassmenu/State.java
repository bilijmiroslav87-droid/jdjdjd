package com.glassmenu;

/** Small runtime flags shared with mixins (mixin classes must not declare their own static fields). */
public final class State {
    public static boolean handsPushed;

    private State() {}
}
