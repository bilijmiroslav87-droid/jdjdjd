package com.glassmenu;

import net.minecraft.util.math.Vec3d;
import org.joml.Vector4f;

/**
 * Blends a colour returned by the game towards the chosen tint. Works with the three shapes the
 * game uses for sky/fog colours across versions: packed int, Vec3d and Vector4f.
 */
public final class Tint {
    private Tint() {}

    public static Object sky(Object value) {
        return Settings.tintSky ? apply(value) : value;
    }

    public static Object fog(Object value) {
        return Settings.tintFog ? apply(value) : value;
    }

    private static Object apply(Object value) {
        int rgb = Settings.TINT_COLORS[Settings.tintIndex] & 0xFFFFFF;
        float s = Settings.tintStrength / 100f;
        float tr = ((rgb >> 16) & 0xFF) / 255f;
        float tg = ((rgb >> 8) & 0xFF) / 255f;
        float tb = (rgb & 0xFF) / 255f;

        if (value instanceof Integer argb) {
            int r = Math.round(lerp(((argb >> 16) & 0xFF) / 255f, tr, s) * 255f);
            int g = Math.round(lerp(((argb >> 8) & 0xFF) / 255f, tg, s) * 255f);
            int b = Math.round(lerp((argb & 0xFF) / 255f, tb, s) * 255f);
            return (argb & 0xFF000000) | (r << 16) | (g << 8) | b;
        }
        if (value instanceof Vec3d v) {
            return new Vec3d(lerp((float) v.x, tr, s), lerp((float) v.y, tg, s), lerp((float) v.z, tb, s));
        }
        if (value instanceof Vector4f v) {
            return new Vector4f(lerp(v.x, tr, s), lerp(v.y, tg, s), lerp(v.z, tb, s), v.w);
        }
        return value;
    }

    private static float lerp(float a, float b, float t) {
        return a + (b - a) * t;
    }
}
