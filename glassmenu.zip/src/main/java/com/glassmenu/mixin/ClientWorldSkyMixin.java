package com.glassmenu.mixin;

import com.glassmenu.Tint;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Sky tint. The return type is handled generically (packed int or Vec3d, depending on version). */
@Mixin(ClientWorld.class)
public abstract class ClientWorldSkyMixin {
    @Inject(method = "getSkyColor", at = @At("RETURN"), cancellable = true, require = 0)
    private void glassmenu$sky(Vec3d cameraPos, float tickDelta, CallbackInfoReturnable<Object> cir) {
        Object original = cir.getReturnValue();
        Object tinted = Tint.sky(original);
        if (tinted != original) cir.setReturnValue(tinted);
    }
}
