package com.glassmenu.mixin;

import com.glassmenu.Settings;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Hides the vanilla crosshair (when a custom style is chosen) and the vignette. */
@Mixin(InGameHud.class)
public abstract class InGameHudMixin {
    @Inject(method = "renderCrosshair", at = @At("HEAD"), cancellable = true, require = 0)
    private void glassmenu$crosshair(DrawContext context, RenderTickCounter tickCounter, CallbackInfo ci) {
        if (Settings.crosshairStyle != 0) ci.cancel();
    }

    @Inject(method = "renderVignetteOverlay", at = @At("HEAD"), cancellable = true, require = 0)
    private void glassmenu$vignette(DrawContext context, Entity entity, CallbackInfo ci) {
        if (Settings.hideVignette) ci.cancel();
    }
}
