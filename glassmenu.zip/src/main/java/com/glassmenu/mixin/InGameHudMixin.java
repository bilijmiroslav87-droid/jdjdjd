package com.glassmenu.mixin;

import com.glassmenu.Settings;
import net.minecraft.client.gui.hud.InGameHud;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Hides vanilla HUD pieces. require = 0 means that if a method name does not match
 * this Minecraft version the injection is skipped instead of crashing the game.
 */
@Mixin(InGameHud.class)
public abstract class InGameHudMixin {
    @Inject(method = "renderCrosshair", at = @At("HEAD"), cancellable = true, require = 0)
    private void glassmenu$crosshair(CallbackInfo ci) {
        if (Settings.crosshairStyle != 0) ci.cancel();
    }

    @Inject(method = "renderFireOverlay", at = @At("HEAD"), cancellable = true, require = 0)
    private void glassmenu$fire(CallbackInfo ci) {
        if (Settings.hideFire) ci.cancel();
    }

    @Inject(method = "renderVignetteOverlay", at = @At("HEAD"), cancellable = true, require = 0)
    private void glassmenu$vignette(CallbackInfo ci) {
        if (Settings.hideVignette) ci.cancel();
    }
}
