package com.glassmenu.mixin;

import com.glassmenu.Settings;
import com.glassmenu.State;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.item.HeldItemRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Custom hands: offsets and scales the first-person item, restoring the matrix afterwards. */
@Mixin(HeldItemRenderer.class)
public abstract class HeldItemRendererMixin {
    @Inject(method = "renderFirstPersonItem", at = @At("HEAD"), require = 0)
    private void glassmenu$handsBegin(AbstractClientPlayerEntity player, float tickDelta, float pitch, Hand hand,
                                      float swingProgress, ItemStack item, float equipProgress,
                                      MatrixStack matrices, VertexConsumerProvider vertexConsumers, int light,
                                      CallbackInfo ci) {
        if (!Settings.customHands) return;
        matrices.push();
        State.handsPushed = true;
        float side = hand == Hand.MAIN_HAND ? 1.0F : -1.0F;
        matrices.translate(side * Settings.handX / 100.0F, Settings.handY / 100.0F, -Settings.handZ / 100.0F);
        float s = Settings.handScale / 100.0F;
        matrices.scale(s, s, s);
    }

    @Inject(method = "renderFirstPersonItem", at = @At("RETURN"), require = 0)
    private void glassmenu$handsEnd(AbstractClientPlayerEntity player, float tickDelta, float pitch, Hand hand,
                                    float swingProgress, ItemStack item, float equipProgress,
                                    MatrixStack matrices, VertexConsumerProvider vertexConsumers, int light,
                                    CallbackInfo ci) {
        if (State.handsPushed) {
            matrices.pop();
            State.handsPushed = false;
        }
    }
}
