package com.glassmenu.mixin;

import com.glassmenu.Settings;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.MinecraftClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Overrides the fog colour and distance after vanilla has set them.
 * require = 0: if the method name does not exist in this version, nothing happens.
 */
@Mixin(net.minecraft.client.render.BackgroundRenderer.class)
public abstract class BackgroundRendererMixin {
    @Inject(method = "applyFog", at = @At("TAIL"), require = 0)
    private static void glassmenu$fog(CallbackInfo ci) {
        if (!Settings.customFog) return;

        int color = Settings.FOG_COLORS[Settings.fogColorIndex];
        if (color == 0) color = Settings.ACCENTS[Settings.accentIndex];
        float r = ((color >> 16) & 0xFF) / 255f;
        float g = ((color >> 8) & 0xFF) / 255f;
        float b = (color & 0xFF) / 255f;
        RenderSystem.setShaderFogColor(r, g, b, 1.0f);

        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.options == null) return;
        float viewBlocks = mc.options.getViewDistance().getValue() * 16f;
        float end = viewBlocks * Settings.fogDistance / 100f;
        RenderSystem.setShaderFogStart(end * 0.1f);
        RenderSystem.setShaderFogEnd(end);
    }
}
