package com.glassmenu.mixin;

import com.glassmenu.Tint;
import net.minecraft.client.render.BackgroundRenderer;
import net.minecraft.client.render.Camera;
import net.minecraft.client.world.ClientWorld;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Fog colour tint (also colours the horizon). */
@Mixin(BackgroundRenderer.class)
public abstract class BackgroundRendererMixin {
    @Inject(method = "getFogColor", at = @At("RETURN"), cancellable = true, require = 0)
    private static void glassmenu$fogColor(Camera camera, float tickDelta, ClientWorld world,
                                           int clampedViewDistance, float skyDarkness,
                                           CallbackInfoReturnable<Object> cir) {
        Object original = cir.getReturnValue();
        Object tinted = Tint.fog(original);
        if (tinted != original) cir.setReturnValue(tinted);
    }
}
