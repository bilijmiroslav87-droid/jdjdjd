package com.glassmenu.mixin;

import com.glassmenu.Settings;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Weather override (Clear / Rain / Thunder). Only applied on the client side of a world. */
@Mixin(World.class)
public abstract class WorldWeatherMixin {
    @Shadow
    public abstract boolean isClient();

    @Inject(method = "getRainGradient", at = @At("HEAD"), cancellable = true, require = 0)
    private void glassmenu$rain(float delta, CallbackInfoReturnable<Float> cir) {
        if (!isClient()) return;
        switch (Settings.weatherOverride) {
            case 1 -> cir.setReturnValue(0.0F);
            case 2, 3 -> cir.setReturnValue(1.0F);
            default -> { }
        }
    }

    @Inject(method = "getThunderGradient", at = @At("HEAD"), cancellable = true, require = 0)
    private void glassmenu$thunder(float delta, CallbackInfoReturnable<Float> cir) {
        if (!isClient()) return;
        switch (Settings.weatherOverride) {
            case 1, 2 -> cir.setReturnValue(0.0F);
            case 3 -> cir.setReturnValue(1.0F);
            default -> { }
        }
    }
}
