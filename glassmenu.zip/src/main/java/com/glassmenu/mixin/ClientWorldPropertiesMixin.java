package com.glassmenu.mixin;

import com.glassmenu.Settings;
import net.minecraft.client.world.ClientWorld;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Custom time: the client sees a fixed time of day. Client-only class, the server is not touched. */
@Mixin(ClientWorld.Properties.class)
public abstract class ClientWorldPropertiesMixin {
    @Inject(method = "getTimeOfDay", at = @At("HEAD"), cancellable = true, require = 0)
    private void glassmenu$time(CallbackInfoReturnable<Long> cir) {
        if (Settings.customTime) cir.setReturnValue(Settings.timeHour * 1000L);
    }
}
