package com.glassmenu;

public final class Theme {
    private Theme() {}

    /** Current accent colour, cycling through hues when rainbow mode is on. */
    public static int accent() {
        if (Settings.rainbow) {
            float hue = (System.currentTimeMillis() % 6000L) / 6000f;
            return 0xFF000000 | hsv(hue, 0.55f, 1f);
        }
        return Settings.ACCENTS[Settings.accentIndex];
    }

    /** Returns the colour with its alpha byte replaced by a (clamped) value. */
    public static int alpha(int color, int a) {
        return (Math.max(0, Math.min(255, a)) << 24) | (color & 0xFFFFFF);
    }

    /** HSV to RGB (no alpha). h, s, v in [0, 1]. */
    static int hsv(float h, float s, float v) {
        float hh = (h - (float) Math.floor(h)) * 6f;
        int i = (int) Math.floor(hh);
        float f = hh - i;
        float p = v * (1f - s);
        float q = v * (1f - s * f);
        float t = v * (1f - s * (1f - f));
        float r, g, b;
        switch (i % 6) {
            case 0 -> { r = v; g = t; b = p; }
            case 1 -> { r = q; g = v; b = p; }
            case 2 -> { r = p; g = v; b = t; }
            case 3 -> { r = p; g = q; b = v; }
            case 4 -> { r = t; g = p; b = v; }
            default -> { r = v; g = p; b = q; }
        }
        return ((int) (r * 255) << 16) | ((int) (g * 255) << 8) | (int) (b * 255);
    }
}
