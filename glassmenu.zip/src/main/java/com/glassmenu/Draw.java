package com.glassmenu;

import net.minecraft.client.gui.DrawContext;

public final class Draw {
    private Draw() {}

    /** Filled rectangle with rounded corners, built from horizontal strips. */
    public static void roundRect(DrawContext ctx, int x, int y, int w, int h, int r, int color) {
        if (w <= 0 || h <= 0) return;
        r = Math.max(0, Math.min(r, Math.min(w, h) / 2));
        if (r == 0) {
            ctx.fill(x, y, x + w, y + h, color);
            return;
        }
        ctx.fill(x, y + r, x + w, y + h - r, color);
        for (int dy = 0; dy < r; dy++) {
            double c = dy + 0.5;
            int inset = (int) Math.round(r - Math.sqrt(r * r - (r - c) * (r - c)));
            ctx.fill(x + inset, y + dy, x + w - inset, y + dy + 1, color);
            ctx.fill(x + inset, y + h - dy - 1, x + w - inset, y + h - dy, color);
        }
    }
}
