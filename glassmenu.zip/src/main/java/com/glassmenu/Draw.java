package com.glassmenu;

import net.minecraft.client.gui.DrawContext;

public final class Draw {
    private Draw() {}

    /** Rounded rectangle with anti-aliased corners (edge pixels get partial alpha). */
    public static void roundRect(DrawContext ctx, int x, int y, int w, int h, int r, int color) {
        if (w <= 0 || h <= 0) return;
        int a = color >>> 24;
        if (a == 0) return;
        r = Math.max(0, Math.min(r, Math.min(w, h) / 2));
        if (r == 0) {
            ctx.fill(x, y, x + w, y + h, color);
            return;
        }
        ctx.fill(x, y + r, x + w, y + h - r, color);
        for (int dy = 0; dy < r; dy++) {
            double c = dy + 0.5;
            double inset = r - Math.sqrt(Math.max(0.0, r * r - (r - c) * (r - c)));
            int full = (int) Math.ceil(inset);          // first fully covered column
            double edge = full - inset;                 // coverage of the partial pixel before it
            int top = y + dy, bottom = y + h - dy - 1;

            if (x + w - full > x + full) {
                ctx.fill(x + full, top, x + w - full, top + 1, color);
                ctx.fill(x + full, bottom, x + w - full, bottom + 1, color);
            }
            if (full > 0 && edge > 0.02) {
                int ec = Theme.alpha(color, Math.round(a * (float) edge));
                ctx.fill(x + full - 1, top, x + full, top + 1, ec);
                ctx.fill(x + w - full, top, x + w - full + 1, top + 1, ec);
                ctx.fill(x + full - 1, bottom, x + full, bottom + 1, ec);
                ctx.fill(x + w - full, bottom, x + w - full + 1, bottom + 1, ec);
            }
        }
    }

    /** Soft drop shadow built from stacked rounded rectangles that fade out. */
    public static void shadow(DrawContext ctx, int x, int y, int w, int h, int r, int color, int alpha, int spread) {
        if (alpha <= 0 || spread <= 0) return;
        for (int i = spread; i >= 1; i--) {
            float t = i / (float) (spread + 1);
            int a = Math.round(alpha * (1f - t) * (1f - t) * 0.55f);
            if (a <= 0) continue;
            roundRect(ctx, x - i, y - i + 2, w + 2 * i, h + 2 * i, r + i, Theme.alpha(color, a));
        }
    }

    /** Horizontal gradient, one column at a time. */
    public static void hGradient(DrawContext ctx, int x, int y, int w, int h, int from, int to) {
        if (w <= 0) return;
        for (int i = 0; i < w; i++) {
            float t = w == 1 ? 0f : i / (float) (w - 1);
            ctx.fill(x + i, y, x + i + 1, y + h, lerpArgb(from, to, t));
        }
    }

    /** Vertical gradient, one row at a time. */
    public static void vGradient(DrawContext ctx, int x, int y, int w, int h, int from, int to) {
        if (h <= 0) return;
        for (int i = 0; i < h; i++) {
            float t = h == 1 ? 0f : i / (float) (h - 1);
            ctx.fill(x, y + i, x + w, y + i + 1, lerpArgb(from, to, t));
        }
    }

    static int lerpArgb(int a, int b, float t) {
        int aa = (int) (((a >>> 24) & 0xFF) * (1 - t) + ((b >>> 24) & 0xFF) * t);
        int ar = (int) (((a >> 16) & 0xFF) * (1 - t) + ((b >> 16) & 0xFF) * t);
        int ag = (int) (((a >> 8) & 0xFF) * (1 - t) + ((b >> 8) & 0xFF) * t);
        int ab = (int) ((a & 0xFF) * (1 - t) + (b & 0xFF) * t);
        return (aa << 24) | (ar << 16) | (ag << 8) | ab;
    }
}
