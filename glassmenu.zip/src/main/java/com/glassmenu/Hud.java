package com.glassmenu;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.text.Text;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public final class Hud {
    public static final String[] CORNER_NAMES = {"Top-left", "Top-right", "Bottom-left", "Bottom-right"};

    private static final int M = 6;
    private static final int GREEN = 0xFF7CFFB2, YELLOW = 0xFFFFD36E, RED = 0xFFFF6F6F, GREY = 0xFFAAAAAA;
    private static final String[] COMPASS = {"N", "NE", "E", "SE", "S", "SW", "W", "NW"};
    private static final DateTimeFormatter TIME = DateTimeFormatter.ofPattern("HH:mm");

    private record Line(String text, int color) {}

    private Hud() {}

    public static void render(DrawContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || mc.options.hudHidden) return;

        TextRenderer tr = mc.textRenderer;
        int sw = mc.getWindow().getScaledWidth();
        int sh = mc.getWindow().getScaledHeight();
        int accent = Theme.accent();

        if (Settings.compass) drawCompass(ctx, tr, mc, sw, accent);
        drawInfo(ctx, tr, mc, sw, sh, accent);
        if (Settings.keystrokes) drawKeystrokes(ctx, tr, mc, sw, sh, accent);
        if (GlassMenu.isZooming()) {
            ctx.drawCenteredTextWithShadow(tr, Text.literal("ZOOM"), sw / 2, sh / 2 + 12, accent);
        }
    }

    /** Top-centre compass strip showing the direction the player faces. */
    private static void drawCompass(DrawContext ctx, TextRenderer tr, MinecraftClient mc, int sw, int accent) {
        float bearing = ((mc.player.getYaw() + 180f) % 360f + 360f) % 360f;
        int cw = 180, ch = 14;
        int x0 = sw / 2 - cw / 2, y0 = M;
        Draw.roundRect(ctx, x0, y0, cw, ch, 4, 0x88101820);

        int base = (int) Math.floor(bearing / 15f) * 15;
        for (int k = -8; k <= 8; k++) {
            int deg = base + k * 15;
            float rel = ((deg - bearing + 540f) % 360f) - 180f;
            if (Math.abs(rel) > 90f) continue;
            int tx = sw / 2 + Math.round(rel * cw / 180f);
            int nd = ((deg % 360) + 360) % 360;
            if (nd % 45 == 0) {
                int color = nd % 90 == 0 ? 0xFFFFFFFF : 0xFFBBBBBB;
                ctx.drawCenteredTextWithShadow(tr, Text.literal(COMPASS[nd / 45]), tx, y0 + 3, color);
            } else {
                ctx.fill(tx, y0 + ch - 4, tx + 1, y0 + ch - 1, 0x88FFFFFF);
            }
        }
        ctx.fill(sw / 2, y0, sw / 2 + 1, y0 + ch, accent);
    }

    /** Info panel with time, fps, ping, coordinates and CPS. */
    private static void drawInfo(DrawContext ctx, TextRenderer tr, MinecraftClient mc, int sw, int sh, int accent) {
        List<Line> lines = new ArrayList<>();

        if (Settings.infoPanel) {
            int fps = mc.getCurrentFps();
            int fpsColor = !Settings.fpsColors ? 0xFFFFFFFF
                    : fps >= 100 ? GREEN : fps >= 50 ? YELLOW : RED;
            lines.add(new Line(LocalTime.now().format(TIME), 0xFFFFFFFF));
            lines.add(new Line(fps + " fps", fpsColor));

            if (Settings.showPing) {
                int ping = ping(mc);
                int pingColor = ping < 0 ? GREY
                        : !Settings.fpsColors ? 0xFFFFFFFF
                        : ping < 80 ? GREEN : ping < 150 ? YELLOW : RED;
                lines.add(new Line(ping < 0 ? "-- ms" : ping + " ms", pingColor));
            }
            if (Settings.showCoords) {
                lines.add(new Line(mc.player.getBlockX() + " " + mc.player.getBlockY() + " " + mc.player.getBlockZ(),
                        0xFFBBBBBB));
            }
        }
        if (Settings.cps) {
            lines.add(new Line("CPS " + GlassMenu.cpsLeft() + " | " + GlassMenu.cpsRight(), accent));
        }
        if (lines.isEmpty()) return;

        int w = 0;
        for (Line l : lines) w = Math.max(w, tr.getWidth(l.text()));
        w += 14;
        int h = lines.size() * 11 + 8;
        int[] p = anchor(Settings.infoCorner, w, h, sw, sh);

        Draw.roundRect(ctx, p[0], p[1], w, h, 4, 0x88101820);
        ctx.fill(p[0] + 4, p[1], p[0] + w - 4, p[1] + 1, accent);
        for (int i = 0; i < lines.size(); i++) {
            Line l = lines.get(i);
            ctx.drawTextWithShadow(tr, Text.literal(l.text()), p[0] + 7, p[1] + 5 + i * 11, l.color());
        }
    }

    /** WASD, Shift, Space, LMB, RMB keycaps that light up while held. */
    private static void drawKeystrokes(DrawContext ctx, TextRenderer tr, MinecraftClient mc, int sw, int sh, int accent) {
        int[] p = anchor(Settings.keystrokesCorner, 58, 78, sw, sh);
        int ox = p[0], oy = p[1];

        key(ctx, tr, "W", ox + 20, oy, mc.options.forwardKey.isPressed(), accent);
        key(ctx, tr, "A", ox, oy + 20, mc.options.leftKey.isPressed(), accent);
        key(ctx, tr, "S", ox + 20, oy + 20, mc.options.backKey.isPressed(), accent);
        key(ctx, tr, "D", ox + 40, oy + 20, mc.options.rightKey.isPressed(), accent);
        keyWide(ctx, tr, "SHIFT", ox, oy + 40, 28, mc.options.sneakKey.isPressed(), accent);
        keyWide(ctx, tr, "SPACE", ox + 30, oy + 40, 28, mc.options.jumpKey.isPressed(), accent);
        keyWide(ctx, tr, "LMB", ox, oy + 60, 28, mc.options.attackKey.isPressed(), accent);
        keyWide(ctx, tr, "RMB", ox + 30, oy + 60, 28, mc.options.useKey.isPressed(), accent);
    }

    private static void key(DrawContext ctx, TextRenderer tr, String label, int x, int y, boolean pressed, int accent) {
        keyWide(ctx, tr, label, x, y, 18, pressed, accent);
    }

    private static void keyWide(DrawContext ctx, TextRenderer tr, String label, int x, int y, int w,
                                boolean pressed, int accent) {
        int h = 18;
        Draw.roundRect(ctx, x, y, w, h, 3, pressed ? Theme.alpha(accent, 0xCC) : 0x66101820);
        ctx.drawCenteredTextWithShadow(tr, Text.literal(label), x + w / 2, y + (h - 8) / 2, 0xFFFFFFFF);
    }

    private static int ping(MinecraftClient mc) {
        if (mc.getNetworkHandler() == null || mc.player == null) return -1;
        PlayerListEntry entry = mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
        return entry == null ? -1 : entry.getLatency();
    }

    /** Top-left / top-right / bottom-left / bottom-right placement with margin. */
    static int[] anchor(int corner, int w, int h, int sw, int sh) {
        int x = (corner & 1) == 1 ? sw - w - M : M;
        int y = corner >= 2 ? sh - h - M : M;
        return new int[]{x, y};
    }
}
