package com.glassmenu;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.Vec3d;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public final class Hud {
    public static final String[] CORNER_NAMES = {"Top-left", "Top-right", "Bottom-left", "Bottom-right"};

    private static final int M = 6;
    private static final int GREEN = 0xFF7CFFB2, YELLOW = 0xFFFFD36E, RED = 0xFFFF6F6F, GREY = 0xFFAAAAAA;
    private static final String[] COMPASS = {"N", "NE", "E", "SE", "S", "SW", "W", "NW"};
    private static final DateTimeFormatter CLOCK = DateTimeFormatter.ofPattern("HH:mm");

    private record Line(String text, int color) {}

    private Hud() {}

    public static void render(DrawContext ctx) {
        if (!GlassMenu.isHudVisible()) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || mc.options.hudHidden) return;

        TextRenderer tr = mc.textRenderer;
        float scale = Settings.hudScale / 100f;
        int sw = Math.round(mc.getWindow().getScaledWidth() / scale);
        int sh = Math.round(mc.getWindow().getScaledHeight() / scale);
        int accent = Theme.accent();

        ctx.getMatrices().push();
        ctx.getMatrices().scale(scale, scale, 1f);
        drawAll(ctx, tr, mc, sw, sh, accent);
        ctx.getMatrices().pop();
    }

    /** Custom crosshair: a dot or a small cross. The vanilla one is hidden by the mixin. */
    private static void drawCrosshair(DrawContext ctx, int sw, int sh) {
        int cx = sw / 2, cy = sh / 2;
        int white = 0xFFFFFFFF;
        if (Settings.crosshairStyle == 1) {
            ctx.fill(cx - 1, cy - 1, cx + 1, cy + 1, white);
        } else if (Settings.crosshairStyle == 2) {
            ctx.fill(cx - 6, cy - 1, cx - 2, cy + 1, white);
            ctx.fill(cx + 3, cy - 1, cx + 7, cy + 1, white);
            ctx.fill(cx - 1, cy - 6, cx + 1, cy - 2, white);
            ctx.fill(cx - 1, cy + 3, cx + 1, cy + 7, white);
        }
    }

    private static int bg() {
        return Theme.alpha(0x101820, Math.round(Settings.hudAlpha * 2.55f));
    }

    private static void drawAll(DrawContext ctx, TextRenderer tr, MinecraftClient mc, int sw, int sh, int accent) {
        if (Settings.compass) drawCompass(ctx, tr, mc, sw, accent);
        if (mc.currentScreen == null) drawCrosshair(ctx, sw, sh);
        drawInfo(ctx, tr, mc, sw, sh, accent);
        if (Settings.showGraph) drawGraph(ctx, sw, sh, accent);
        if (Settings.keystrokes) drawKeystrokes(ctx, tr, mc, sw, sh, accent);
        if (Settings.armorHud) drawArmor(ctx, tr, mc, sw, sh, accent);
        if (Settings.potionHud) drawPotions(ctx, tr, mc, sw, sh, accent);
        if (GlassMenu.isZooming()) {
            ctx.drawCenteredTextWithShadow(tr, Fonts.text("ZOOM"), sw / 2, sh / 2 + 12, accent);
        }
    }

    /** Top-centre compass strip showing the direction the player faces. */
    private static void drawCompass(DrawContext ctx, TextRenderer tr, MinecraftClient mc, int sw, int accent) {
        float bearing = ((mc.player.getYaw() + 180f) % 360f + 360f) % 360f;
        int cw = 180, ch = 14;
        int x0 = sw / 2 - cw / 2, y0 = M;
        Draw.roundRect(ctx, x0, y0, cw, ch, 4, bg());

        int base = (int) Math.floor(bearing / 15f) * 15;
        for (int k = -8; k <= 8; k++) {
            int deg = base + k * 15;
            float rel = ((deg - bearing + 540f) % 360f) - 180f;
            if (Math.abs(rel) > 90f) continue;
            int tx = sw / 2 + Math.round(rel * cw / 180f);
            int nd = ((deg % 360) + 360) % 360;
            if (nd % 45 == 0) {
                int color = nd % 90 == 0 ? 0xFFFFFFFF : 0xFFBBBBBB;
                ctx.drawCenteredTextWithShadow(tr, Fonts.text(COMPASS[nd / 45]), tx, y0 + 3, color);
            } else {
                ctx.fill(tx, y0 + ch - 4, tx + 1, y0 + ch - 1, 0x88FFFFFF);
            }
        }
        ctx.fill(sw / 2, y0, sw / 2 + 1, y0 + ch, accent);
    }

    /** Info panel: clock, game time, fps, speed, ping, coordinates and CPS. */
    private static void drawInfo(DrawContext ctx, TextRenderer tr, MinecraftClient mc, int sw, int sh, int accent) {
        List<Line> lines = new ArrayList<>();

        if (Settings.infoPanel) {
            int fps = mc.getCurrentFps();
            int fpsColor = !Settings.fpsColors ? 0xFFFFFFFF
                    : fps >= 100 ? GREEN : fps >= 50 ? YELLOW : RED;
            lines.add(new Line(LocalTime.now().format(CLOCK), 0xFFFFFFFF));
            if (Settings.showTime) lines.add(new Line(gameTime(mc), 0xFFFFFFFF));
            lines.add(new Line(fps + " fps", fpsColor));

            if (Settings.showSpeed) {
                Vec3d v = mc.player.getVelocity();
                double bps = Math.hypot(v.x, v.z) * 20.0;
                lines.add(new Line(String.format("%.1f b/s", bps), 0xFFFFFFFF));
            }
            if (Settings.showPing) {
                int ping = ping(mc);
                int pingColor = ping < 0 ? GREY
                        : !Settings.fpsColors ? 0xFFFFFFFF
                        : ping < 80 ? GREEN : ping < 150 ? YELLOW : RED;
                lines.add(new Line(ping < 0 ? "-- ms" : ping + " ms", pingColor));
            }
            if (Settings.showCoords) {
                lines.add(new Line(mc.player.getBlockX() + " " + mc.player.getBlockY() + " " + mc.player.getBlockZ(),
                        0xFFBBBBBB));
            }
        }
        if (Settings.showSession) {
            long secs = GlassMenu.sessionMillis() / 1000;
            long h = secs / 3600, m = (secs % 3600) / 60, sec = secs % 60;
            String t = h > 0 ? String.format("%d:%02d:%02d", h, m, sec) : String.format("%02d:%02d", m, sec);
            lines.add(new Line("Session " + t, 0xFFFFFFFF));
        }
        if (Settings.showWaypoint && !GlassMenu.waypoints().isEmpty()) {
            double best = Double.MAX_VALUE;
            for (double[] wp : GlassMenu.waypoints()) {
                double dx = wp[0] - mc.player.getX();
                double dy = wp[1] - mc.player.getY();
                double dz = wp[2] - mc.player.getZ();
                best = Math.min(best, Math.sqrt(dx * dx + dy * dy + dz * dz));
            }
            lines.add(new Line(String.format("WP %.0f m | %d set", best, GlassMenu.waypoints().size()), accent));
        }
        if (Settings.showStats) {
            double walked = GlassMenu.distanceWalked();
            String dist = walked >= 1000 ? String.format("%.2f km", walked / 1000) : String.format("%.0f m", walked);
            lines.add(new Line("Walked " + dist, 0xFFFFFFFF));
            lines.add(new Line("Peak CPS " + GlassMenu.peakCps(), 0xFFFFFFFF));
            lines.add(new Line("Avg FPS " + GlassMenu.avgFps(), 0xFFFFFFFF));
        }
        if (Settings.cps) {
            lines.add(new Line("CPS " + GlassMenu.cpsLeft() + " | " + GlassMenu.cpsRight(), accent));
        }
        drawPanel(ctx, tr, lines, Settings.infoCorner, sw, sh, accent);
    }

    /** In-game day and time, taken from the world clock (Minecraft day = 24000 ticks). */
    private static String gameTime(MinecraftClient mc) {
        long t = mc.world.getTimeOfDay();
        long day = t / 24000L;
        long tick = t % 24000L;
        int hours = (int) ((tick / 1000 + 6) % 24);
        int minutes = (int) ((tick % 1000) * 60 / 1000);
        return String.format("Day %d  %02d:%02d", day, hours, minutes);
    }

    /** Bar graph of the last 60 FPS samples. */
    private static void drawGraph(DrawContext ctx, int sw, int sh, int accent) {
        int w = GlassMenu.fpsSampleCount() + 2, h = 22;
        int[] p = anchor(Settings.graphCorner, w, h, sw, sh);
        Draw.roundRect(ctx, p[0], p[1], w, h, 4, bg());
        for (int i = 0; i < GlassMenu.fpsSampleCount(); i++) {
            int fps = GlassMenu.fpsAt(i);
            int bar = Math.max(1, Math.min(h - 4, fps * (h - 4) / 200));
            int color = !Settings.fpsColors ? accent
                    : fps >= 100 ? GREEN : fps >= 50 ? YELLOW : RED;
            int x = p[0] + 1 + i;
            ctx.fill(x, p[1] + h - 2 - bar, x + 1, p[1] + h - 2, color);
        }
    }

    /** WASD, Shift, Space, LMB, RMB keycaps that light up while held. */
    private static void drawKeystrokes(DrawContext ctx, TextRenderer tr, MinecraftClient mc, int sw, int sh, int accent) {
        int[] p = anchor(Settings.keystrokesCorner, 58, 78, sw, sh);
        int ox = p[0], oy = p[1];

        keyCap(ctx, tr, "W", ox + 20, oy, 18, mc.options.forwardKey.isPressed(), accent);
        keyCap(ctx, tr, "A", ox, oy + 20, 18, mc.options.leftKey.isPressed(), accent);
        keyCap(ctx, tr, "S", ox + 20, oy + 20, 18, mc.options.backKey.isPressed(), accent);
        keyCap(ctx, tr, "D", ox + 40, oy + 20, 18, mc.options.rightKey.isPressed(), accent);
        keyCap(ctx, tr, "SHIFT", ox, oy + 40, 28, mc.options.sneakKey.isPressed(), accent);
        keyCap(ctx, tr, "SPACE", ox + 30, oy + 40, 28, mc.options.jumpKey.isPressed(), accent);
        keyCap(ctx, tr, "LMB", ox, oy + 60, 28, mc.options.attackKey.isPressed(), accent);
        keyCap(ctx, tr, "RMB", ox + 30, oy + 60, 28, mc.options.useKey.isPressed(), accent);
    }

    private static void keyCap(DrawContext ctx, TextRenderer tr, String label, int x, int y, int w,
                               boolean pressed, int accent) {
        int h = 18;
        Draw.roundRect(ctx, x, y, w, h, 3, pressed ? Theme.alpha(accent, 0xCC) : bg());
        ctx.drawCenteredTextWithShadow(tr, Fonts.text(label), x + w / 2, y + (h - 8) / 2, 0xFFFFFFFF);
    }

    /** Four armour slots (helmet at the top) with durability percentages. */
    private static void drawArmor(DrawContext ctx, TextRenderer tr, MinecraftClient mc, int sw, int sh, int accent) {
        int w = 62, h = 4 * 20 + 6;
        int[] p = anchor(Settings.armorCorner, w, h, sw, sh);
        Draw.roundRect(ctx, p[0], p[1], w, h, 4, bg());
        if (Settings.hudAccentBar) ctx.fill(p[0] + 4, p[1], p[0] + w - 4, p[1] + 1, accent);
        for (int i = 0; i < 4; i++) {
            ItemStack stack = mc.player.getInventory().getArmorStack(3 - i);
            int y = p[1] + 4 + i * 20;
            ctx.drawItem(stack, p[0] + 4, y);
            if (!stack.isEmpty() && stack.isDamageable() && stack.getMaxDamage() > 0) {
                int pct = (int) Math.round(100.0 * (stack.getMaxDamage() - stack.getDamage()) / stack.getMaxDamage());
                ctx.drawTextWithShadow(tr, Fonts.text(pct + "%"), p[0] + 26, y + 5, durabilityColor(pct));
            }
        }
    }

    private static int durabilityColor(int pct) {
        return pct > 50 ? GREEN : pct > 20 ? YELLOW : RED;
    }

    /** Active potion effects with remaining time. */
    private static void drawPotions(DrawContext ctx, TextRenderer tr, MinecraftClient mc, int sw, int sh, int accent) {
        List<Line> lines = new ArrayList<>();
        for (StatusEffectInstance effect : mc.player.getStatusEffects()) {
            String name = effect.getEffectType().value().getName().getString();
            int level = effect.getAmplifier() + 1;
            int secs = Math.max(0, effect.getDuration() / 20);
            String time = String.format("%d:%02d", secs / 60, secs % 60);
            lines.add(new Line(name + (level > 1 ? " " + level : "") + "  " + time, 0xFFFFFFFF));
        }
        drawPanel(ctx, tr, lines, Settings.potionCorner, sw, sh, accent);
    }

    /** Shared rounded panel with one text line per entry, placed at a screen corner. */
    private static void drawPanel(DrawContext ctx, TextRenderer tr, List<Line> lines, int corner,
                                  int sw, int sh, int accent) {
        if (lines.isEmpty()) return;
        int w = 0;
        for (Line l : lines) w = Math.max(w, tr.getWidth(Fonts.text(l.text())));
        w += 14;
        int h = lines.size() * 11 + 8;
        int[] p = anchor(corner, w, h, sw, sh);

        Draw.roundRect(ctx, p[0], p[1], w, h, 4, bg());
        if (Settings.hudAccentBar) ctx.fill(p[0] + 4, p[1], p[0] + w - 4, p[1] + 1, accent);
        for (int i = 0; i < lines.size(); i++) {
            Line l = lines.get(i);
            ctx.drawTextWithShadow(tr, Fonts.text(l.text()), p[0] + 7, p[1] + 5 + i * 11, l.color());
        }
    }

    private static int ping(MinecraftClient mc) {
        if (mc.getNetworkHandler() == null || mc.player == null) return -1;
        PlayerListEntry entry = mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
        return entry == null ? -1 : entry.getLatency();
    }

    /** Top-left / top-right / bottom-left / bottom-right placement with margin. */
    static int[] anchor(int corner, int w, int h, int sw, int sh) {
        int x = (corner & 1) == 1 ? sw - w - M : M;
        int y = corner >= 2 ? sh - h - M : M;
        return new int[]{x, y};
    }
}
