package com.glassmenu;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.option.KeyBinding;

/** Minimal HUD: a FPS/Ping pill and a keybinds list, plus the custom crosshair. */
public final class Hud {
    public static final String[] CORNER_NAMES = {"Top-left", "Top-right", "Bottom-left", "Bottom-right"};

    private static final int MARGIN = 6, RADIUS = 6, GAP = 4;
    private static final int BG = 0xB40F0F14;          // RGBA(15, 15, 20, 180)
    private static final int BORDER = 0x14FFFFFF;
    private static final int GREEN = 0xFF7CFFB2, YELLOW = 0xFFFFD36E, RED = 0xFFFF6F6F;
    private static final int TEXT = 0xFFF2F2F5, DIM = 0xFF8A8F98, GREY = 0xFFAAAAAA;

    private static float smoothFps = -1f;

    private Hud() {}

    public static void render(DrawContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || mc.options.hudHidden) return;
        TextRenderer tr = mc.textRenderer;
        int sw = mc.getWindow().getScaledWidth();
        int sh = mc.getWindow().getScaledHeight();

        if (mc.currentScreen == null) drawCrosshair(ctx, sw, sh);
        if (!GlassMenu.isHudVisible()) return;

        int pillH = 0;
        if (Settings.pillEnabled) pillH = drawPill(ctx, tr, mc, sw, sh);
        if (Settings.keybindsHud) {
            int offset = Settings.pillEnabled && Settings.keybindsCorner == Settings.pillCorner ? pillH + GAP : 0;
            drawKeybinds(ctx, tr, sw, sh, offset);
        }
    }

    /** Custom crosshair; the vanilla one is cancelled by the mixin when a custom style is selected. */
    private static void drawCrosshair(DrawContext ctx, int sw, int sh) {
        int cx = sw / 2, cy = sh / 2, white = 0xFFFFFFFF;
        if (Settings.crosshairStyle == 1) {
            ctx.fill(cx - 1, cy - 1, cx + 1, cy + 1, white);
        } else if (Settings.crosshairStyle == 2) {
            ctx.fill(cx - 6, cy - 1, cx - 2, cy + 1, white);
            ctx.fill(cx + 3, cy - 1, cx + 7, cy + 1, white);
            ctx.fill(cx - 1, cy - 6, cx + 1, cy - 2, white);
            ctx.fill(cx - 1, cy + 3, cx + 1, cy + 7, white);
        }
    }

    /** Pill with a status dot, a smoothed FPS value and the ping. */
    private static int drawPill(DrawContext ctx, TextRenderer tr, MinecraftClient mc, int sw, int sh) {
        int fps = mc.getCurrentFps();
        smoothFps = smoothFps < 0 ? fps : smoothFps + (fps - smoothFps) * 0.08f;
        int shown = Math.round(smoothFps);
        int status = !Settings.fpsColors ? TEXT : shown >= 100 ? GREEN : shown >= 50 ? YELLOW : RED;
        String fpsText = shown + " FPS";

        String pingText = null;
        int pingColor = TEXT;
        if (Settings.showPing) {
            int ping = ping(mc);
            pingText = ping < 0 ? "-- MS" : ping + " MS";
            pingColor = ping < 0 ? GREY : !Settings.fpsColors ? TEXT : ping < 80 ? GREEN : ping < 150 ? YELLOW : RED;
        }

        int dot = 6, pad = 9, sep = 12, h = 18;
        int fpsW = tr.getWidth(Fonts.text(fpsText));
        int w = pad + dot + 6 + fpsW + (pingText != null ? sep + tr.getWidth(Fonts.text(pingText)) : 0) + pad;
        int[] p = anchor(Settings.pillCorner, w, h, sw, sh, 0);
        panel(ctx, p[0], p[1], w, h);

        int tx = p[0] + pad;
        Draw.roundRect(ctx, tx, p[1] + (h - dot) / 2, dot, dot, dot / 2, status);
        tx += dot + 6;
        ctx.drawTextWithShadow(tr, Fonts.text(fpsText), tx, p[1] + 5, TEXT);
        tx += fpsW;
        if (pingText != null) {
            ctx.fill(tx + sep / 2, p[1] + 5, tx + sep / 2 + 1, p[1] + h - 5, 0x30FFFFFF);
            ctx.drawTextWithShadow(tr, Fonts.text(pingText), tx + sep, p[1] + 5, pingColor);
        }
        return h;
    }

    /** List of the mod's keybinds; a keycap lights up while its key is held. */
    private static void drawKeybinds(DrawContext ctx, TextRenderer tr, int sw, int sh, int offset) {
        String[] names = {"Menu", "Zoom", "Hide HUD"};
        KeyBinding[] keys = {GlassMenu.openKey(), GlassMenu.zoomKey(), GlassMenu.hudKey()};
        String[] labels = new String[keys.length];
        int nameW = 0, keyW = 0;
        for (int i = 0; i < keys.length; i++) {
            labels[i] = keys[i].getBoundKeyLocalizedText().getString().toUpperCase();
            nameW = Math.max(nameW, tr.getWidth(Fonts.text(names[i])));
            keyW = Math.max(keyW, tr.getWidth(Fonts.text(labels[i])));
        }
        int pad = 9, rowH = 15, headH = 17, capPad = 5, gap = 14;
        int capW = keyW + capPad * 2;
        int w = pad + Math.max(nameW + gap + capW, tr.getWidth(Fonts.text("KEYBINDS"))) + pad;
        int h = headH + keys.length * rowH + 5;
        int[] p = anchor(Settings.keybindsCorner, w, h, sw, sh, offset);
        panel(ctx, p[0], p[1], w, h);

        ctx.drawTextWithShadow(tr, Fonts.text("KEYBINDS"), p[0] + pad, p[1] + 6, DIM);
        for (int i = 0; i < keys.length; i++) {
            int ry = p[1] + headH + i * rowH;
            ctx.drawTextWithShadow(tr, Fonts.text(names[i]), p[0] + pad, ry + 3, TEXT);
            int cx = p[0] + w - pad - capW;
            Draw.roundRect(ctx, cx, ry, capW, 12, 4, Theme.alpha(0xFFFFFF, keys[i].isPressed() ? 0x50 : 0x18));
            ctx.drawTextWithShadow(tr, Fonts.text(labels[i]), cx + capPad, ry + 2, TEXT);
        }
    }

    /** Matte rounded panel: radius 6, fill RGBA(15, 15, 20, 180), faint border. */
    private static void panel(DrawContext ctx, int x, int y, int w, int h) {
        Draw.roundRect(ctx, x, y, w, h, RADIUS, BORDER);
        Draw.roundRect(ctx, x + 1, y + 1, w - 2, h - 2, RADIUS - 1, BG);
    }

    private static int ping(MinecraftClient mc) {
        if (mc.getNetworkHandler() == null || mc.player == null) return -1;
        PlayerListEntry entry = mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
        return entry == null ? -1 : entry.getLatency();
    }

    static int[] anchor(int corner, int w, int h, int sw, int sh, int offset) {
        int x = (corner & 1) == 1 ? sw - w - MARGIN : MARGIN;
        int y = corner >= 2 ? sh - h - MARGIN - offset : MARGIN + offset;
        return new int[]{x, y};
    }
}
