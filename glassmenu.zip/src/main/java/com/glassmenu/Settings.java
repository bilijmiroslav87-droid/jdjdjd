package com.glassmenu;

public final class Settings {
    public static final String[] TRAIL_NAMES = {"Off", "End rod", "Heart", "Dust", "Flame", "Snow", "Soul"};
    public static final String[] HIT_NAMES = {"Off", "Crit", "Enchant", "Heart"};
    public static final int[] ACCENTS = {
            0xFF7AB8FF, // blue
            0xFFFF6FA8, // pink
            0xFF7CFFB2, // mint
            0xFFFFD36E, // gold
            0xFFC08CFF, // violet
            0xFFFF6F6F, // red
            0xFF6FF3FF, // cyan
            0xFFFFFFFF, // white
            0xFFFF2D55, // neon red
            0xFFAA00FF  // purple
    };
    public static final String[] WEATHER_NAMES = {"Off", "Rain", "Snow", "Ash", "Sparks"};
    public static final String[] ACCENT_NAMES = {"Blue", "Pink", "Mint", "Gold", "Violet", "Red", "Cyan", "White", "Neon red", "Purple"};

    // HUD
    public static boolean infoPanel = true;
    public static int infoCorner = 0;
    public static boolean showCoords = true;
    public static boolean showSpeed = true;
    public static boolean showPing = true;
    public static boolean cps = true;
    public static boolean compass = true;

    // Tools
    public static boolean keystrokes = false;
    public static int keystrokesCorner = 2;
    public static boolean zoomEnabled = true;
    public static int zoomFov = 30;
    public static boolean fpsColors = true;

    // Armor / potions
    public static boolean armorHud = false;
    public static int armorCorner = 3;
    public static boolean potionHud = true;
    public static int potionCorner = 1;

    // Effects
    public static int trailMode = 0;
    public static int hitMode = 1;
    public static boolean rainbow = false;
    public static int accentIndex = 0;

    // Weather (client-side particles around the player)
    public static int weatherMode = 0;
    public static int weatherDensity = 4;

    // Session / waypoint
    public static boolean showSession = true;
    public static boolean showWaypoint = true;

    // HUD look (Pulse-style)
    public static int hudAlpha = 60;       // panel background opacity, 0-100
    public static int hudScale = 100;      // 80, 100 or 120
    public static boolean hudAccentBar = true;
    public static final int[] HUD_SCALES = {80, 100, 120};

    // Custom fog and sky tint (the horizon colour of the sky follows the fog colour)
    public static final String[] FOG_NAMES = {"Night blue", "Dusk pink", "Mist grey", "Acid green", "Accent"};
    public static final int[] FOG_COLORS = {0xFF0B1A33, 0xFF5A2A4A, 0xFFAAB4BE, 0xFF1E3A24, 0};
    public static boolean customFog = false;
    public static int fogColorIndex = 0;
    public static int fogDistance = 100;   // percent of the view distance

    // Session statistics
    public static boolean showStats = true;

    // Night mode: raises the game's brightness (gamma) while enabled
    public static boolean brightBoost = false;

    // Extra visuals: hat gradient, particle wings, jump burst (client only)
    public static boolean hatGradient = false;
    public static boolean wings = false;
    public static boolean jumpFx = false;

    // Neon hat: glowing wireframe drawn with particles above the head (client only)
    public static final String[] HAT_NAMES = {"Off", "Cone", "Halo", "Both"};
    public static int hatMode = 0;
    public static int hatSize = 2;      // 1 small, 2 medium, 3 large

    // Crosshair and in-game overlays (Pulse-style)
    public static final String[] CROSSHAIR_NAMES = {"Vanilla", "Dot", "Cross", "Hidden"};
    public static int crosshairStyle = 0;
    public static boolean hideFire = false;
    public static boolean hideVignette = false;

    // Game time and FPS graph
    public static boolean showTime = true;
    public static boolean showGraph = false;
    public static int graphCorner = 3;

    public static final String[] PRESET_NAMES = {"Full", "Minimal", "Stats"};

    // Glass
    public static int glassAlpha = 85;
    public static int cornerRadius = 8;
    public static boolean sheen = true;
    public static boolean openAnim = true;
    public static boolean parallax = true;

    /** Applies a HUD preset: 0 = Full, 1 = Minimal, 2 = Stats. */
    public static void applyPreset(int i) {
        switch (i) {
            case 0 -> { // Full: everything on
                infoPanel = true; showCoords = true; showSpeed = true; showPing = true; cps = true;
                compass = true; showTime = true; showGraph = true; keystrokes = true;
                armorHud = true; potionHud = true;
            }
            case 1 -> { // Minimal: clock and FPS only, plus potions
                infoPanel = true; showCoords = false; showSpeed = false; showPing = false; cps = false;
                compass = false; showTime = false; showGraph = false; keystrokes = false;
                armorHud = false; potionHud = true;
            }
            default -> { // Stats: numbers and graph, no keys or armour
                infoPanel = true; showCoords = true; showSpeed = true; showPing = true; cps = true;
                compass = false; showTime = true; showGraph = true; keystrokes = false;
                armorHud = false; potionHud = false;
            }
        }
    }

    /** Pulse-style dark theme: white accent, translucent HUD, no accent bar, no sheen. */
    public static void applyPulseTheme() {
        accentIndex = Math.max(0, ACCENTS.length - 1);
        hudAlpha = 40;
        hudScale = 100;
        hudAccentBar = false;
        crosshairStyle = 1;
        hideFire = true;
        glassAlpha = 90;
        sheen = false;
    }

    public static void resetDefaults() {
        infoPanel = true;
        infoCorner = 0;
        showCoords = true;
        showSpeed = true;
        showPing = true;
        cps = true;
        compass = true;
        keystrokes = false;
        keystrokesCorner = 2;
        zoomEnabled = true;
        zoomFov = 30;
        fpsColors = true;
        armorHud = false;
        armorCorner = 3;
        potionHud = true;
        potionCorner = 1;
        trailMode = 0;
        hitMode = 1;
        showSession = true;
        showWaypoint = true;
        parallax = true;
        weatherMode = 0;
        weatherDensity = 4;
        hudAlpha = 60;
        hudScale = 100;
        hudAccentBar = true;
        hatMode = 0;
        hatSize = 2;
        hatGradient = false;
        wings = false;
        jumpFx = false;
        brightBoost = false;
        showStats = true;
        customFog = false;
        fogColorIndex = 0;
        fogDistance = 100;
        crosshairStyle = 0;
        hideFire = false;
        hideVignette = false;
        showTime = true;
        showGraph = false;
        graphCorner = 3;
        rainbow = false;
        accentIndex = 0;
        glassAlpha = 85;
        cornerRadius = 8;
        sheen = true;
        openAnim = true;
    }

    /** Keeps values inside valid ranges, e.g. after loading a hand-edited config. */
    public static void sanitize() {
        infoCorner = Math.floorMod(infoCorner, 4);
        keystrokesCorner = Math.floorMod(keystrokesCorner, 4);
        armorCorner = Math.floorMod(armorCorner, 4);
        graphCorner = Math.floorMod(graphCorner, 4);
        hudAlpha = clamp(hudAlpha, 0, 100);
        crosshairStyle = clamp(crosshairStyle, 0, CROSSHAIR_NAMES.length - 1);
        hatMode = clamp(hatMode, 0, HAT_NAMES.length - 1);
        hatSize = clamp(hatSize, 1, 3);
        fogColorIndex = Math.floorMod(fogColorIndex, FOG_COLORS.length);
        fogDistance = clamp(fogDistance, 20, 100);
        if (hudScale != 80 && hudScale != 100 && hudScale != 120) hudScale = 100;
        potionCorner = Math.floorMod(potionCorner, 4);
        zoomFov = clamp(zoomFov, 30, 70);
        trailMode = clamp(trailMode, 0, TRAIL_NAMES.length - 1);
        hitMode = clamp(hitMode, 0, HIT_NAMES.length - 1);
        weatherMode = clamp(weatherMode, 0, WEATHER_NAMES.length - 1);
        weatherDensity = clamp(weatherDensity, 1, 10);
        accentIndex = Math.floorMod(accentIndex, ACCENTS.length);
        glassAlpha = clamp(glassAlpha, 20, 100);
        cornerRadius = clamp(cornerRadius, 0, 12);
    }

    static int clamp(int v, int min, int max) {
        return Math.max(min, Math.min(max, v));
    }

    private Settings() {}
}
