package com.glassmenu;

public final class Settings {
    public static final String[] TRAIL_NAMES = {"Off", "End rod", "Heart", "Dust", "Flame", "Snow", "Soul"};
    public static final String[] HIT_NAMES = {"Off", "Crit", "Enchant", "Heart"};
    public static final int[] ACCENTS = {
            0xFF7AB8FF, // blue
            0xFFFF6FA8, // pink
            0xFF7CFFB2, // mint
            0xFFFFD36E, // gold
            0xFFC08CFF, // violet
            0xFFFF6F6F, // red
            0xFF6FF3FF, // cyan
            0xFFFFFFFF  // white
    };
    public static final String[] ACCENT_NAMES = {"Blue", "Pink", "Mint", "Gold", "Violet", "Red", "Cyan", "White"};

    // HUD
    public static boolean infoPanel = true;
    public static int infoCorner = 0;
    public static boolean showCoords = true;
    public static boolean showSpeed = true;
    public static boolean showPing = true;
    public static boolean cps = true;
    public static boolean compass = true;

    // Tools
    public static boolean keystrokes = false;
    public static int keystrokesCorner = 2;
    public static boolean zoomEnabled = true;
    public static int zoomFov = 30;
    public static boolean fpsColors = true;

    // Armor / potions
    public static boolean armorHud = false;
    public static int armorCorner = 3;
    public static boolean potionHud = true;
    public static int potionCorner = 1;

    // Effects
    public static int trailMode = 0;
    public static int hitMode = 1;
    public static boolean rainbow = false;
    public static int accentIndex = 0;

    // Glass
    public static int glassAlpha = 85;
    public static int cornerRadius = 8;
    public static boolean sheen = true;
    public static boolean openAnim = true;

    public static void resetDefaults() {
        infoPanel = true;
        infoCorner = 0;
        showCoords = true;
        showSpeed = true;
        showPing = true;
        cps = true;
        compass = true;
        keystrokes = false;
        keystrokesCorner = 2;
        zoomEnabled = true;
        zoomFov = 30;
        fpsColors = true;
        armorHud = false;
        armorCorner = 3;
        potionHud = true;
        potionCorner = 1;
        trailMode = 0;
        hitMode = 1;
        rainbow = false;
        accentIndex = 0;
        glassAlpha = 85;
        cornerRadius = 8;
        sheen = true;
        openAnim = true;
    }

    /** Keeps values inside valid ranges, e.g. after loading a hand-edited config. */
    public static void sanitize() {
        infoCorner = Math.floorMod(infoCorner, 4);
        keystrokesCorner = Math.floorMod(keystrokesCorner, 4);
        armorCorner = Math.floorMod(armorCorner, 4);
        potionCorner = Math.floorMod(potionCorner, 4);
        zoomFov = clamp(zoomFov, 30, 70);
        trailMode = clamp(trailMode, 0, TRAIL_NAMES.length - 1);
        hitMode = clamp(hitMode, 0, HIT_NAMES.length - 1);
        accentIndex = Math.floorMod(accentIndex, ACCENTS.length);
        glassAlpha = clamp(glassAlpha, 20, 100);
        cornerRadius = clamp(cornerRadius, 0, 12);
    }

    static int clamp(int v, int min, int max) {
        return Math.max(min, Math.min(max, v));
    }

    private Settings() {}
}
