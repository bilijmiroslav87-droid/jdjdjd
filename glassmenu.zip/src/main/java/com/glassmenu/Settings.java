package com.glassmenu;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.HashMap;
import java.util.Map;

public final class Settings {
    public static final String[] TRAIL_NAMES = {"Off", "End rod", "Heart", "Dust", "Flame", "Snow", "Soul"};
    public static final String[] HIT_NAMES = {"Off", "Crit", "Enchant", "Heart"};
    public static final String[] PARTICLE_WEATHER_NAMES = {"Off", "Rain", "Snow", "Ash", "Sparks"};
    public static final String[] WEATHER_NAMES = {"Vanilla", "Clear", "Rain", "Thunder"};
    public static final String[] HAT_NAMES = {"Off", "Cone", "Halo", "Both"};
    public static final String[] CROSSHAIR_NAMES = {"Vanilla", "Dot", "Cross", "Hidden"};
    public static final int[] ACCENTS = {
            0xFF7AB8FF, 0xFFFF6FA8, 0xFF7CFFB2, 0xFFFFD36E, 0xFFC08CFF,
            0xFFFF6F6F, 0xFF6FF3FF, 0xFFFFFFFF, 0xFFFF2D55, 0xFFAA00FF
    };
    public static final String[] ACCENT_NAMES = {"Blue", "Pink", "Mint", "Gold", "Violet", "Red", "Cyan", "White", "Neon red", "Purple"};
    public static final String[] TINT_NAMES = {"Night blue", "Dusk pink", "Mist grey", "Moss green", "Violet", "Amber"};
    public static final int[] TINT_COLORS = {0x0B1A33, 0x5A2A4A, 0xAAB4BE, 0x1E3A24, 0x3B2A66, 0x7A4A12};

    // HUD
    public static boolean pillEnabled = true;
    public static int pillCorner = 0;
    public static boolean showPing = true;
    public static boolean fpsColors = true;
    public static boolean keybindsHud = true;
    public static int keybindsCorner = 1;

    // World
    public static boolean customTime = false;
    public static int timeHour = 6;            // 0..23, in thousands of ticks (0 sunrise, 6 noon, 12 sunset, 18 midnight)
    public static int weatherOverride = 0;
    public static boolean tintSky = false;
    public static boolean tintFog = false;
    public static int tintIndex = 0;
    public static int tintStrength = 60;
    public static boolean brightBoost = false;

    // Hands and items
    public static boolean customHands = false;
    public static int handX = 0;               // centimetres
    public static int handY = 0;
    public static int handZ = 0;
    public static int handScale = 100;
    public static boolean itemPhysics = false;

    // Tools
    public static boolean zoomEnabled = true;
    public static int zoomFov = 30;
    public static int crosshairStyle = 0;
    public static boolean hideFire = false;
    public static boolean hideVignette = false;

    // Fx
    public static int trailMode = 0;
    public static int hitMode = 1;
    public static int weatherMode = 0;
    public static int weatherDensity = 4;
    public static int hatMode = 0;
    public static int hatSize = 2;
    public static boolean hatGradient = false;
    public static boolean wings = false;
    public static boolean jumpFx = false;

    // Look
    public static boolean rainbow = false;
    public static int accentIndex = 0;
    public static boolean menuBlur = true;
    public static boolean openAnim = true;

    public static void sanitize() {
        pillCorner = Math.floorMod(pillCorner, 4);
        keybindsCorner = Math.floorMod(keybindsCorner, 4);
        timeHour = clamp(timeHour, 0, 23);
        weatherOverride = clamp(weatherOverride, 0, WEATHER_NAMES.length - 1);
        tintIndex = Math.floorMod(tintIndex, TINT_COLORS.length);
        tintStrength = clamp(tintStrength, 0, 100);
        handX = clamp(handX, -50, 50);
        handY = clamp(handY, -50, 50);
        handZ = clamp(handZ, -50, 50);
        handScale = clamp(handScale, 50, 150);
        zoomFov = clamp(zoomFov, 30, 70);
        crosshairStyle = clamp(crosshairStyle, 0, CROSSHAIR_NAMES.length - 1);
        trailMode = clamp(trailMode, 0, TRAIL_NAMES.length - 1);
        hitMode = clamp(hitMode, 0, HIT_NAMES.length - 1);
        weatherMode = clamp(weatherMode, 0, PARTICLE_WEATHER_NAMES.length - 1);
        weatherDensity = clamp(weatherDensity, 1, 10);
        hatMode = clamp(hatMode, 0, HAT_NAMES.length - 1);
        hatSize = clamp(hatSize, 1, 3);
        accentIndex = Math.floorMod(accentIndex, ACCENTS.length);
    }

    static int clamp(int v, int min, int max) {
        return Math.max(min, Math.min(max, v));
    }

    /** True for the public static boolean/int fields that make up the saved configuration. */
    static boolean isSetting(Field f) {
        int mod = f.getModifiers();
        return Modifier.isStatic(mod) && !Modifier.isFinal(mod)
                && (f.getType() == boolean.class || f.getType() == int.class);
    }

    public static void resetDefaults() {
        for (Field f : Settings.class.getFields()) {
            if (!isSetting(f)) continue;
            Object v = DEFAULTS.get(f.getName());
            if (v == null) continue;
            try {
                if (f.getType() == boolean.class) f.setBoolean(null, (Boolean) v);
                else f.setInt(null, (Integer) v);
            } catch (IllegalAccessException ignored) {
            }
        }
    }

    // Must stay below all setting fields: it snapshots their initial values.
    private static final Map<String, Object> DEFAULTS = captureDefaults();

    private static Map<String, Object> captureDefaults() {
        Map<String, Object> m = new HashMap<>();
        for (Field f : Settings.class.getFields()) {
            if (!isSetting(f)) continue;
            try {
                m.put(f.getName(), f.get(null));
            } catch (IllegalAccessException ignored) {
            }
        }
        return m;
    }

    private Settings() {}
}
