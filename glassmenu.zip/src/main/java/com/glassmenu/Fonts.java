package com.glassmenu;

import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

/** Text helpers that draw with the bundled Poppins fonts instead of the vanilla font. */
public final class Fonts {
    public static final Identifier REGULAR = Identifier.of("glassmenu", "ui");
    public static final Identifier MEDIUM = Identifier.of("glassmenu", "ui_medium");
    public static final Identifier DISPLAY = Identifier.of("glassmenu", "ui_display");

    private Fonts() {}

    public static Text text(String s) {
        return Text.literal(s).setStyle(Style.EMPTY.withFont(REGULAR));
    }

    /** Headline font (Frick, uppercase display face) for titles and section headers. */
    public static Text display(String s) {
        return Text.literal(s).setStyle(Style.EMPTY.withFont(DISPLAY));
    }

    public static Text medium(String s) {
        return Text.literal(s).setStyle(Style.EMPTY.withFont(MEDIUM));
    }
}
