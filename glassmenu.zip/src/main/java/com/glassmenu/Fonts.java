package com.glassmenu;

import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

/** Text helpers that draw with the bundled Poppins fonts instead of the vanilla font. */
public final class Fonts {
    public static final Identifier REGULAR = Identifier.of("glassmenu", "ui");
    public static final Identifier MEDIUM = Identifier.of("glassmenu", "ui_medium");

    private Fonts() {}

    public static Text text(String s) {
        return Text.literal(s).setStyle(Style.EMPTY.withFont(REGULAR));
    }

    public static Text medium(String s) {
        return Text.literal(s).setStyle(Style.EMPTY.withFont(MEDIUM));
    }
}
