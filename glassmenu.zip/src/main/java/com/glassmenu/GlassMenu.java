package com.glassmenu;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.particle.DustParticleEffect;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.ActionResult;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayDeque;
import java.util.Deque;

public class GlassMenu implements ClientModInitializer {
    public static final Logger LOGGER = LoggerFactory.getLogger("glassmenu");

    private static KeyBinding openKey;
    private static KeyBinding zoomKey;

    private static final Deque<Long> leftClicks = new ArrayDeque<>();
    private static final Deque<Long> rightClicks = new ArrayDeque<>();
    private static boolean prevLeft, prevRight;

    private static Integer savedFov;
    private static boolean zooming;

    @Override
    public void onInitializeClient() {
        Config.load();

        openKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.glassmenu.open",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                "key.categories.misc"
        ));
        zoomKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.glassmenu.zoom",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_C,
                "key.categories.misc"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(GlassMenu::onTick);

        AttackEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
            if (Settings.hitMode == 0 || !world.isClient() || entity == null) return ActionResult.PASS;
            ParticleEffect fx = switch (Settings.hitMode) {
                case 2 -> ParticleTypes.ENCHANTED_HIT;
                case 3 -> ParticleTypes.HEART;
                default -> ParticleTypes.CRIT;
            };
            double y = entity.getY() + entity.getHeight() * 0.5;
            for (int i = 0; i < 8; i++) {
                world.addParticle(fx, entity.getX(), y, entity.getZ(),
                        (Math.random() - 0.5) * 0.3,
                        Math.random() * 0.3,
                        (Math.random() - 0.5) * 0.3);
            }
            return ActionResult.PASS;
        });

        HudRenderCallback.EVENT.register((ctx, tickCounter) -> Hud.render(ctx));
    }

    private static void onTick(MinecraftClient client) {
        while (openKey.wasPressed()) {
            if (client.currentScreen == null) {
                client.setScreen(new GlassScreen());
            }
        }
        tickClicks(client);
        tickZoom(client);
        tickTrail(client);
    }

    private static void tickClicks(MinecraftClient client) {
        long now = System.currentTimeMillis();
        boolean left = client.options.attackKey.isPressed();
        boolean right = client.options.useKey.isPressed();
        if (left && !prevLeft) leftClicks.addLast(now);
        if (right && !prevRight) rightClicks.addLast(now);
        prevLeft = left;
        prevRight = right;
    }

    /** Hold the zoom key to narrow the FOV; the old FOV is restored on release. */
    private static void tickZoom(MinecraftClient client) {
        boolean want = Settings.zoomEnabled && zoomKey.isPressed()
                && client.player != null && client.currentScreen == null;
        if (want) {
            if (savedFov == null) savedFov = client.options.getFov().getValue();
            client.options.getFov().setValue(Settings.zoomFov);
            zooming = true;
        } else {
            if (savedFov != null) {
                client.options.getFov().setValue(savedFov);
                savedFov = null;
            }
            zooming = false;
        }
    }

    private static void tickTrail(MinecraftClient client) {
        if (Settings.trailMode == 0 || client.player == null || client.world == null) return;
        if (client.world.getTime() % 2 != 0) return;
        var p = client.player;
        client.world.addParticle(trailParticle(), p.getX(), p.getY() + 0.1, p.getZ(), 0.0, 0.01, 0.0);
    }

    private static ParticleEffect trailParticle() {
        return switch (Settings.trailMode) {
            case 2 -> ParticleTypes.HEART;
            case 3 -> new DustParticleEffect(Theme.accent() & 0xFFFFFF, 1.0F);
            case 4 -> ParticleTypes.FLAME;
            case 5 -> ParticleTypes.SNOWFLAKE;
            case 6 -> ParticleTypes.SOUL_FIRE_FLAME;
            default -> ParticleTypes.END_ROD;
        };
    }

    /** Left-click presses in the last second. */
    public static int cpsLeft() {
        return prune(leftClicks);
    }

    /** Right-click presses in the last second. */
    public static int cpsRight() {
        return prune(rightClicks);
    }

    private static int prune(Deque<Long> clicks) {
        long cutoff = System.currentTimeMillis() - 1000L;
        while (!clicks.isEmpty() && clicks.peekFirst() < cutoff) clicks.pollFirst();
        return clicks.size();
    }

    public static boolean isZooming() {
        return zooming;
    }

    public static KeyBinding openKey() {
        return openKey;
    }

    public static KeyBinding zoomKey() {
        return zoomKey;
    }
}
