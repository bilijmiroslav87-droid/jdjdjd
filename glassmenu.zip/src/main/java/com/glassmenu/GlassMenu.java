package com.glassmenu;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.particle.DustParticleEffect;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.ActionResult;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class GlassMenu implements ClientModInitializer {
    public static final Logger LOGGER = LoggerFactory.getLogger("glassmenu");

    private static KeyBinding openKey;
    private static KeyBinding zoomKey;
    private static KeyBinding hudKey;

    private static boolean hudVisible = true;
    private static Integer savedFov;
    private static boolean zooming;
    private static Double savedGamma;
    private static boolean wasOnGround = true;

    @Override
    public void onInitializeClient() {
        Config.load();

        openKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.glassmenu.open", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, "key.categories.misc"));
        zoomKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.glassmenu.zoom", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_C, "key.categories.misc"));
        hudKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.glassmenu.hud", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_H, "key.categories.misc"));

        ClientTickEvents.END_CLIENT_TICK.register(GlassMenu::onTick);

        AttackEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
            if (Settings.hitMode == 0 || !world.isClient() || entity == null) return ActionResult.PASS;
            ParticleEffect fx = switch (Settings.hitMode) {
                case 2 -> ParticleTypes.ENCHANTED_HIT;
                case 3 -> ParticleTypes.HEART;
                default -> ParticleTypes.CRIT;
            };
            double y = entity.getY() + entity.getHeight() * 0.5;
            for (int i = 0; i < 8; i++) {
                world.addParticle(fx, entity.getX(), y, entity.getZ(),
                        (Math.random() - 0.5) * 0.3, Math.random() * 0.3, (Math.random() - 0.5) * 0.3);
            }
            return ActionResult.PASS;
        });

        HudRenderCallback.EVENT.register((ctx, tickCounter) -> Hud.render(ctx));
    }

    private static void onTick(MinecraftClient client) {
        while (openKey.wasPressed()) {
            if (client.currentScreen == null) client.setScreen(new GlassScreen());
        }
        while (hudKey.wasPressed()) {
            if (client.currentScreen == null && client.player != null) hudVisible = !hudVisible;
        }
        tickZoom(client);
        tickBrightness(client);
        tickTrail(client);
        tickWeatherParticles(client);
        tickHat(client);
        tickWings(client);
        tickJumpFx(client);
    }

    /** Hold the zoom key to narrow the FOV; the old FOV is restored on release. */
    private static void tickZoom(MinecraftClient client) {
        boolean want = Settings.zoomEnabled && zoomKey.isPressed()
                && client.player != null && client.currentScreen == null;
        if (want) {
            if (savedFov == null) savedFov = client.options.getFov().getValue();
            client.options.getFov().setValue(Settings.zoomFov);
            zooming = true;
        } else {
            if (savedFov != null) {
                client.options.getFov().setValue(savedFov);
                savedFov = null;
            }
            zooming = false;
        }
    }

    /** Brightness boost: gamma goes to maximum while enabled; the old value is restored afterwards. */
    private static void tickBrightness(MinecraftClient client) {
        if (client.options == null) return;
        if (Settings.brightBoost) {
            if (savedGamma == null) savedGamma = client.options.getGamma().getValue();
            if (client.options.getGamma().getValue() < 1.0) client.options.getGamma().setValue(1.0);
        } else if (savedGamma != null) {
            client.options.getGamma().setValue(savedGamma);
            savedGamma = null;
        }
    }

    private static void tickTrail(MinecraftClient client) {
        if (Settings.trailMode == 0 || client.player == null || client.world == null) return;
        if (client.world.getTime() % 2 != 0) return;
        var p = client.player;
        client.world.addParticle(trailParticle(), p.getX(), p.getY() + 0.1, p.getZ(), 0.0, 0.01, 0.0);
    }

    private static ParticleEffect trailParticle() {
        return switch (Settings.trailMode) {
            case 2 -> ParticleTypes.HEART;
            case 3 -> new DustParticleEffect(Theme.accent() & 0xFFFFFF, 1.0F);
            case 4 -> ParticleTypes.FLAME;
            case 5 -> ParticleTypes.SNOWFLAKE;
            case 6 -> ParticleTypes.SOUL_FIRE_FLAME;
            default -> ParticleTypes.END_ROD;
        };
    }

    /** Client-side weather particles in a box around the player; only you see them. */
    private static void tickWeatherParticles(MinecraftClient client) {
        if (Settings.weatherMode == 0 || client.player == null || client.world == null) return;
        var player = client.player;
        var random = client.world.random;
        for (int i = 0; i < Settings.weatherDensity; i++) {
            double x = player.getX() + (random.nextDouble() - 0.5) * 24.0;
            double z = player.getZ() + (random.nextDouble() - 0.5) * 24.0;
            double y = player.getY() + 4 + random.nextDouble() * 10.0;
            switch (Settings.weatherMode) {
                case 1 -> client.world.addParticle(ParticleTypes.RAIN, x, y, z, 0.0, -0.6, 0.0);
                case 2 -> client.world.addParticle(ParticleTypes.SNOWFLAKE, x, y, z,
                        (random.nextDouble() - 0.5) * 0.05, -0.05, (random.nextDouble() - 0.5) * 0.05);
                case 3 -> client.world.addParticle(ParticleTypes.WHITE_ASH, x, y, z,
                        (random.nextDouble() - 0.5) * 0.02, -0.03, (random.nextDouble() - 0.5) * 0.02);
                default -> client.world.addParticle(ParticleTypes.END_ROD, x, y, z,
                        (random.nextDouble() - 0.5) * 0.1, -0.1, (random.nextDouble() - 0.5) * 0.1);
            }
        }
    }

    private static int lerpRgb(int a, int b, float t) {
        int r = (int) (((a >> 16) & 0xFF) * (1 - t) + ((b >> 16) & 0xFF) * t);
        int g = (int) (((a >> 8) & 0xFF) * (1 - t) + ((b >> 8) & 0xFF) * t);
        int bl = (int) ((a & 0xFF) * (1 - t) + (b & 0xFF) * t);
        return (r << 16) | (g << 8) | bl;
    }

    /** Neon hat: cone spokes and a halo ring made of dust particles above the head. */
    private static void tickHat(MinecraftClient client) {
        if (Settings.hatMode == 0 || client.player == null || client.world == null) return;
        var player = client.player;
        var random = client.world.random;
        double baseY = player.getY() + player.getHeight() + 0.2;
        double size = 0.25 + 0.2 * Settings.hatSize;
        double spin = (client.world.getTime() % 628) * 0.01;
        int accent = Theme.accent() & 0xFFFFFF;
        boolean cone = Settings.hatMode == 1 || Settings.hatMode == 3;
        boolean halo = Settings.hatMode == 2 || Settings.hatMode == 3;

        if (cone) {
            for (int i = 0; i < 4; i++) {
                int spoke = random.nextInt(8);
                double angle = spoke * Math.PI / 4 + spin;
                double t = random.nextDouble();
                double radius = size * (1.0 - t);
                int colour = Settings.hatGradient ? lerpRgb(accent, 0xFFFFFF, (float) t) : accent;
                client.world.addParticle(new DustParticleEffect(colour, 0.9F),
                        player.getX() + Math.cos(angle) * radius, baseY + t * 0.5,
                        player.getZ() + Math.sin(angle) * radius, 0.0, 0.0, 0.0);
            }
        }
        if (halo) {
            for (int i = 0; i < 3; i++) {
                double angle = random.nextDouble() * Math.PI * 2 + spin;
                client.world.addParticle(new DustParticleEffect(accent, 0.9F),
                        player.getX() + Math.cos(angle) * size, baseY,
                        player.getZ() + Math.sin(angle) * size, 0.0, 0.0, 0.0);
            }
        }
    }

    /** Particle wings on the back that flap slowly. */
    private static void tickWings(MinecraftClient client) {
        if (!Settings.wings || client.player == null || client.world == null) return;
        var player = client.player;
        var random = client.world.random;
        double yaw = Math.toRadians(player.getYaw());
        double sideX = Math.cos(yaw), sideZ = Math.sin(yaw);
        double backX = Math.sin(yaw), backZ = -Math.cos(yaw);
        double flap = Math.sin(client.world.getTime() * 0.2) * 0.35;
        double chestY = player.getY() + player.getHeight() * 0.65;
        int accent = Theme.accent() & 0xFFFFFF;

        for (int side = -1; side <= 1; side += 2) {
            for (int i = 0; i < 2; i++) {
                float frac = random.nextFloat();
                double reach = 0.25 + frac * 0.9;
                double lift = 0.15 + frac * 0.45 + flap * frac;
                client.world.addParticle(new DustParticleEffect(lerpRgb(accent, 0xFFFFFF, frac), 0.8F),
                        player.getX() + backX * 0.2 + sideX * side * reach, chestY + lift,
                        player.getZ() + backZ * 0.2 + sideZ * side * reach, 0.0, 0.0, 0.0);
            }
        }
    }

    /** Burst of particles at the feet when the player leaves the ground upwards. */
    private static void tickJumpFx(MinecraftClient client) {
        if (client.player == null || client.world == null) return;
        boolean onGround = client.player.isOnGround();
        if (Settings.jumpFx && wasOnGround && !onGround && client.player.getVelocity().y > 0) {
            var random = client.world.random;
            for (int i = 0; i < 12; i++) {
                double angle = random.nextDouble() * Math.PI * 2;
                client.world.addParticle(ParticleTypes.END_ROD,
                        client.player.getX(), client.player.getY() + 0.05, client.player.getZ(),
                        Math.cos(angle) * 0.08, 0.02, Math.sin(angle) * 0.08);
            }
        }
        wasOnGround = onGround;
    }

    public static boolean isHudVisible() { return hudVisible; }
    public static boolean isZooming() { return zooming; }
    public static KeyBinding openKey() { return openKey; }
    public static KeyBinding zoomKey() { return zoomKey; }
    public static KeyBinding hudKey() { return hudKey; }
}
